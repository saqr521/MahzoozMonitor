package com.mahzooz.monitor;

/**
 * Text-level de-duplication for OCR strike observations.
 *
 * This sits after OCR and protects the analytics layer from animation frames,
 * blinking UI and repeated presentation of the same result. It does not
 * suppress visual detection of bars/storage items.
 */
public final class StrikeDataFilter {
    private static final long DEFAULT_DUPLICATE_WINDOW_MS = 7000L;

    private final long duplicateWindowMs;
    private String lastAnalyzedGift = "";
    private int lastMultiplier = Integer.MIN_VALUE;
    private long lastStrikeTime = 0L;

    public StrikeDataFilter() {
        this(DEFAULT_DUPLICATE_WINDOW_MS);
    }

    public StrikeDataFilter(long duplicateWindowMs) {
        this.duplicateWindowMs = Math.max(1000L, duplicateWindowMs);
    }

    /**
     * Returns false when the same gift + multiplier is merely being redrawn
     * during the same result/animation window.
     */
    public synchronized boolean isNewUniqueStrike(String currentGift, int currentMultiplier) {
        long now = System.currentTimeMillis();
        String gift = OcrFilter.normalize(currentGift);

        if (gift.isEmpty()) return false;

        if (gift.equals(lastAnalyzedGift)
                && currentMultiplier == lastMultiplier
                && lastStrikeTime != 0L
                && now - lastStrikeTime < duplicateWindowMs) {
            return false;
        }

        lastAnalyzedGift = gift;
        lastMultiplier = currentMultiplier;
        lastStrikeTime = now;
        return true;
    }

    public synchronized void reset() {
        lastAnalyzedGift = "";
        lastMultiplier = Integer.MIN_VALUE;
        lastStrikeTime = 0L;
    }

    public synchronized long lastStrikeTime() {
        return lastStrikeTime;
    }

    /**
     * Extracts x1/x10/x49/x99 style multipliers from OCR text.
     * Arabic multiplication signs and common OCR variants are tolerated.
     * Returns 0 when no multiplier is present.
     */
    public static int extractMultiplier(String text) {
        if (text == null) return 0;
        String s = text
                .replace('×', 'x')
                .replace('X', 'x')
                .replace('х', 'x')
                .replace('Х', 'x');

        java.util.regex.Matcher m =
                java.util.regex.Pattern.compile("(?i)\\bx\\s*(\\d{1,4})\\b").matcher(s);
        int best = 0;
        while (m.find()) {
            try {
                best = Math.max(best, Integer.parseInt(m.group(1)));
            } catch (Throwable ignored) {}
        }
        return best;
    }
}
