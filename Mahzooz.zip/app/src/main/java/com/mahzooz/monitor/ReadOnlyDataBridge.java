package com.mahzooz.monitor;

/**
 * Safe ingestion boundary for result data explicitly delivered to Mahzooz by
 * an app-owned/exported source. It is deliberately not a packet interceptor.
 */
public final class ReadOnlyDataBridge {
    public interface Listener { void onResult(ReadOnlyResultDataParser.Result result); }
    private final Listener listener;
    public ReadOnlyDataBridge(Listener listener) { this.listener = listener; }
    public void accept(String payload) {
        ReadOnlyResultDataParser.Result r = ReadOnlyResultDataParser.parse(payload);
        if (listener != null) listener.onResult(r);
    }
}
