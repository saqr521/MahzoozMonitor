Build workflow.
