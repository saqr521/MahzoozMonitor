package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import java.util.*;

/**
 * Live visual reader for the Mahzooz item board.
 *
 * The v46 build previously contained an unrelated fixed 5x2 Taka board reader
 * with unrelated game prototypes. That reader could never describe the
 * Mahzooz green/yellow item board correctly.  This class now uses the same
 * marker-first pipeline as the main Analyzer and reads only the user-selected
 * rectangle supplied to it.
 */
public final class GamePlayVision {
    public static final class Suggestion {
        public final String label;
        public final int confidencePct;
        public final int hits;
        public final int total;
        Suggestion(String l, int c, int h, int t) {
            label = l;
            confidencePct = Math.max(0, Math.min(100, c));
            hits = h;
            total = t;
        }
    }

    public static final class Result {
        public final boolean gridDetected, stable;
        public final String currentLabel;
        public final int recognitionPct;
        public final List<Suggestion> suggestions;
        public final int changedCells;
        public final String sequence;
        Result(boolean gd, boolean st, String cl, int rp, List<Suggestion> ss, int cc, String seq) {
            gridDetected = gd;
            stable = st;
            currentLabel = cl;
            recognitionPct = rp;
            suggestions = ss;
            changedCells = cc;
            sequence = seq;
        }
    }

    private final Context boardContext;
    private final TemplateRepository templates;
    private String lastSignature = "";
    private int stableFrames = 0;
    private String committedSignature = "";
    private String lastTrigger = "";

    public GamePlayVision(Context context) {
        boardContext = context.getApplicationContext();
        templates = new TemplateRepository(boardContext);
    }

    public synchronized Result analyze(Bitmap board, HistoryDb db, long nowMs) {
        if (board == null || board.isRecycled() || board.getWidth() < 80 || board.getHeight() < 80) {
            return empty();
        }

        List<Detector.Marker> green = Detector.findMarkers(board, true);
        List<Detector.Marker> yellow = Detector.findMarkers(board, false);
        List<Detector.Marker> all = new ArrayList<>();
        all.addAll(green);
        all.addAll(yellow);
        all.sort((a, b) -> {
            int d = Integer.compare(a.rect.top, b.rect.top);
            return d != 0 ? d : Integer.compare(a.rect.left, b.rect.left);
        });

        TemplateRepository repo = templates;
        ArrayList<String> labels = new ArrayList<>();
        int recognized = 0;
        float scoreSum = 0f;
        for (Detector.Marker marker : all) {
            Detector.Tile tile = Detector.itemForMarker(board, marker, repo);
            String label = tile == null ? "" : tile.label;
            if (label == null || label.isEmpty() || "غير معروف".equals(label)) label = "";
            labels.add(label);
            if (!label.isEmpty()) {
                recognized++;
                scoreSum += Math.max(0f, Math.min(1f, tile.similarity));
            }
        }

        String signature = String.join(";", labels);
        if (signature.equals(lastSignature)) stableFrames++;
        else {
            lastSignature = signature;
            stableFrames = 1;
        }

        String trigger = "";
        int changed = 0;
        if (stableFrames >= 2 && !signature.equals(committedSignature)) {
            if (!committedSignature.isEmpty()) {
                String[] old = committedSignature.split(";", -1);
                int n = Math.min(old.length, labels.size());
                for (int i = 0; i < n; i++) {
                    String before = old[i] == null ? "" : old[i];
                    String after = labels.get(i);
                    if (!after.isEmpty() && !after.equals(before)) {
                        changed++;
                        if (trigger.isEmpty()) trigger = after;
                        if (!before.isEmpty()) {
                            try { db.observeGameTransition(before, after); } catch (Throwable ignored) {}
                        }
                    }
                }
            } else {
                for (String label : labels) if (!label.isEmpty()) { trigger = label; break; }
            }
            committedSignature = signature;
            if (!trigger.isEmpty()) lastTrigger = trigger;
        }

        if (trigger.isEmpty()) trigger = lastTrigger;
        if (trigger.isEmpty()) {
            for (String label : labels) if (!label.isEmpty()) { trigger = label; break; }
        }

        List<Suggestion> suggestions = aggregateSuggestions(labels, db);
        int recognition = recognized == 0 ? 0 : Math.round(100f * scoreSum / recognized);
        boolean detected = !all.isEmpty();
        return new Result(detected, stableFrames >= 2, trigger, recognition, suggestions,
                changed, sequenceText(labels));
    }


    private Result empty() {
        return new Result(false, false, "", 0, Collections.emptyList(), 0, "");
    }

    /**
     * Builds an ordered 1..5 chain from the actual observed visual-transition
     * table. The previous implementation merged unrelated next candidates,
     * which did not produce the requested consecutive sequence.
     *
     * No step is invented: when there is not enough observed transition
     * evidence, the sequence stops.
     */
    private List<Suggestion> aggregateSuggestions(List<String> labels, HistoryDb db) {
        ArrayList<Suggestion> out = new ArrayList<>();
        if (labels == null || db == null) return out;

        // Start from the currently visible item that has the strongest
        // observed outgoing transition history.
        String current = "";
        int bestTotal = -1;

        for (String label : labels) {
            if (label == null || label.isEmpty()) continue;
            try {
                List<String> rows = db.rankedGameTransitions(label, 1);
                if (!rows.isEmpty()) {
                    String[] p = rows.get(0).split("\\|", -1);
                    if (p.length >= 3) {
                        String[] ht = p[2].split("/", 2);
                        if (ht.length >= 2) {
                            int total = Integer.parseInt(ht[1]);
                            if (total > bestTotal) {
                                bestTotal = total;
                                current = label;
                            }
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }

        if (current.isEmpty()) return out;

        LinkedHashSet<String> visited = new LinkedHashSet<>();
        for (int step = 0; step < 5 && !current.isEmpty(); step++) {
            List<String> rows;
            try {
                rows = db.rankedGameTransitions(current, 8);
            } catch (Throwable ignored) {
                break;
            }

            String chosenNext = "";
            int chosenHits = 0;
            int chosenTotal = 0;
            int chosenPct = 0;

            for (String row : rows) {
                try {
                    String[] p = row.split("\\|", -1);
                    if (p.length < 3) continue;

                    String next = p[0] == null ? "" : p[0].trim();
                    if (next.isEmpty() || visited.contains(next) || next.equals(current)) continue;

                    String[] ht = p[2].split("/", 2);
                    if (ht.length < 2) continue;

                    int hits = Integer.parseInt(ht[0]);
                    int total = Integer.parseInt(ht[1]);
                    int pct = Integer.parseInt(p[1]);
                    if (hits <= 0 || total <= 0) continue;

                    chosenNext = next;
                    chosenHits = hits;
                    chosenTotal = total;
                    chosenPct = Math.max(0, Math.min(100, pct));
                    break;
                } catch (Throwable ignored) {}
            }

            if (chosenNext.isEmpty()) break;

            visited.add(chosenNext);
            out.add(new Suggestion(chosenNext, chosenPct, chosenHits, chosenTotal));
            current = chosenNext;
        }

        return out;
    }

    private String sequenceText(List<String> labels) {
        if (labels.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (String s : labels) {
            if (b.length() > 0) b.append(" → ");
            b.append(s == null || s.isEmpty() ? "غير مقروء" : s);
        }
        return b.toString();
    }
}
