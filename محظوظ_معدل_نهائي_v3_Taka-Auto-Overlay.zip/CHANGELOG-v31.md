# v31 — إصلاح قراءة الشاشة والأيقونات

- توسيع كشف علامات الشريط الأخضر والخزين الأصفر ليشمل كامل إطار الشاشة بدل الاقتصار على الجزء السفلي.
- تخفيف شرط تطابق لون العلامة قليلًا للتعامل مع الحواف ومؤثرات اللعبة.
- إصلاح حساب منطقة الأيقونة أسفل العلامة: لم يعد يعتمد على `screenWidth/4` الذي كان ينتج قصاصات ضخمة ويكسر التعرف بالقوالب.
- إبقاء الإطار الملتقط في الذاكرة أثناء التحليل فقط وعدم حفظه كصورة على الهاتف.
- رفع نسخة التطبيق إلى 8.0.0 / versionCode 28.

ملاحظة الاختبار: بيئة البناء الحالية لا تحتوي توزيع Gradle 8.10.2 محليًا، والاتصال بـ services.gradle.org غير متاح؛ لذلك لم يتم ادعاء نجاح Build على هذه البيئة.


## v31.1 — إصلاح تعلّم الشريط والخزين
- إصلاح مسار تعلّم العلاقات: كان الربط يعتمد على ظهور شريط أخضر جديد واختفاء خزين أصفر واحد في نفس اللقطة، وهو عكس اتجاه العلاقة المطلوب في بعض اختبارات اللعبة.
- عند اختيار شريط أخضر بصريًا، يحفظ البرنامج لقطة أساس للخزين ثم ينتظر اختفاء عنصر أصفر فعلي أثناء بقاء لوحة العناصر ظاهرة.
- عند رصد الاستهلاك، تُحفظ العلاقة بصيغة **الشريط ← الخزين** في قاعدة SQLite الدائمة، ويمكن أن تكون أكثر من قطعة خزين للشريط نفسه.
- لم يتم إضافة أي نقر أو تحكم تلقائي في اللعبة؛ التعلّم يظل قراءة شاشة فقط.
- رفع versionCode إلى 29 وversionName إلى 8.0.1 حتى يمكن تثبيت النسخة فوق v31.

## v31.7 — مؤشر الرهانات والتحليل الحسابي
- إضافة محرك محلي لمؤشر الرهان يعرض الطرف المرشح، الثقة الحسابية، سبب المؤشر، والمبالغ المرصودة عند توفرها عبر OCR.
- تحليل السلسلة والنمط المتبادل وآخر 10 نتائج مرصودة.
- حساب مبلغ مرجعي محلي يبدأ من 5 عملات، يعاد للأساس عند نتيجة فوز مقروءة، ويتضاعف عند نتيجة خسارة مقروءة، بحد أقصى 64× الأساس.
- المؤشر للعرض فقط ولا ينفذ أي ضغط أو إرسال أو تحكم داخل اللعبة.

## v31.8 linked analytics
- Unified OCR + filtered OCR + recent-history + pool-number parsing + pattern analysis into one overlay report.
- Recent history is capped at the latest 10 observations.
- Overlay now receives one combined local analytics signal from the Analyzer.
- Removed stake/multiplier calculation from the analytics engine; no automated game interaction.

## v31.8 linked OCR analytics refinement
- OCR filter remains the live input gate; unchanged OCR text is ignored.
- Unified local analytics now combines the last 10 observed labels, streak/alternation evidence, and labeled OCR numeric observations into one neutral signal score.
- Added data-quality indication so the overlay distinguishes limited/medium/high observation coverage.
- Numeric OCR parsing is explicitly local and observational; no screenshots are written by OCR.
- No automatic game interaction, betting submission, or stake/multiplier calculation is performed.


- Added local Martingale tracking to the modified OCR analytics build.
