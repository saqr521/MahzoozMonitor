# v22 — 7.4.0 — Observed Hit-Plan Decision Layer

- Added persistent `hit_plans` storage.
- Added `HitPlanEngine` for pre-play hit-count display.
- The decision UI can show exact observed plans such as ×9 or ×49 only after those counts are actually observed.
- Each completed single-icon interaction is recorded as observed ×1; no synthetic ×9/×49 values are created.
- Kept all prior visual, interaction-reference, sequence, relation, acceleration, OpenCV, grid, Apriori, atomic/bitmask and read-only safety layers.
- Fixed duplicate transition output line in `HistoryDb`.
- No automated tapping, input injection, game memory access, hooks, traffic interception, or TLS bypass.
