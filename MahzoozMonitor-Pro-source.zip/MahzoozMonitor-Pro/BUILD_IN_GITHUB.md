لو المستودع لا يحتوي gradle-wrapper.jar، شغّل `gradle wrapper --gradle-version 8.10.2`
مرة واحدة من بيئة Android/Gradle، ثم ارفع ملفات wrapper إلى المستودع.
