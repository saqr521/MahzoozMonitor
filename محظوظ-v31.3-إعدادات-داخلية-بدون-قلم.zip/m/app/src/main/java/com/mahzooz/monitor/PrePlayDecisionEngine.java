package com.mahzooz.monitor;

import java.util.*;

/**
 * Evidence-only pre-play decision layer.
 * It ranks currently visible icons before the user plays, using only observations
 * already stored by the monitor. It never predicts a guaranteed win and never
 * generates a hit count that was not observed.
 */
public final class PrePlayDecisionEngine {
    public static final class Decision {
        public final String label;
        public final int scorePct;
        public final int observedTests;
        public final int transitionHits;
        public final int transitionTotal;
        public final int relationHits;
        public final int relationTotal;
        public final boolean hasEvidence;
        Decision(String l,int s,int tests,int th,int tt,int rh,int rt,boolean e){
            label=l; scorePct=s; observedTests=tests; transitionHits=th; transitionTotal=tt;
            relationHits=rh; relationTotal=rt; hasEvidence=e;
        }
        public String line(int rank){
            StringBuilder s=new StringBuilder();
            s.append(rank).append(") ").append(label).append(" — ").append(scorePct).append("% ثقة قرار");
            if(transitionTotal>0) s.append(" | تسلسل ").append(transitionHits).append('/').append(transitionTotal);
            if(relationTotal>0) s.append(" | ربط ").append(relationHits).append('/').append(relationTotal);
            if(observedTests>0) s.append(" | اختبارات ").append(observedTests);
            return s.toString();
        }
    }

    public synchronized List<Decision> rank(List<Detector.Tile> visible, String currentGreenState, HistoryDb db){
        ArrayList<Decision> out=new ArrayList<>();
        if(visible==null||db==null) return out;

        LinkedHashMap<String,Detector.Tile> unique=new LinkedHashMap<>();
        for(Detector.Tile t:visible){
            if(t==null||t.label==null||t.label.isEmpty()||"غير معروف".equals(t.label)) continue;
            if(!unique.containsKey(t.label)) unique.put(t.label,t);
        }

        Map<String,int[]> transition=new HashMap<>();
        if(currentGreenState!=null&&!currentGreenState.isEmpty()){
            for(String row:db.rankedTransitions(currentGreenState,32)){
                String[] p=row.split("\\|",-1);
                if(p.length<3) continue;
                String[] ht=p[2].split("/",2);
                if(ht.length<2) continue;
                try { transition.put(p[0],new int[]{Integer.parseInt(ht[0]),Integer.parseInt(ht[1])}); }
                catch(NumberFormatException ignored) {}
            }
        }

        for(String label:unique.keySet()){
            int[] tr=transition.get(label);
            int th=tr==null?0:tr[0], tt=tr==null?0:tr[1];
            int rh=0, rt=0;
            // A relation is evidence for the green-side item; if this icon is a
            // currently visible green item, its stored yellow relation contributes.
            rt=db.relationTotal(label);
            if(rt>0) rh=db.bestRelationHits(label);
            int tests=db.interactionTestCount(label);

            boolean evidence=tt>0 || rt>0 || tests>0;
            if(!evidence) continue;

            double transitionPct=tt>0 ? 100.0*th/tt : 0;
            double relationPct=rt>0 ? 100.0*rh/rt : 0;
            double testScore=Math.min(100.0,tests*12.5);
            // Prioritize repeated transition evidence, then relation evidence,
            // then repeated icon-specific interaction references.
            double score = tt>0 ? transitionPct*0.55 : 0;
            score += rt>0 ? relationPct*0.30 : 0;
            score += testScore*0.15;
            int pct=(int)Math.round(Math.max(1,Math.min(99,score)));
            out.add(new Decision(label,pct,tests,th,tt,rh,rt,true));
        }
        Collections.sort(out,(a,b)->{
            int d=Integer.compare(b.scorePct,a.scorePct);
            if(d!=0) return d;
            d=Integer.compare(b.transitionHits,a.transitionHits);
            if(d!=0) return d;
            return Integer.compare(b.observedTests,a.observedTests);
        });
        return out;
    }
}
