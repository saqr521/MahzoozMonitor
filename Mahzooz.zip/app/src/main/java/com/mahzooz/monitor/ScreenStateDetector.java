package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.List;

/**
 * Fast screen-state detector. It classifies what is actually visible and keeps
 * unknown/ambiguous states explicit instead of guessing hidden game state.
 */
public final class ScreenStateDetector {
    public enum LockState { OPEN, LOCKED, UNKNOWN }
    public static final class State {
        public final LockState lockState;
        public final String scene;
        public final float confidence;
        State(LockState l,String s,float c){lockState=l;scene=s;confidence=c;}
    }
    private ScreenStateDetector() {}

    public static State inspect(Bitmap b, List<Detector.Marker> green, List<Detector.Marker> yellow) {
        return inspect(b, green, yellow, "", false);
    }

    public static State inspect(Bitmap b, List<Detector.Marker> green, List<Detector.Marker> yellow,
                                String ocrText, boolean takaForeground) {
        if (b==null) return new State(LockState.UNKNOWN,"لا توجد شاشة",0f);
        int w=b.getWidth(), h=b.getHeight();
        int sample=Math.max(1,Math.min(w,h)/160);
        int dark=0,total=0, bright=0;
        for(int y=h/5;y<h;y+=sample) for(int x=0;x<w;x+=sample){
            int c=b.getPixel(x,y); int v=(Color.red(c)+Color.green(c)+Color.blue(c))/3;
            total++; if(v<45) dark++; if(v>205) bright++;
        }
        float darkRatio=total==0?0:(float)dark/total;
        float brightRatio=total==0?0:(float)bright/total;
        // Strong lock visuals often expose a dim/disabled surface. This is only a
        // visible-screen heuristic; UNKNOWN is retained when evidence is weak.
        if(darkRatio>.78f && green.isEmpty() && yellow.isEmpty())
            return new State(LockState.LOCKED,"شاشة مقفولة/معطلة ظاهريًا",.78f);
        String text = ocrText == null ? "" : ocrText.toLowerCase(java.util.Locale.ROOT);
        boolean gameUi = containsAny(text, "win", "bet", "stake", "total bet", "spin", "play",
                "الرهان", "فوز", "تدوير", "اضغط للعب", "game", "لعبة");
        boolean inventoryUi = containsAny(text, "إرسال", "ارسال", "الغرفة", "الكل في الغرفة",
                "هدية", "هدايا", "تصنيف", "خصم", "الحقيبة", "أكثر شعبية", "الحدث", "فخم", "svip");
        boolean knownTakaTitle = containsAny(text, "jungle hunt", "ocean hunt", "sphinx magic",
                "sphinx", "lucky wheel");
        boolean strongGameCanvas = looksLikeGameCanvas(b);

        // Taka keeps its room header around the embedded game. A known title,
        // game controls, or the strong game-canvas fingerprint therefore takes
        // precedence over generic room/inventory words.
        if (takaForeground && (knownTakaTitle || gameUi || strongGameCanvas))
            return new State(LockState.OPEN,"شاشة لعبة مرئية",Math.min(1f,
                    .78f + .03f*Math.min(7,green.size()+yellow.size())));
        if (takaForeground && (inventoryUi || (!green.isEmpty() && !yellow.isEmpty())))
            return new State(LockState.OPEN,"واجهة الغرفة/الهدايا — ليست شاشة لعبة",.90f);
        if ((gameUi && (!green.isEmpty() || !yellow.isEmpty())) || strongGameCanvas)
            return new State(LockState.OPEN,"شاشة لعبة مرئية",Math.min(1f,.72f+.04f*Math.min(7,green.size()+yellow.size())));
        if(!green.isEmpty() || !yellow.isEmpty())
            return new State(LockState.OPEN,"مؤشرات عناصر مرئية",Math.min(1f,.55f+.04f*(green.size()+yellow.size())));
        if(brightRatio>.72f)
            return new State(LockState.UNKNOWN,"شاشة ظاهرة بدون مؤشرات كافية",.45f);
        return new State(LockState.UNKNOWN,"حالة غير محسومة",.35f);
    }
    private static boolean looksLikeGameCanvas(Bitmap b) {
        if (b == null || b.isRecycled() || b.getWidth() < 500 || b.getHeight() < 700) return false;
        int w=b.getWidth(), h=b.getHeight(), step=Math.max(10, Math.min(w,h)/70);
        int n=0, sat=0, dark=0; float[] hsv=new float[3];
        for(int y=(int)(h*.35f); y<(int)(h*.92f); y+=step) for(int x=0;x<w;x+=step){
            Color.colorToHSV(b.getPixel(x,y),hsv); n++;
            if(hsv[1]>.55f && hsv[2]>.35f) sat++;
            if(hsv[2]<.22f) dark++;
        }
        return n>0 && ((float)sat/n)>.18f && ((float)dark/n)>.08f;
    }

    private static boolean containsAny(String t, String... values) {
        if (t == null) return false;
        for (String v : values) if (v != null && !v.isEmpty() && t.contains(v.toLowerCase(java.util.Locale.ROOT))) return true;
        return false;
    }

}
