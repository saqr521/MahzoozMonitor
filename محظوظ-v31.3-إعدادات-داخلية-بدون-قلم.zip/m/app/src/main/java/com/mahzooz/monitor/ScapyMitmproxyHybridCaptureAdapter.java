package com.mahzooz.monitor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Safe hybrid-capture boundary.
 *
 * The name documents compatibility with normalized exports produced by tools
 * such as Scapy/mitmproxy, but this Android app does NOT open a packet socket,
 * run a proxy, decrypt TLS, or intercept another app's traffic.  Callers may
 * feed records that they explicitly exported from a system they own/control.
 */
public final class ScapyMitmproxyHybridCaptureAdapter {
    private final List<ImportedTelemetryRecord> imported = new ArrayList<>();

    public synchronized void acceptExportedRecord(ImportedTelemetryRecord record) {
        if (record != null) imported.add(record);
    }

    public synchronized List<ImportedTelemetryRecord> snapshot() {
        return Collections.unmodifiableList(new ArrayList<>(imported));
    }

    public synchronized void clear() { imported.clear(); }
}
