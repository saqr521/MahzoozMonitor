## v37 / قراءة الشاشة الحية وتصحيح بصمة اللعبة
- منع الـOverlay من أن يلوث OCR/الرؤية الخاصة به.
- تمييز واجهة الغرفة/الهدايا عن شاشة اللعبة داخل Taka عند توفر أدلة مرئية كافية.
- إظهار اسم اللعبة الداخلي الذي يقرأه OCR فعليًا بدل الاعتماد على اسم ثابت.
- إبقاء التحليل وصفيًا مبنيًا على الشاشة فقط؛ لا وصول لذاكرة اللعبة أو بياناتها الخاصة ولا ضمان للنتيجة.


## v29 / 7.9.0 — إصلاح دورة المراقبة والواجهة
- تم إيقاف الحفظ التلقائي لصور الشاشة في Pictures/Mahzooz؛ إطارات MediaProjection تستخدم للتحليل فقط.
- تم جعل خدمة المراقبة `START_NOT_STICKY` مع `stopWithTask=true` وإزالة الـOverlay في `onTaskRemoved` و`onDestroy` حتى لا يبقى المربع بعد إغلاق التطبيق/المهمة.
- تم تصحيح ترتيب اللوحة ليكون قسم **الخزين والشرايط يسارًا** وقسم **اللعب يمينًا** على الواجهات العربية.
- تم حذف نصوص Debug والإحداثيات وبيانات الخوارزميات من الـOverlay؛ يعرض فقط الرصد والعلاقات المرصودة.
- تم الإبقاء على التحليل البصري المحلي وقاعدة التعلم الدائمة كما هي، دون تحويل الرصد إلى تحكم أو نقر داخل اللعبة.
# محظوظ Monitor — FINAL

مشروع أندرويد لمراقبة شاشة اللعبة وتحليل عناصر 🟩 الشرايط و🟨 الخزين من صورة الشاشة، مع حفظ التعلم محليًا.

## الموجود في النسخة
- Gradle Wrapper 8.10.2 كامل.
- Android Gradle Plugin 8.7.3 + Java 17 + compile/target SDK 35.
- MediaProjection لقراءة الشاشة.
- Foreground Service مخصص لالتقاط الشاشة.
- واجهة عائمة قابلة للتحريك والتكبير/التصغير فوق اللعبة: الشرايط والخزين يسارًا، واللعب يمينًا، وتعرض البيانات المرصودة فقط.
- Accessibility Service لتنفيذ سحب واحد عند طلب كشف الصفوف المخفية، بدون نقر على العناصر.
- اكتشاف العلامات الخضراء والصفراء في لوحة العناصر، بما فيها الصفوف التي تظهر بعد السحب.
- لا توجد حزمة أيقونات ألعاب ثابتة داخل النسخة؛ التعرف على الألعاب يعتمد على الرصد الفعلي والتعلم المحلي أثناء التشغيل.
- قاعدة SQLite دائمة تحفظ الأحداث، العلاقات `الشريط ← الخزين`، وانتقالات `الحالة السابقة → العنصر التالي`.
- نسبة العلاقة تُحسب من عدد المشاهدات المتكررة، ولا تُعرض كضمان لنتيجة عشوائية.
- التعلم يستمر بين جلسات اللعب ولا يُمسح عند إغلاق التطبيق.

## الصلاحيات المطلوبة
- موافقة MediaProjection من أندرويد لالتقاط الشاشة.
- إشعارات Android 13+ لخدمة الالتقاط الأمامية.
- Foreground Service mediaProjection.
- الظهور فوق التطبيقات لعرض النتيجة فوق اللعبة.
- Accessibility لكشف الصفوف المخفية بالسحب عند الطلب.

لا يستطيع التطبيق منح صلاحيات النظام المحمية لنفسه؛ أندرويد سيطلب موافقة المستخدم عند الحاجة.

## البناء
يفضل البناء باستخدام:
- Java 17
- Gradle 8.10.2 عبر `./gradlew`
- Android SDK 35

GitHub Actions يستخدم Gradle Wrapper الموجود في المشروع ويثبت SDK 35 ثم يبني `app-debug.apk`.


## v11 / 6.2.0 — كشف العلامة أولًا
- التصنيف الآن يعتمد على العلامة نفسها: 🟩 = شريط، 🟨 = خزين، دون افتراض ترتيب العناصر.
- تم ضبط كشف العلامات ليتوافق مع حجم العلامة الظاهر فعليًا في لقطات الفيديو.
- تم إزالة شرط المحاذاة الصارم للأعمدة حتى لا تختفي علامة صحيحة بسبب مكانها.
- تم منع التعلم من ربط عدة شرايط بعدة مخازن في لقطة واحدة؛ الربط التلقائي يُسجل فقط عند تغير أخضر واحد وأصفر واحد معًا.
- تم منع احتساب الانتقال مرتين.
- تم تصحيح اسم «درق».
- لا توجد نسبة فوز مخترعة؛ النسب المعروضة هي أدلة مرصودة من المشاهدات السابقة فقط.


## v12 / 6.3.0 — Analytics layer
- Added `Counter`, `HighResolutionTimer`, `TimestampAnalysis`, `TimeSeriesAnalysis`, `StatisticalAnalysis`, `MarkovChainsModel`, and `RtpTrackingAlgorithm` for local, evidence-based analytics.
- Added Java numerical primitives (`NumericalAnalysis`) instead of bundling a Python runtime; this keeps Android builds lightweight while providing NumPy/SciPy-style operations such as diff, dot product, and correlation.
- Added persistent analytics samples to SQLite.
- Added an optional Protobuf telemetry schema for user-owned/exported observations.
- Marker detection no longer assumes four columns or any fixed ordering; the green/yellow badge remains the primary classifier.
- Network interception components such as Scapy/mitmproxy Hybrid Capture, SSL proxying/bypass, and Magisk/LSPosed process hooking are intentionally not included. Those mechanisms would intercept or alter another app's private traffic/process. The project can instead consume telemetry that the user explicitly exports or data observed from the screen.
- gRPC can be added later as a transport for the user-owned telemetry contract without coupling it to game traffic interception.


## v13 / 6.4.0 — Safe telemetry integration boundaries
- Preserved all v12 analytics and marker-first detection code.
- Added `ScapyMitmproxyHybridCaptureAdapter` as an import boundary for normalized, user-exported telemetry only. It does not sniff packets or operate a proxy.
- Added `SslTelemetryBoundary` to make the SSL limitation explicit: no TLS interception, certificate bypass, or CA installation.
- Added `RootHookBoundary` to make the root/hook limitation explicit: no Magisk/LSPosed process injection or hooks.
- Added `ImportedTelemetryRecord` for timestamped, user-owned exported observations.
- These boundaries can feed the existing timestamp/time-series/statistical/Markov analytics without accessing private game traffic or process memory.


## v14.1 / OpenCV + Optical Flow + Screenshots
- Added OpenCV 4.10.0 for local read-only computer vision.
- Added optical-flow analysis between consecutive captured frames to measure visible motion/change.
- Added optional `tools/python_cv/` companion using OpenCV/Pillow for screenshot-only desktop testing.
- PyAutoGUI is deliberately not used for clicks, key presses, drags, game automation, traffic interception, or memory access.
- Existing WebSocket/Traffic/Memory/Frida safety boundaries remain unchanged.

## v20 / 7.2.0 — تدريب الأيقونات من الضغطات الفردية
- تم دمج الفيديو الثاني كمرجع بصري محلي على شكل قصاصات حقيقية للأيقونات + manifest، وليس كفيديو داخل التطبيق.
- الفيديو يوضح نمط الاختبار: اختيار أيقونة واحدة، الانتقال من لوحة الهدايا إلى الغرفة، ثم العودة؛ كما يظهر تمييز الأيقونة المختارة.
- `InteractionReferenceLearner` يتعلم هذا المسار من الشاشة فقط ويحفظ الأيقونة والخلية وحالة الشاشة قبل/بعد الاختبار.
- تم تشديد التعلم التلقائي لعلاقات 🟩/🟨 حتى لا يُعتبر مجرد تغيير صفحة/سحب علاقة صحيحة.
- تم إصلاح قص الأيقونة من موضع العلامة نفسها بدل الاعتماد على إحداثي صف ثابت.
- تم تخفيف تكلفة كشف العلامات مع إبقاء تحقق HSV داخل الكتل الصغيرة لتقليل الإنذارات الكاذبة.

## v31.8 – Live Pattern Analytics

This build is based directly on v31.7 and adds the complete local analytics pipeline around the existing OCR/vision path:
- last-10 chronological history window;
- live OCR numeric pool extraction when labelled values are visible;
- streak and alternating-pattern detection;
- confidence and safety classification;
- persistent base/current amount state for local simulation/display;
- live overlay text through the existing recommendation channel;
- no automatic taps, clicks, submissions, or game control.

The project does not save screen captures as part of the OCR engine.
