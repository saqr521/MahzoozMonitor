package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Analyzer {
    private final TemplateRepository templates;
    private final HistoryDb db;
    private long lastFrameHash = 0;
    private String lastGreenSignature = "";
    private final Map<String,Integer> transitions = new HashMap<>();

    public Analyzer(Context c){templates=new TemplateRepository(c);db=new HistoryDb(c);}

    public synchronized AnalysisResult analyze(Bitmap bmp){
        List<Detector.Marker> g=Detector.findMarkers(bmp,true);
        List<Detector.Marker> y=Detector.findMarkers(bmp,false);
        Collections.sort(g, Comparator.comparingInt(a->a.rect.top*10000+a.rect.left));
        Collections.sort(y, Comparator.comparingInt(a->a.rect.top*10000+a.rect.left));

        List<Detector.Tile> greenItems=new ArrayList<>();
        List<Detector.Tile> yellowItems=new ArrayList<>();
        for(Detector.Marker m:g) greenItems.add(Detector.itemForMarker(bmp,m,templates));
        for(Detector.Marker m:y) yellowItems.add(Detector.itemForMarker(bmp,m,templates));

        // tiles contains all named items; green/yellow lists remain the raw marker lists
        // for compatibility with the existing UI/history schema.
        List<Detector.Tile> tiles=new ArrayList<>();
        tiles.addAll(greenItems); tiles.addAll(yellowItems);
        List<String> relations=buildRelations(greenItems,yellowItems);
        String current=signature(greenItems);
        String recommendation=updateAndRecommend(lastGreenSignature,current);
        lastGreenSignature=current;

        long screenHash=Detector.phash(bmp,new android.graphics.Rect(0,0,bmp.getWidth(),bmp.getHeight()));
        String change=lastFrameHash==0?"بدء الرصد":(Long.bitCount(screenHash^lastFrameHash)>10?"تغير ملحوظ في الشاشة":"");
        lastFrameHash=screenHash;

        float confidence=.45f;
        if(!g.isEmpty()||!y.isEmpty())confidence+=.20f;
        if(!tiles.isEmpty())confidence+=.10f;
        if(!relations.isEmpty())confidence+=.10f;
        if(!recommendation.isEmpty())confidence+=.10f;
        return new AnalysisResult(System.currentTimeMillis(),g,y,tiles,relations,recommendation,change,Math.min(1f,confidence));
    }

    private List<String> buildRelations(List<Detector.Tile> green,List<Detector.Tile> yellow){
        ArrayList<String> out=new ArrayList<>();
        StringBuilder bars=new StringBuilder("الشرايط: ");
        for(int i=0;i<green.size();i++){
            if(i>0)bars.append("، ");
            bars.append(green.get(i).label);
        }
        StringBuilder stock=new StringBuilder("الخزين: ");
        for(int i=0;i<yellow.size();i++){
            if(i>0)stock.append("، ");
            stock.append(yellow.get(i).label);
        }
        if(!green.isEmpty())out.add(bars.toString());
        if(!yellow.isEmpty())out.add(stock.toString());
        // A spatial relation is reported only when the named tiles are genuinely close;
        // we do not invent a gameplay relationship from mere screen proximity.
        for(Detector.Tile g:green){
            Detector.Tile best=null; double bd=Double.MAX_VALUE;
            for(Detector.Tile y:yellow){double d=centerDistance(g.rect,y.rect);if(d<bd){bd=d;best=y;}}
            if(best!=null && bd<170) out.add("ارتباط مكاني: "+g.label+" ← "+best.label);
        }
        return out;
    }

    private String signature(List<Detector.Tile> items){
        if(items.isEmpty())return "";
        StringBuilder s=new StringBuilder();
        for(Detector.Tile t:items)s.append(t.label).append(';');
        return s.toString();
    }

    private String updateAndRecommend(String previous,String current){
        if(previous==null||previous.isEmpty()||current.isEmpty()||previous.equals(current))return "";
        String key=previous+"->"+current;
        transitions.put(key,transitions.containsKey(key)?transitions.get(key)+1:1);
        String prefix=previous+"->"; int total=0,best=0; String bestSig=null;
        for(Map.Entry<String,Integer> e:transitions.entrySet())if(e.getKey().startsWith(prefix)){
            total+=e.getValue(); if(e.getValue()>best){best=e.getValue();bestSig=e.getKey().substring(prefix.length());}
        }
        if(bestSig==null||total==0)return "";
        int pct=Math.round(100f*best/total);
        String next=bestSig.replace(';',' ').trim();
        return "الترشيح الإحصائي التالي: "+next+" — احتمال تاريخي "+pct+"% (من المشاهدات المسجلة، وليس ضمانًا للنتيجة)";
    }

    private static double centerDistance(android.graphics.Rect a,android.graphics.Rect b){
        double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0,bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;
        return Math.hypot(ax-bx,ay-by);
    }
    public void save(AnalysisResult r){db.add(r);} public TemplateRepository templates(){return templates;} public HistoryDb db(){return db;}
}
