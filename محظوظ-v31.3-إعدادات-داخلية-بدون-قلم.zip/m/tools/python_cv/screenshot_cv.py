"""Screenshot-only CV helper. Never sends input to another application."""
from pathlib import Path
import time
import cv2
import numpy as np
from PIL import Image
import pyautogui

OUT = Path("screenshots")
OUT.mkdir(exist_ok=True)

def capture():
    shot = pyautogui.screenshot()
    stamp = time.strftime("%Y%m%d_%H%M%S")
    path = OUT / f"mahzooz_{stamp}.png"
    shot.save(path)
    return path

def optical_flow(previous_path, current_path):
    prev = cv2.imread(str(previous_path), cv2.IMREAD_GRAYSCALE)
    curr = cv2.imread(str(current_path), cv2.IMREAD_GRAYSCALE)
    if prev is None or curr is None:
        raise ValueError("Could not read screenshots")
    prev = cv2.resize(prev, (320, 0))
    curr = cv2.resize(curr, (320, 0))
    flow = cv2.calcOpticalFlowFarneback(prev, curr, None, 0.5, 3, 15, 3, 5, 1.2, 0)
    mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
    return float(np.mean(mag))

if __name__ == "__main__":
    p = capture()
    with Image.open(p) as im:
        print(f"saved {p} | size={im.size}")
