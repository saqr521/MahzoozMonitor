package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class TemplateRepository {
    public static class Entry { String label; long hash; Entry(String l,long h){label=l;hash=h;} }
    public static class Match { public final String label; public final float similarity; Match(String l,float s){label=l;similarity=s;} }
    private final SharedPreferences p;
    private final List<Entry> entries=new ArrayList<>();
    private final Context context;
    public TemplateRepository(Context c){context=c.getApplicationContext();p=c.getSharedPreferences("templates",Context.MODE_PRIVATE);load();}

    private void load(){
        entries.clear();
        String raw=p.getString("data","");
        if(!raw.isEmpty()) for(String s:raw.split("\\n")){String[] a=s.split("\\|",2);if(a.length==2)try{entries.add(new Entry(a[1],Long.parseUnsignedLong(a[0])));}catch(Exception ignored){}}
    }
    private static long parseHash(String s){
        String x=s.startsWith("0x")||s.startsWith("0X")?s.substring(2):s;
        return Long.parseUnsignedLong(x,16);
    }

    private void save(){StringBuilder b=new StringBuilder();for(Entry e:entries)b.append(e.hash).append('|').append(e.label.replace("|","/")).append('\n');p.edit().putString("data",b.toString()).apply();}
    public synchronized void add(String label,long hash){
        if(label==null||label.isEmpty()||"غير معروف".equals(label)||hash==0)return;
        for(Entry e:entries) if(e.label.equals(label)) return;
        entries.add(new Entry(label,hash)); save();
    }
    public synchronized void remember(String label,long hash){ add(label,hash); }
    public synchronized Match best(long hash){
        String best="غير معروف";float score=0;
        for(Entry e:entries){long x=hash^e.hash;int d=Long.bitCount(x);float s=1f-d/64f;if(s>score){score=s;best=e.label;}}
        return new Match(score>=0.62f?best:"غير معروف",score);
    }
    public synchronized int size(){return entries.size();}
}
