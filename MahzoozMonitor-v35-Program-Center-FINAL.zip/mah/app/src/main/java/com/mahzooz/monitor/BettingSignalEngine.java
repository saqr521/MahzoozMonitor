package com.mahzooz.monitor;

import android.content.Context;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Unified local screen analytics. Combines OCR, recent observed history and
 * numeric observations into one neutral statistical indicator. It never
 * clicks, submits, controls the game, or computes a stake/multiplier.
 */
public final class BettingSignalEngine {
    public static final class Signal {
        public final String side;
        public final int confidence;
        public final String safety;
        public final String reason;
        public final String pools;
        public final String history;
        public final String pattern;
        public final String dataQuality;
        public final int martingaleBet;
        public final int martingaleStep;
        public final boolean martingaleEnabled;
        Signal(String side,int confidence,String safety,String reason,String pools,String history,String pattern,String dataQuality,
           int martingaleBet, int martingaleStep, boolean martingaleEnabled){
            this.side=side; this.confidence=confidence; this.safety=safety;
            this.reason=reason; this.pools=pools; this.history=history; this.pattern=pattern;
            this.dataQuality=dataQuality;
            this.martingaleBet=martingaleBet;
            this.martingaleStep=martingaleStep;
            this.martingaleEnabled=martingaleEnabled;
        }
        public String text(){
            StringBuilder s=new StringBuilder();
            s.append("مؤشر التحليل الحالي: ").append(side.isEmpty()?"غير محدد":side).append('\n');
            s.append("درجة الإشارة الإحصائية: ").append(confidence).append("%\n");
            s.append("قوة البيانات: ").append(safety).append('\n');
            if(!dataQuality.isEmpty()) s.append("جودة القراءة: ").append(dataQuality).append('\n');
            if(!pattern.isEmpty()) s.append("النمط: ").append(pattern).append('\n');
            if(!reason.isEmpty()) s.append("العوامل المرصودة: ").append(reason).append('\n');
            if(!history.isEmpty()) s.append("آخر النتائج: ").append(history).append('\n');
            if(!pools.isEmpty()) s.append(pools).append('\n');
            if(martingaleEnabled) {
                s.append("Martingale: المستوى ").append(martingaleStep).append(" | المبلغ المحسوب: ").append(martingaleBet).append("\n");
            }
            s.append("ملاحظة: هذا مؤشر إحصائي وصفي مبني على ما قرأه OCR، وليس ضماناً للنتيجة القادمة.");
            return s.toString().trim();
        }
    }

    private static final Pattern NUM = Pattern.compile("(?<![0-9])([0-9]{1,12}(?:[.,][0-9]{1,3})?)([kKmM]?)");
    private final MartingaleManager martingale;
    public BettingSignalEngine(Context c) { martingale = new MartingaleManager(c); }

    public Signal analyze(List<String> rawHistory, String ocr) {
        List<String> h=clean(rawHistory);
        martingale.observeOcrOutcome(ocr);

        String text=ocr==null?"":ocr;
        String lower=text.toLowerCase(Locale.US);
        long pa=parsePoolNear(lower, new String[]{"dragon","تنين"});
        long pb=parsePoolNear(lower, new String[]{"tiger","نمر"});

        LinkedHashMap<String,Integer> freq=new LinkedHashMap<>();
        for(String x:h) freq.put(x,freq.getOrDefault(x,0)+1);
        String most=""; int mostCount=0;
        for(Map.Entry<String,Integer> e:freq.entrySet()) if(e.getValue()>mostCount){most=e.getKey();mostCount=e.getValue();}

        int streak=0;
        if(!h.isEmpty()){
            streak=1;
            for(int i=h.size()-1;i>0 && h.get(i).equals(h.get(i-1));i--) streak++;
        }
        boolean alt=isAlternating(h);

        ArrayList<String> factors=new ArrayList<>();
        String pattern="";
        int score=0;
        if(streak>=4){ score+=35; pattern="سلسلة متتابعة ×"+streak; factors.add("سلسلة طويلة مرصودة"); }
        else if(streak>=2){ score+=15; pattern="سلسلة قصيرة ×"+streak; factors.add("سلسلة مرصودة"); }
        if(alt){ score+=30; pattern=pattern.isEmpty()?"نمط متبادل":"نمط متبادل + "+pattern; factors.add("تعاقب مرصود"); }
        if(!h.isEmpty() && mostCount>=2){ score+=Math.min(20, mostCount*4); factors.add("تكرار تاريخي"); }
        if(pa>0 && pb>0){
            long high=Math.max(pa,pb), low=Math.min(pa,pb);
            if(low>0){
                double ratio=(double)high/(double)low;
                if(ratio>=3.0){ score+=15; factors.add("فرق كبير في الأرقام المقروءة"); }
                else if(ratio>=1.5){ score+=7; factors.add("فرق متوسط في الأرقام المقروءة"); }
                else factors.add("الأرقام متقاربة");
            }
        }
        score=Math.max(0,Math.min(100,score));
        // The indicator names the strongest currently observed historical label;
        // it is not presented as a prediction or betting instruction.
        String side=most;
        if(side.isEmpty() && !h.isEmpty()) side=h.get(h.size()-1);
        String safety=score>=70?"قوية":score>=40?"متوسطة":"ضعيفة";
        int tokens=(h.size()>0?1:0)+(pa>0?1:0)+(pb>0?1:0);
        String quality=tokens>=3?"مرتفعة":tokens>=2?"متوسطة":"محدودة";
        String pools="";
        if(pa>0||pb>0) pools="الأرقام المقروءة بالـOCR: Dragon="+pa+" | Tiger="+pb;
        String reason=join(factors,"، ");
        String history=join(h," ← ");
        return new Signal(side,score,safety,reason,pools,history,pattern,quality,
                martingale.currentBet(), martingale.step(), martingale.enabled());
    }

    private long parsePoolNear(String text,String[] keys){
        int pos=-1;
        for(String k:keys){ int p=text.indexOf(k); if(p>=0 && (pos<0||p<pos)) pos=p; }
        if(pos<0) return 0;
        int start=Math.max(0,pos-40), end=Math.min(text.length(),pos+180);
        String window=text.substring(start,end).replace('،', ',');
        Matcher m=NUM.matcher(window);
        long best=0;
        while(m.find()){
            try {
                String raw=m.group(1).replace(',', '.');
                double base=Double.parseDouble(raw);
                String suffix=m.group(2);
                double multiplier=("k".equalsIgnoreCase(suffix)) ? 1000.0
                        : ("m".equalsIgnoreCase(suffix) ? 1000000.0 : 1.0);
                long v=Math.round(base*multiplier);
                if(v>best) best=v;
            } catch(Exception ignored){}
        }
        return best;
    }
    private boolean isAlternating(List<String> h){
        if(h.size()<4) return false;
        int start=Math.max(1,h.size()-4);
        for(int i=start;i<h.size();i++) if(h.get(i).equals(h.get(i-1))) return false;
        return true;
    }
    private List<String> clean(List<String> in){
        ArrayList<String> out=new ArrayList<>();
        if(in!=null) for(String x:in) if(x!=null&&!x.trim().isEmpty()) out.add(x.trim());
        if(out.size()>10) return new ArrayList<>(out.subList(out.size()-10,out.size()));
        return out;
    }
    private String join(List<String> v,String sep){StringBuilder b=new StringBuilder();for(int i=0;i<v.size();i++){if(i>0)b.append(sep);b.append(v.get(i));}return b.toString();}
}
