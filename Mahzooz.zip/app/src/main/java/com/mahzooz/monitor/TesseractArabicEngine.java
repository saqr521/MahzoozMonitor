package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Offline Arabic+English OCR fallback. It is fed only the in-memory MediaProjection
 * frame; it never writes screenshots. CI supplies ara/eng traineddata in assets.
 */
public final class TesseractArabicEngine {
    private final Context context;
    private TessBaseAPI api;
    private final AtomicBoolean prepared = new AtomicBoolean(false);
    private volatile boolean available;
    private long lastRun;
    private String lastText = "";

    public TesseractArabicEngine(Context c) { context = c.getApplicationContext(); }

    private synchronized boolean prepare() {
        if (prepared.get()) return available;
        try {
            File base = new File(context.getFilesDir(), "tesseract");
            File tessdata = new File(base, "tessdata");
            if (!tessdata.exists() && !tessdata.mkdirs()) return false;
            copyIfPresent("tessdata/ara.traineddata", new File(tessdata, "ara.traineddata"));
            copyIfPresent("tessdata/eng.traineddata", new File(tessdata, "eng.traineddata"));
            if (!new File(tessdata, "ara.traineddata").isFile() || !new File(tessdata, "eng.traineddata").isFile()) return false;
            api = new TessBaseAPI();
            available = api.init(base.getAbsolutePath(), "ara+eng");
            if (available) {
                api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT);
                try { api.setVariable("user_defined_dpi", "300"); } catch (Throwable ignored2) {}
            }
        } catch (Throwable ignored) {
            available = false;
            if (api != null) { try { api.recycle(); } catch (Throwable ignored2) {} api = null; }
        }
        prepared.set(true);
        return available;
    }

    private void copyIfPresent(String asset, File target) {
        if (target.isFile() && target.length() > 0) return;
        try (InputStream in = context.getAssets().open(asset);
             FileOutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) >= 0) { if (n > 0) out.write(buf, 0, n); }
        } catch (Throwable ignored) { }
    }

    public synchronized String readIfDue(Bitmap bitmap, long now) {
        if (bitmap == null || bitmap.isRecycled() || now - lastRun < 2200L) return "";
        if (!prepare() || api == null) return "";
        lastRun = now;
        Bitmap work = null;
        try {
            int maxW = 1280;
            if (bitmap.getWidth() > maxW) {
                int nh = Math.max(1, Math.round(bitmap.getHeight() * (maxW / (float) bitmap.getWidth())));
                work = Bitmap.createScaledBitmap(bitmap, maxW, nh, true);
            } else {
                work = bitmap;
            }
            api.setImage(work);
            String text = api.getUTF8Text();
            if (text == null) text = "";
            text = OcrSanitizer.clean(text);
            if (!text.isEmpty()) lastText = text;
            return text;
        } catch (Throwable ignored) {
            return "";
        } finally {
            if (work != null && work != bitmap && !work.isRecycled()) work.recycle();
        }
    }

    public synchronized String lastText() { return lastText; }
    public boolean isAvailable() { return available; }

    public synchronized void close() {
        if (api != null) { try { api.recycle(); } catch (Throwable ignored) {} api = null; }
        available = false;
    }
}
