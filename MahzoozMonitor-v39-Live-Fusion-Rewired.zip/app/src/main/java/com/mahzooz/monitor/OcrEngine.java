package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Fused on-device OCR. Full-frame OCR is combined with targeted ROIs so game
 * titles, Arabic room labels and bet/result text are not lost in a busy screen.
 */
public final class OcrEngine {
    private final TextRecognizer recognizer;
    private final OcrFilter filter = new OcrFilter(850L);
    private final StrikeDataFilter strikeFilter = new StrikeDataFilter(3500L);
    private final TesseractArabicEngine tesseract;
    private volatile String lastAcceptedText = "";
    private volatile String lastMlKitText = "";
    private volatile String lastTesseractText = "";

    public OcrEngine(Context context) {
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        tesseract = new TesseractArabicEngine(context);
    }

    public String readIfDue(Bitmap bitmap, long now) {
        if (bitmap == null || bitmap.isRecycled() || !filter.allow(now)) return "";
        try {
            List<Bitmap> regions = regions(bitmap);
            StringBuilder mlAll = new StringBuilder();
            for (Bitmap region : regions) {
                try {
                    InputImage image = InputImage.fromBitmap(region, 0);
                    Text text = Tasks.await(recognizer.process(image), 700L, TimeUnit.MILLISECONDS);
                    String s = OcrSanitizer.clean(text == null ? "" : text.getText());
                    if (!s.isEmpty()) appendUnique(mlAll, s);
                } catch (Throwable ignored) {
                } finally {
                    if (region != bitmap && !region.isRecycled()) region.recycle();
                }
            }
            String ml = OcrSanitizer.clean(mlAll.toString());
            if (!ml.isEmpty()) lastMlKitText = ml;

            // Tesseract is slower, so it runs only on the full frame + game-title ROI.
            String ar = tesseract.readIfDue(bitmap, now);
            if (!ar.isEmpty()) lastTesseractText = ar;

            String merged = merge(ml, ar);
            if (merged.isEmpty()) merged = merge(lastMlKitText, lastTesseractText);
            if (!merged.isEmpty()) {
                int multiplier = StrikeDataFilter.extractMultiplier(merged);
                if (strikeFilter.isNewUniqueStrike(merged, multiplier) || lastAcceptedText.isEmpty()) {
                    lastAcceptedText = merged;
                    return merged;
                }
            }
            return "";
        } catch (Throwable ignored) {
            return "";
        }
    }

    private List<Bitmap> regions(Bitmap src) {
        ArrayList<Bitmap> out = new ArrayList<>();
        out.add(src);
        int w = src.getWidth(), h = src.getHeight();
        // Top room/header region: Arabic room tabs, gift labels and balances.
        out.add(crop(src, 0, 0, w, Math.round(h * 0.46f), 0.85f));
        // Middle/lower game region: title, controls, bet and result text.
        out.add(crop(src, 0, Math.round(h * 0.34f), w, Math.round(h * 0.88f), 1.0f));
        return out;
    }

    private Bitmap crop(Bitmap src, int l, int t, int r, int b, float scale) {
        l = Math.max(0, Math.min(src.getWidth()-1, l));
        t = Math.max(0, Math.min(src.getHeight()-1, t));
        r = Math.max(l+1, Math.min(src.getWidth(), r));
        b = Math.max(t+1, Math.min(src.getHeight(), b));
        Bitmap base = Bitmap.createBitmap(src, l, t, r-l, b-t);
        if (scale == 1f) return base;
        int nw = Math.max(1, Math.round(base.getWidth()*scale));
        int nh = Math.max(1, Math.round(base.getHeight()*scale));
        Bitmap scaled = Bitmap.createScaledBitmap(base, nw, nh, true);
        if (scaled != base && !base.isRecycled()) base.recycle();
        return scaled;
    }

    private void appendUnique(StringBuilder dst, String text) {
        if (text == null || text.trim().isEmpty()) return;
        String normalized = OcrSanitizer.singleLine(text);
        String existing = OcrSanitizer.singleLine(dst.toString());
        if (existing.contains(normalized)) return;
        if (dst.length() > 0) dst.append('\n');
        dst.append(text.trim());
    }

    private String merge(String a, String b) {
        a = a == null ? "" : a.trim(); b = b == null ? "" : b.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        String as = OcrSanitizer.singleLine(a), bs = OcrSanitizer.singleLine(b);
        if (bs.contains(as)) return b;
        if (as.contains(bs)) return a;
        return a + "\n" + b;
    }

    public String lastAcceptedText() { return lastAcceptedText; }
    public String engineStatus() {
        return "MLKit=" + (!lastMlKitText.isEmpty() ? "OK" : "—") +
                " | Tesseract=" + (tesseract.isAvailable() ? "OK" : "غير متاح");
    }

    public void close() {
        try { recognizer.close(); } catch (Throwable ignored) {}
        try { tesseract.close(); } catch (Throwable ignored) {}
    }
}
