package com.mahzooz.monitor;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads visible countdown/timing information only. */
public final class ZeroSecondTimingMonitor {
    public static final class Snapshot {
        public final int seconds;
        public final boolean nearZero;
        public final String text;
        Snapshot(int s,boolean z,String t){seconds=s;nearZero=z;text=t;}
    }
    private static final Pattern P=Pattern.compile("(?iu)(?:countdown|timer|العداد|متبقي|باقي|ثانية|ثواني)\\D{0,12}(\\d{1,3})");
    public Snapshot observe(String ocr){
        String t=ocr==null?"":ocr;
        Matcher m=P.matcher(t); int s=-1;
        while(m.find())try{s=Integer.parseInt(m.group(1));}catch(Exception ignored){}
        boolean z=s>=0&&s<=2;
        String text=s<0?"العداد: غير مقروء":("العداد المرصود: "+s+" ثانية"+(z?" | قرب الصفر — عرض معلومات فقط":""));
        return new Snapshot(s,z,text);
    }
}
