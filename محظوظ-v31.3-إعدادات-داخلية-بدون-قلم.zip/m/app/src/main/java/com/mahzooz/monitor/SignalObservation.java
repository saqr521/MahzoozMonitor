package com.mahzooz.monitor;

/**
 * Normalized, read-only observation at a boundary. This is intentionally limited
 * to signals the monitor can lawfully observe (screen/accessibility or user-exported
 * telemetry). It never reads another process' private memory or bypasses TLS.
 */
public final class SignalObservation {
    public enum Direction { GAME_TO_MONITOR, MONITOR_TO_GAME_INTENT }
    public final long timestampMs;
    public final Direction direction;
    public final String source;
    public final String summary;
    public final float confidence;

    public SignalObservation(long t, Direction d, String s, String text, float c) {
        timestampMs=t; direction=d; source=s; summary=text; confidence=c;
    }
}
