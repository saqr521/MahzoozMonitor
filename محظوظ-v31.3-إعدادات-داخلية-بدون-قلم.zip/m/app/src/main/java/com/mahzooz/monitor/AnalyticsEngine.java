package com.mahzooz.monitor;

import java.util.ArrayDeque;
import java.util.Deque;

/** Central local analytics coordinator. */
public final class AnalyticsEngine {
    private final Counter frameCounter = new Counter();
    private final Counter greenCounter = new Counter();
    private final Counter yellowCounter = new Counter();
    private final MarkovChainsModel markov = new MarkovChainsModel();
    private final RtpTrackingAlgorithm rtp = new RtpTrackingAlgorithm();
    private final Deque<TimeSeriesAnalysis.Sample> recent = new ArrayDeque<>();
    private long lastTimestampMs;
    private long lastElapsedNs;

    public synchronized void record(AnalysisResult r,long timestampMs,long elapsedNs,String previousState,String nextLabel){
        frameCounter.increment();
        greenCounter.add(r.green.size()); yellowCounter.add(r.yellow.size());
        if(previousState!=null&&!previousState.isEmpty()&&nextLabel!=null&&!nextLabel.isEmpty()) markov.observe(previousState,nextLabel);
        recent.addLast(new TimeSeriesAnalysis.Sample(timestampMs,elapsedNs,r.green.size(),r.yellow.size(),r.confidence));
        while(recent.size()>120)recent.removeFirst();
        lastTimestampMs=timestampMs; lastElapsedNs=elapsedNs;
    }
    public synchronized String summary(){
        return "تحليل محلي: عينات="+frameCounter.get()+" | متوسط الفاصل="+
                String.format(java.util.Locale.US,"%.0fms",TimeSeriesAnalysis.meanIntervalMs(new java.util.ArrayList<>(recent)))+
                " | 🟩="+greenCounter.get()+" | 🟨="+yellowCounter.get();
    }
    public Counter frameCounter(){return frameCounter;}
    public MarkovChainsModel markov(){return markov;}
    public RtpTrackingAlgorithm rtp(){return rtp;}
    public synchronized long lastTimestampMs(){return lastTimestampMs;}
    public synchronized long lastElapsedNs(){return lastElapsedNs;}
}
