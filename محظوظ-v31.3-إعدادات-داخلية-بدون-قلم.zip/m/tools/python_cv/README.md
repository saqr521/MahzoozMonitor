# Mahzooz Python CV Companion

Optional desktop/test tooling for screenshots and computer vision.

- OpenCV: image processing + optical flow.
- Pillow: PNG/JPEG inspection and preprocessing.
- PyAutoGUI: **screenshot capture only** in this project. No click, keypress, drag, or game-control automation is included.

The Android app remains the primary monitor and uses MediaProjection. This folder is not used to intercept game traffic or memory.
