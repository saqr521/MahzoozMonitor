
## v36.1 — Taka foreground + movable compact overlay
- Foreground package tracking now comes from the existing Accessibility service.
- Taka package `com.taka.vhgyk` is treated as the active Taka context when it is foreground.
- The floating panel now has a dedicated drag handle and can be moved horizontally/vertically.
- Two-finger pinch continues to resize the complete panel.
- The manual game selector was removed from the floating panel so the visible game profile can switch automatically.
- The panel shows the observed stake when OCR can read it and reports stake changes such as 100 → 1000.
- Internal-game ranking excludes the Mahzooz/Lucky Gifts profile.
- Historical transitions and observed hit plans are displayed as evidence; they are not represented as guaranteed future results.
