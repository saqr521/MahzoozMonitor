package com.mahzooz.monitor;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.view.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private Analyzer analyzer;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        startForeground(11, new Notification.Builder(this, "monitor")
            .setContentTitle("Mahzooz Monitor")
            .setContentText("تحليل الشاشة جارٍ")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build());

        int code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra("data");
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY; }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = dm.widthPixels, h = dm.heightPixels;
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        MediaProjectionManager mpm =
            (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        display = projection.createVirtualDisplay("MahzoozCapture", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

        analyzer = new Analyzer(this);
        reader.setOnImageAvailableListener(r -> {
            if (!busy.compareAndSet(false, true)) return;
            Image image = null;
            try {
                image = r.acquireLatestImage();
                if (image != null) {
                    AnalysisResult result = analyzer.analyze(image);
                    ResultStore.save(this, result);
                }
            } finally {
                if (image != null) image.close();
                busy.set(false);
            }
        }, new Handler(Looper.getMainLooper()));
        return START_STICKY;
    }

    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
            "monitor", "Screen monitor", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public void onDestroy() {
        if (reader != null) reader.close();
        if (display != null) display.release();
        if (projection != null) projection.stop();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
