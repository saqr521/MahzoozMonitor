package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.LinkedHashSet;
import java.util.Set;

/** Stores the user's selected external apps. It does not modify their APKs or private data. */
public final class ProgramLibrary {
    private static final String PREFS = "program_library";
    private static final String KEY_PACKAGES = "packages";
    private final SharedPreferences prefs;

    public ProgramLibrary(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public Set<String> getPackages() {
        return new LinkedHashSet<>(prefs.getStringSet(KEY_PACKAGES, new LinkedHashSet<>()));
    }

    public void add(String packageName) {
        Set<String> s = getPackages();
        s.add(packageName);
        prefs.edit().putStringSet(KEY_PACKAGES, s).apply();
    }

    public void remove(String packageName) {
        Set<String> s = getPackages();
        s.remove(packageName);
        prefs.edit().putStringSet(KEY_PACKAGES, s).apply();
    }
}
