package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/**
 * Paper-training only. It records hypothetical outcomes locally and never
 * submits a wager, clicks the game, or changes the game state.
 */
public final class VirtualBettingMode {
    private static final String PREF = "virtual_training";
    private final SharedPreferences sp;
    private String lastPrediction = "";
    private long lastOutcomeHash = Long.MIN_VALUE;

    public VirtualBettingMode(Context c) {
        sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public boolean enabled() { return sp.getBoolean("enabled", false); }
    public int stake() { return Math.max(1, sp.getInt("stake", 50)); }
    public long balance() { return sp.getLong("balance", 1000L); }
    public int wins() { return sp.getInt("wins", 0); }
    public int losses() { return sp.getInt("losses", 0); }

    public void setEnabled(boolean value) { sp.edit().putBoolean("enabled", value).apply(); }

    public void setStake(int value) {
        sp.edit().putInt("stake", Math.max(1, Math.min(100000, value))).apply();
    }

    public void reset() {
        lastPrediction = "";
        lastOutcomeHash = Long.MIN_VALUE;
        sp.edit().putLong("balance", 1000L).putInt("wins", 0).putInt("losses", 0).apply();
    }

    public void observePrediction(String prediction) {
        if (!enabled() || prediction == null) return;
        String p = prediction.trim();
        if (!p.isEmpty()) lastPrediction = p;
    }

    /**
     * Only explicit outcome words are accepted. A screen change is never
     * treated as a win/loss.
     */
    public void observeOutcome(String ocr) {
        if (!enabled() || lastPrediction.isEmpty() || ocr == null) return;
        String t = ocr.toLowerCase(Locale.US);
        boolean win = containsAny(t, "wins", "winner", "win", "فاز", "الفائز", "مكسب", "نجاح");
        boolean loss = containsAny(t, "loss", "lose", "lost", "خسر", "خسارة", "خساره");
        if (win == loss) return;
        long h = t.hashCode();
        if (h == lastOutcomeHash) return;
        lastOutcomeHash = h;

        long b = balance();
        int s = stake();
        if (win) {
            sp.edit().putLong("balance", b + s).putInt("wins", wins() + 1).apply();
        } else {
            sp.edit().putLong("balance", b - s).putInt("losses", losses() + 1).apply();
        }
        lastPrediction = "";
    }

    public String summary() {
        if (!enabled()) return "التدريب الافتراضي: متوقف";
        return "التدريب الافتراضي: " + balance() + " | ربح " + wins() + " | خسارة " + losses() + " | قيمة افتراضية " + stake();
    }

    private boolean containsAny(String t, String... xs) {
        for (String x : xs) if (t.contains(x)) return true;
        return false;
    }
}
