package com.mahzooz.monitor;

import android.os.Build;
import java.util.Arrays;

/** Hardware capability probe; no privileged access and no game-process hooks. */
public final class HardwareAccelerationManager {
    private final boolean neon;
    private final boolean openCvNative;
    private final boolean renderThread;

    public HardwareAccelerationManager(boolean openCvNative) {
        this.openCvNative = openCvNative;
        this.neon = hasNeon();
        this.renderThread = Build.VERSION.SDK_INT >= 21;
    }

    private boolean hasNeon() {
        try {
            for (String abi : Build.SUPPORTED_ABIS) {
                if (abi != null && (abi.contains("arm64-v8a") || abi.contains("armeabi-v7a"))) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public boolean neonAvailable() { return neon; }
    public boolean openCvNativeAvailable() { return openCvNative; }
    public boolean renderThreadAvailable() { return renderThread; }
    public String summary() {
        return "HW Accel: OpenCV-Native=" + openCvNative +
                " | NEON=" + neon + " | RenderThread=" + renderThread +
                " | ABI=" + Arrays.toString(Build.SUPPORTED_ABIS);
    }
}
