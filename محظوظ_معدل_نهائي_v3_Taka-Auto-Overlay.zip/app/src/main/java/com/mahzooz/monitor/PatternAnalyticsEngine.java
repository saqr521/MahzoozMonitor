package com.mahzooz.monitor;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Local, read-only statistical pattern summary.
 *
 * This class intentionally does NOT generate a gambling recommendation,
 * stake size, loss-recovery multiplier, or "guaranteed" next result.
 * It only describes patterns actually observed on the device.
 */
public final class PatternAnalyticsEngine {

    public static final class Report {
        public final String text;
        public final List<String> recent;
        Report(String text, List<String> recent) {
            this.text = text == null ? "" : text;
            this.recent = recent == null ? Collections.emptyList() : recent;
        }
    }

    private static final Pattern NUMBER = Pattern.compile("(?<!\\d)(\\d{1,9})(?:[,.](\\d{1,2}))?(?!\\d)");

    public Report analyze(List<String> observedLabels, String ocrText) {
        ArrayList<String> history = new ArrayList<>();
        if (observedLabels != null) {
            for (String x : observedLabels) {
                if (x != null && !x.trim().isEmpty()) history.add(x.trim());
            }
        }
        if (history.size() > 10) history = new ArrayList<>(history.subList(history.size() - 10, history.size()));

        StringBuilder out = new StringBuilder();
        out.append("تحليل إحصائي مرصود\n");
        if (history.isEmpty()) {
            out.append("التاريخ: لا توجد 10 نتائج مرصودة بعد.");
        } else {
            out.append("آخر ").append(history.size()).append(": ")
               .append(join(history, " ← ")).append('\n');

            int streak = 1;
            for (int i = history.size() - 1; i > 0; i--) {
                if (history.get(i).equals(history.get(i - 1))) streak++;
                else break;
            }
            if (streak >= 2) {
                out.append("سلسلة مرصودة: ").append(streak)
                   .append(" مرات متتالية لنفس العنصر.\n");
            }

            if (history.size() >= 4) {
                boolean alternating = true;
                for (int i = history.size() - 2; i >= Math.max(1, history.size() - 5); i--) {
                    if (history.get(i).equals(history.get(i - 1))) {
                        alternating = false;
                        break;
                    }
                }
                if (alternating) out.append("نمط متبادل مرصود في آخر 4–5 مشاهدات.\n");
            }
            out.append("ملاحظة: هذا وصف للتاريخ المرصود وليس توقعاً للنتيجة القادمة.");
        }

        String pools = parsePools(ocrText);
        if (!pools.isEmpty()) out.append("\n").append(pools);

        return new Report(out.toString().trim(), history);
    }

    private String parsePools(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        Matcher m = NUMBER.matcher(text);
        ArrayList<String> nums = new ArrayList<>();
        while (m.find() && nums.size() < 8) nums.add(m.group());
        if (nums.size() < 2) return "";
        return "أرقام OCR المرصودة: " + join(nums, " ، ") +
                "\nلا يتم تحويلها إلى توصية أو مبلغ مراهنة.";
    }

    private static String join(List<String> values, String sep) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) b.append(sep);
            b.append(values.get(i));
        }
        return b.toString();
    }
}
