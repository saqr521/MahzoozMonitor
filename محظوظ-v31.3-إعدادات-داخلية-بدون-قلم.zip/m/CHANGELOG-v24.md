# محظوظ v24 — Persistent Play Session Hit Log

- Reworked "سجل اللعب" to store **manual observed hits**, not videos or screenshots.
- Added persistent `play_sessions` table: each monitoring/play run is kept as a separate session.
- Added persistent `play_hits` table: each observed hit stores time, hit number, icon label, confidence, next observed hit, and validation percentage when available.
- Added `play_links` to accumulate observed hit-to-hit sequences without inventing outcomes.
- A new monitoring run starts a new session; an inactivity gap over 30 minutes also starts a new session. Therefore playing again an hour later is stored separately.
- Settings now shows sessions individually, opens each session's hit log, and provides a delete icon for each session.
- Deleting one session removes only that session's hit records; global learning/relations remain intact.
- Existing "مسح كل البيانات" remains available as an explicit manual action.
- No game input automation, no taps, no hooks, no traffic interception.
