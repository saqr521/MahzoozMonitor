package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.Bitmap;
import java.util.*;

public class Analyzer {
    private final TemplateRepository templates;
    private final HistoryDb db;
    private final SystemLearner learner;
    private final AnalyticsEngine analytics;
    private long lastFrameHash = 0;
    private String lastGreenSignature = "";
    private String lastYellowSignature = "";
    private String lastMarkovState = "";
    private final ReadOnlyEventMonitor readOnlyEventMonitor;
    private final WebSocketReadOnlyMonitor webSocketMonitor;
    private final EventCorrelationEngine correlationEngine;
    private final SignalRedundancyRouter signalRouter;
    private final OwnedTrafficMetadataMonitor trafficMetadataMonitor;
    private final SelfMemoryStateMonitor selfMemoryMonitor;
    private final FridaSafetyBoundary fridaBoundary;
    private final ScreenshotAndCvTools cvTools;
    private final ParallelProcessingEngine parallelEngine;
    private final HardwareAccelerationManager hardwareAcceleration;
    private final MultiprocessingBoundary multiprocessingBoundary;
    private final SequenceMemory sequenceMemory;
    private final MultiConditionRuleEngine ruleEngine;
    private final SequentialAprioriAlgorithm apriori;
    private final AtomicState atomicState;
    private final InteractionReferenceLearner interactionLearner;
    private final PrePlayDecisionEngine prePlayDecisionEngine;
    private final HitPlanEngine hitPlanEngine;
    private final PatternAnalyticsEngine patternAnalyticsEngine;
    private final OcrEngine ocrEngine;
    private final BettingSignalEngine bettingSignalEngine;
    private BettingSignalEngine.Signal latestBettingSignal;
    private String latestOverlayOcr = "";
    private String latestVisibleGameName = "";
    private int latestVisibleGameConfidence = 0;
    private boolean latestVisibleGameConfirmed = false;
    private boolean latestRoomScene = false;
    private boolean latestInternalGameScene = false;
    private int latestSceneConfidence = 0;
    private boolean lastTakaVisualEvidence = false;
    private java.util.List<PrePlayDecisionEngine.Decision> latestPrePlayDecisions =
            java.util.Collections.emptyList();
    private final ServerPatternMonitor serverPatternMonitor;
    private final VirtualBettingMode virtualBettingMode;
    private final DeepChainHistoryTracker deepChainTracker;
    private final ObservationalRiskTracker observationalRiskTracker;
    private final GameRouter gameRouter;
    private final DeepChainPatternEngine deepChainPatternEngine;
    private final DynamicRiskStepper dynamicRiskStepper;
    private final ZeroSecondTimingMonitor zeroSecondTimingMonitor;
    private final GameSignalEngine gameSignalEngine;
    // The detected game may change automatically, but the user-facing selection
    // stays where the user left it until the user explicitly changes it.
    private final android.content.SharedPreferences gameSelectionPrefs;
    private GameRouter.GameMode selectedGameMode = GameRouter.GameMode.UNKNOWN;
    // Relation-learning evidence is armed by a selected GREEN strip and is
    // completed only when a later inventory frame actually loses one or more
    // yellow items. This avoids the old reversed/overly-strict one-green/one-yellow rule.
    private String pendingRelationGreen = "";
    private String pendingRelationYellowBaseline = "";
    private long pendingRelationAt = 0L;

    // Filters repeated OCR frames so a real sequence stays consecutive and varied.
    private final ArrayDeque<String> filteredPlaySequence = new ArrayDeque<>();
    private String lastFilteredPlayLabel = "";
    private int lastObservedStake = 0;
    private int previousObservedStake = 0;
    private String latestObservedOutcome = "";
    private String latestObservedPlayLabel = "";
    private long latestObservedPlayAt = 0L;

    public Analyzer(Context c){ templates=new TemplateRepository(c); db=new HistoryDb(c); learner=new SystemLearner(db); analytics=new AnalyticsEngine(); readOnlyEventMonitor=new ReadOnlyEventMonitor(db); webSocketMonitor=new WebSocketReadOnlyMonitor(db); correlationEngine=new EventCorrelationEngine(db); signalRouter=new SignalRedundancyRouter(); trafficMetadataMonitor=new OwnedTrafficMetadataMonitor(db); selfMemoryMonitor=new SelfMemoryStateMonitor(); fridaBoundary=new FridaSafetyBoundary(); cvTools=new ScreenshotAndCvTools(); parallelEngine=new ParallelProcessingEngine(); hardwareAcceleration=new HardwareAccelerationManager(cvTools.openCvAvailable()); multiprocessingBoundary=new MultiprocessingBoundary(); sequenceMemory=new SequenceMemory(120); ruleEngine=new MultiConditionRuleEngine(); apriori=new SequentialAprioriAlgorithm(); atomicState=new AtomicState(); interactionLearner=new InteractionReferenceLearner(); prePlayDecisionEngine=new PrePlayDecisionEngine(); hitPlanEngine=new HitPlanEngine(); patternAnalyticsEngine=new PatternAnalyticsEngine(); ocrEngine=new OcrEngine(c); bettingSignalEngine=new BettingSignalEngine(c); serverPatternMonitor=new ServerPatternMonitor(); virtualBettingMode=new VirtualBettingMode(c); deepChainTracker=new DeepChainHistoryTracker(); observationalRiskTracker=new ObservationalRiskTracker(); gameRouter=new GameRouter(); deepChainPatternEngine=new DeepChainPatternEngine(); dynamicRiskStepper=new DynamicRiskStepper(c); zeroSecondTimingMonitor=new ZeroSecondTimingMonitor(); gameSignalEngine=new GameSignalEngine();
        gameSelectionPrefs=c.getSharedPreferences("game_selection", Context.MODE_PRIVATE);
        String saved=gameSelectionPrefs.getString("selected_mode", GameRouter.GameMode.UNKNOWN.name());
        try { selectedGameMode=GameRouter.GameMode.valueOf(saved); }
        catch (Exception ignored) { selectedGameMode=GameRouter.GameMode.UNKNOWN; }
    }

    public synchronized AnalysisResult analyze(Bitmap bmp){
        final long analysisStartNs = HighResolutionTimer.nowNanos();
        // Per-frame detected mode. The router remains the source of truth; this
        // local value is updated when stronger visual/scene evidence is found
        // later in this frame.
        GameRouter.GameMode gameMode = gameRouter.currentMode();
        final long timestampMs = System.currentTimeMillis();
        atomicState.recordFrame(timestampMs);
        Bitmap visionBmp = cropConfiguredReadRegion(bmp);
        // OCR is deliberately rate-limited independently from frame analysis.
        String freshOcr = OcrSanitizer.clean(ocrEngine.readIfDue(bmp, timestampMs));
        String ocrText = freshOcr.isEmpty() ? OcrSanitizer.clean(ocrEngine.lastAcceptedText()) : freshOcr;
        // Accessibility is a semantic fallback for Taka only. The service is
        // configured to retrieve window content, but its collector reads text
        // only when the foreground package is com.taka.vhgyk.
        String semanticText = ScrollAccessibilityService.isTakaForeground()
                ? OcrSanitizer.clean(ScrollAccessibilityService.currentForegroundText()) : "";
        if (!semanticText.isEmpty()) ocrText = mergeEvidenceText(ocrText, semanticText);
        int observedStake = parseObservedStake(ocrText);
        if (observedStake > 0 && observedStake != lastObservedStake) { previousObservedStake = lastObservedStake; lastObservedStake = observedStake; }
        latestOverlayOcr = ocrText == null ? "" : ocrText;
        latestVisibleGameName = extractVisibleGameName(latestOverlayOcr);
        latestVisibleGameConfidence = gameTitleConfidence(latestVisibleGameName, latestOverlayOcr);
        latestVisibleGameConfirmed = !latestVisibleGameName.isEmpty();

        // Marker detection must not depend exclusively on OCR. On a real device
        // MLKit/Tesseract can temporarily return no text even while the Taka room
        // is clearly visible. In that case the accessibility package identity and
        // the repeated gift-grid geometry are independent evidence sources.
        boolean takaPackageForeground = ScrollAccessibilityService.isTakaForeground();
        boolean roomTextEvidence = hasGiftRoomEvidence(ocrText);
        List<Detector.Marker> rawGreen=Detector.findMarkers(visionBmp,true);
        List<Detector.Marker> rawYellow=Detector.findMarkers(visionBmp,false);
        boolean giftGridEvidence = Detector.looksLikeGiftGrid(rawGreen, rawYellow, visionBmp);
        boolean roomUiEvidence = roomTextEvidence || giftGridEvidence;
        // Do not let the persistent Taka room header ("الكل في الغرفة", "إرسال", ...)
        // turn an internal game frame into a fake Mahzooz inventory.  The old build
        // accepted room text alone, so saturated casino artwork could be counted as
        // green/yellow gift badges and poison the relation database.
        boolean explicitGameTitle = hasKnownInternalGameTitle(ocrText);
        boolean gameControlsEvidence = hasInternalGameControls(ocrText);
        boolean gameFrameEvidence = explicitGameTitle || gameControlsEvidence || looksLikeTakaGameCanvas(visionBmp);
        boolean useGiftMarkers = giftGridEvidence ||
                (roomUiEvidence && !gameFrameEvidence && rawGreen.size() + rawYellow.size() >= 6);
        List<Detector.Marker> g=useGiftMarkers ? rawGreen : new ArrayList<>();
        List<Detector.Marker> y=useGiftMarkers ? rawYellow : new ArrayList<>();
        sortMarkers(g); sortMarkers(y);
        boolean takaVisualEvidence = giftGridEvidence || hasTakaVisualEvidence(ocrText, visionBmp, g, y, roomUiEvidence, latestVisibleGameName);
        boolean takaForeground = takaPackageForeground || takaVisualEvidence;
        lastTakaVisualEvidence = takaForeground;
        ScreenStateDetector.State preliminaryState = ScreenStateDetector.inspect(visionBmp,g,y,ocrText,takaForeground);
        latestRoomScene = preliminaryState != null && preliminaryState.scene != null && preliminaryState.scene.contains("الغرفة/الهدايا");
        latestInternalGameScene = preliminaryState != null && preliminaryState.scene != null && preliminaryState.scene.contains("شاشة لعبة مرئية");
        latestSceneConfidence = preliminaryState == null ? 0 : Math.round(preliminaryState.confidence * 100f);
        if (!latestInternalGameScene) {
            latestVisibleGameConfirmed = false;
            latestVisibleGameName = "";
            latestVisibleGameConfidence = 0;
        }
        // Run the actual router on every frame. The previous revision only called
        // promote() in a couple of fallback branches, leaving the router UNKNOWN
        // for many perfectly readable internal games.
        GameRouter.Fingerprint routed = gameRouter.fingerprint(
                visionBmp, ocrText, semanticText, g.size(), y.size());
        gameMode = routed.mode;

        // Route by the visible scene before trusting generic host words such as
        // "محظوظ".  The Taka room/inventory screen is a different state from
        // an actual internal game frame.
        if (takaForeground && preliminaryState != null) {
            String scene = preliminaryState.scene == null ? "" : preliminaryState.scene;
            if (scene.contains("الغرفة/الهدايا")) {
                gameMode = GameRouter.GameMode.LUCKY_GIFTS;
            } else if (scene.contains("شاشة لعبة مرئية") && gameMode == GameRouter.GameMode.LUCKY_GIFTS) {
                gameMode = GameRouter.GameMode.ARCADE_INSTANT;
            }
        }
        boolean visibleGameFrame = takaForeground && isLikelyTakaGameFrame(ocrText, latestVisibleGameName);
        if (takaForeground && visibleGameFrame && !roomUiEvidence) {
            // A visible title/control cluster is stronger evidence of an internal
            // game than the host-room word "محظوظ". Promote it into the router so
            // GameSignalEngine and the overlay receive the same mode.
            gameMode = modeFromVisibleGame(latestVisibleGameName, ocrText);
            int titleScore = Math.max(78, latestVisibleGameConfidence);
            gameRouter.promote(gameMode, titleScore, "عنوان لعبة مرئي + عناصر تحكم");
        } else if (takaForeground && gameMode == GameRouter.GameMode.UNKNOWN) {
            gameMode = TakaGameKnowledge.modeFromVisibleText(ocrText);
            if (gameMode != GameRouter.GameMode.UNKNOWN) gameRouter.promote(gameMode, 70, "نص لعبة Taka مرئي");
        }

        // Always run tile detection. Markers are badges; the tile below each badge
        // is the actual item name used for the learned relation map.
        // Every colored badge belongs to one inventory icon. Build the tile directly
        // from the badge position; this works for 4-column layouts and for rows that
        // move after a scroll instead of assuming a fixed six-column grid.
        List<Detector.Tile> greenItems=new ArrayList<>();
        for(Detector.Marker m:g) { Detector.Tile t=Detector.itemForMarker(visionBmp,m,templates); greenItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> yellowItems=new ArrayList<>();
        for(Detector.Marker m:y) { Detector.Tile t=Detector.itemForMarker(visionBmp,m,templates); yellowItems.add(t); templates.remember(t.label,t.hash); }

        // The supplied sprite catalog is a visual fallback; when Arabic OCR can
        // read the item names, use the OCR sequence to repair unknown visual
        // matches. This is only enabled on the validated gift-room surface.
        if ((roomUiEvidence || giftGridEvidence) && (!g.isEmpty() || !y.isEmpty())) {
            applyKnownOcrItemLabels(g, greenItems, y, yellowItems, ocrText);
        }

        // Build the user-facing pre-play evidence from the current visible
        // inventory. This is historical evidence only; it does not invent a
        // future result or place a bet.
        ArrayList<Detector.Tile> prePlayCandidates=new ArrayList<>();
        prePlayCandidates.addAll(greenItems);
        prePlayCandidates.addAll(yellowItems);

        List<Detector.Tile> tiles=new ArrayList<>();
        tiles.addAll(greenItems);
        for(Detector.Tile t:yellowItems){
            boolean dup=false;
            for(Detector.Tile e:tiles) if(!e.rect.isEmpty() && !t.rect.isEmpty() && centerDistance(e.rect,t.rect)<20){dup=true;break;}
            if(!dup) tiles.add(t);
        }

        String previousGreenSignature = lastGreenSignature;
        String previousYellowSignature = lastYellowSignature;
        String current=signature(greenItems);
        latestPrePlayDecisions = prePlayDecisionEngine.rank(prePlayCandidates, current, db);
        if (!greenItems.isEmpty()) {
            for (Detector.Tile t : greenItems) {
                if (t != null && t.label != null && !t.label.isEmpty() && !"غير معروف".equals(t.label)) {
                    deepChainTracker.observe(t.label);
                }
            }
        }
        sequenceMemory.observeState(current);
        String currentYellow=signature(yellowItems);
        ScreenStateDetector.State screenState = ScreenStateDetector.inspect(visionBmp,g,y,ocrText,takaForeground);
        boolean inventoryVisible=!tiles.isEmpty() && (!g.isEmpty() || !y.isEmpty());
        InteractionReferenceLearner.Observation interaction=interactionLearner.observe(visionBmp,tiles,inventoryVisible,timestampMs);

        // Arm relation learning from an explicitly selected GREEN strip. The
        // yellow inventory is the baseline; we then wait for an actual visible
        // consumption/removal event instead of assuming that a page transition
        // itself proves a relation.
        String selectedNow = interactionLearner.pendingLabel();
        if (inventoryVisible && selectedNow != null && !selectedNow.isEmpty() &&
                labels(current).contains(selectedNow)) {
            if (!selectedNow.equals(pendingRelationGreen)) {
                pendingRelationGreen = selectedNow;
                pendingRelationYellowBaseline = currentYellow;
                pendingRelationAt = timestampMs;
            }
        }

        if(interaction!=null){
            db.recordInteractionReference(timestampMs,interaction.selectedLabel,interaction.beforeSignature,interaction.afterSignature,interaction.row,interaction.column,interaction.confidence);
            // One completed manual interaction is one real observed hit in the persistent chronological play log.
            // This is history only: the monitor never sends input to the game.
            db.recordPlayHit(interaction.selectedLabel, interaction.confidence, timestampMs);
            // Keep the separate evidence layer for exact observed hit plans; a single test is x1.
            db.observeHitPlan(interaction.selectedLabel,1,"icon-test",interaction.confidence);
            AlgorithmTrace.recordInteractionReference(interaction);
        }
        List<String> relations=buildRelations(greenItems,yellowItems,previousGreenSignature,previousYellowSignature,current,currentYellow,interaction);
        // Stronger live evidence path: selected green -> yellow item(s) visibly
        // disappear while the inventory remains on screen. Learn each consumed
        // yellow item once, and keep the evidence persistent in SQLite.
        if (inventoryVisible && !pendingRelationGreen.isEmpty() &&
                timestampMs - pendingRelationAt <= 12000L &&
                !pendingRelationYellowBaseline.isEmpty()) {
            Set<String> baselineY = labels(pendingRelationYellowBaseline);
            Set<String> nowY = labels(currentYellow);
            Set<String> consumed = new LinkedHashSet<>(baselineY);
            consumed.removeAll(nowY);
            if (!consumed.isEmpty()) {
                for (String yItem : consumed) {
                    db.observeRelation(pendingRelationGreen, yItem);
                    int hits=db.relationHits(pendingRelationGreen,yItem);
                    int total=db.relationTotal(pendingRelationGreen);
                    int pct=total>0?Math.round(100f*hits/total):0;
                    relations.add(""+pendingRelationGreen+" ← "+yItem+" | نسبة الربط المرصودة: "+pct+"% ("+hits+"/"+total+")");
                }
                pendingRelationGreen = "";
                pendingRelationYellowBaseline = "";
                pendingRelationAt = 0L;
            }
        } else if (timestampMs - pendingRelationAt > 12000L) {
            pendingRelationGreen = "";
            pendingRelationYellowBaseline = "";
            pendingRelationAt = 0L;
        }
        String recommendation=updateAndRecommend(previousGreenSignature,current,interaction);
        gameSignalEngine.observe(gameMode, gameRouter.confidence(), ocrText, timestampMs);
        latestBettingSignal = bettingSignalEngine.analyze(filteredRecentPlayLabels(12), ocrText);
        latestObservedOutcome = extractVisibleOutcome(ocrText);
        if (interaction != null && interaction.selectedLabel != null && !interaction.selectedLabel.isEmpty()) {
            latestObservedPlayLabel = interaction.selectedLabel;
            latestObservedPlayAt = timestampMs;
        } else {
            String ocrPlay = extractCurrentKnownItem(ocrText);
            if (!ocrPlay.isEmpty()) { latestObservedPlayLabel = ocrPlay; latestObservedPlayAt = timestampMs; }
        }
        String routerStatus = gameRouter.statusLine();
        String signalDashboard = gameSignalEngine.dashboard();
        if (!signalDashboard.isEmpty()) recommendation = signalDashboard + (recommendation.isEmpty() ? "" : "\n" + recommendation);
        String referenceProfile = TakaReferenceCatalog.profileForText(ocrText);
        if (!"غير محدد".equals(referenceProfile) && gameMode == GameRouter.GameMode.UNKNOWN) {
            routerStatus = routerStatus + " | ملف مرجعي: " + referenceProfile;
        }
        recommendation = routerStatus + (recommendation.isEmpty() ? "" : "\n" + recommendation);
        // Add a neutral, local-only description of the observed history/OCR.
        // It deliberately does not produce a betting side or stake amount.
        PatternAnalyticsEngine.Report patternReport =
                patternAnalyticsEngine.analyze(filteredRecentPlayLabels(10), ocrText);
        if (patternReport != null && !patternReport.text.isEmpty()) {
            recommendation = patternReport.text + (recommendation.isEmpty() ? "" : "\n" + recommendation);
        }
        String nextObserved = firstNewLabel(previousGreenSignature, current);
        if (!nextObserved.isEmpty()) { latestObservedPlayLabel = nextObserved; latestObservedPlayAt = timestampMs; }
        String markovState = observedMarkovState(gameMode, latestVisibleGameName, ocrText, nextObserved);
        String markovPreviousState = lastMarkovState;
        if (!markovState.isEmpty() && !markovState.equals(lastMarkovState)) {
            if (!lastMarkovState.isEmpty()) analytics.markov().observe(lastMarkovState, markovState);
            lastMarkovState = markovState;
        }
        String predictionSource = !ocrText.isEmpty() ? firstRecognizedLabel(ocrText) : nextObserved;
        ServerPatternMonitor.Snapshot serverPattern = serverPatternMonitor.observe(ocrText, predictionSourceSafe(ocrText, nextObserved), timestampMs);
        if (serverPattern != null) recommendation += "\n\n" + serverPattern.format();
        // BettingSignalEngine is kept for compatibility with the existing project,
        // but its wager-direction output is not surfaced by the observational build.
        recommendation += "\n\n" + virtualBettingMode.summary();
        recommendation += "\n" + observationalRiskTracker.summary();

        // Observational replacement for future-chain prediction:
        // show only the last five items that were actually observed.
        recommendation += "\n\n" + deepChainTracker.summary5();
        dynamicRiskStepper.observe(ocrText);
        recommendation += "\n" + dynamicRiskStepper.snapshot().text;
        DeepChainPatternEngine.Report deepReport = deepChainPatternEngine.analyze(deepChainTracker.lastObserved(30));
        if (deepReport != null && !deepReport.text.isEmpty()) recommendation += "\n\n" + deepReport.text;
        ZeroSecondTimingMonitor.Snapshot timing = zeroSecondTimingMonitor.observe(ocrText);
        if (timing != null) recommendation += "\n" + timing.text;
        virtualBettingMode.observeOutcome(ocrText);
        SystemLearner.Snapshot model=learner.update(greenItems, recommendation);
        AlgorithmTrace.recordGameToMonitor(g, y, greenItems, yellowItems, relations);
        if(!recommendation.isEmpty()) AlgorithmTrace.recordMonitorOutput(recommendation);
        lastGreenSignature=current;
        lastYellowSignature=currentYellow;

        float[] channelMeans = parallelEngine.pixelChannelMeans(bmp);
        AlgorithmTrace.recordVisionMetric("Atomic/Bitmask", atomicState.summary() + " | flags=" +
                BitmaskLookupTables.describe(BitmaskLookupTables.mask(!g.isEmpty(), !y.isEmpty(), false, !tiles.isEmpty(), !relations.isEmpty())));
        AlgorithmTrace.recordVisionMetric("Parallel/Vectorized",
                parallelEngine.backendSummary() + " | RGBmean=" + channelMeans[0] + "," + channelMeans[1] + "," + channelMeans[2]);
        AlgorithmTrace.recordVisionMetric("Hardware", hardwareAcceleration.summary());
        AlgorithmTrace.recordVisionMetric("Multiprocessing", multiprocessingBoundary.status() + " | gameProcessHook=" + multiprocessingBoundary.attachesToGameProcess());

        long screenHash=Detector.phash(bmp,new Rect(0,0,bmp.getWidth(),bmp.getHeight()));
        String change=lastFrameHash==0?"بدء الرصد":(Long.bitCount(screenHash^lastFrameHash)>10?"تغير ملحوظ في الشاشة":"");
        lastFrameHash=screenHash;

        float confidence=.35f;
        if(!g.isEmpty()||!y.isEmpty()) confidence+=.20f;
        if(!tiles.isEmpty()) confidence+=.15f;
        if(!relations.isEmpty()) confidence+=.15f;
        if(!recommendation.isEmpty()) confidence+=.05f;
        confidence=Math.min(1f,confidence);
        String coordinates = buildCoordinates(g, y, greenItems, yellowItems, visionBmp.getWidth(), visionBmp.getHeight());
        float opticalFlow = cvTools.opticalFlow(bmp);
        sequenceMemory.observeNumbers(timestampMs, confidence, opticalFlow, greenItems.size(), yellowItems.size());
        if (opticalFlow > 0.35f) confidence = Math.min(1f, confidence + 0.05f);
        AlgorithmTrace.recordVisionMetric("OpenCV", "opticalFlow=" + opticalFlow + " available=" + cvTools.openCvAvailable());
        if(!ocrText.isEmpty()) AlgorithmTrace.recordVisionMetric("OCR", ocrText + " | " + ocrEngine.engineStatus());
        else AlgorithmTrace.recordVisionMetric("OCR", ocrEngine.engineStatus());
        AlgorithmTrace.recordVisionMetric("matchTemplate", "available=" + cvTools.openCvAvailable() + " | thresholded local template matching ready");
        AlgorithmTrace.recordVisionMetric("SequenceMemory", sequenceMemory.summary());
        AlgorithmTrace.recordVisionMetric("IconInteractionTraining", interactionLearner.status() + " | DB=" + db.interactionReferenceCount());
        List<GridMappingAnalysis.Cell> gridCells=GridMappingAnalysis.map(tiles);
        AlgorithmTrace.recordVisionMetric("GridMapping", GridMappingAnalysis.summary(gridCells));
        List<MultiConditionRuleEngine.Match> ruleMatches=ruleEngine.evaluate(greenItems,yellowItems,confidence,opticalFlow);
        if(!ruleMatches.isEmpty()) {
            StringBuilder rb=new StringBuilder();
            for(MultiConditionRuleEngine.Match m:ruleMatches){if(rb.length()>0) rb.append(" | "); rb.append(m.rule).append(": ").append(m.explanation);}
            AlgorithmTrace.recordVisionMetric("MultiConditionRules", rb.toString());
        }
        List<SequentialAprioriAlgorithm.Pattern> patterns=apriori.mine(sequenceMemory.recentStates(120),3,2,5);
        AlgorithmTrace.recordVisionMetric("SequentialApriori", SequentialAprioriAlgorithm.format(patterns));
        // Wire the Markov model into the same observed transition stream used by the persistent DB.
        if (!markovState.isEmpty()) {
            java.util.List<String> markov = analytics.markov().rank(markovPreviousState, 3);
            if (!markov.isEmpty()) {
                recommendation = recommendation + (recommendation.isEmpty() ? "" : "\n") +
                        "انتقالات Markov المرصودة: " + String.join(" ؛ ", markov);
            }
        }
        AnalysisResult.Prediction observedPrediction = predictFromHistory(nextObserved);
        if (observedPrediction != null && observedPrediction.confidencePercentage > 0 && !nextObserved.isEmpty()) {
            recommendation = recommendation + (recommendation.isEmpty() ? "" : "\n") +
                    "تحليل التسلسل المرصود: " + observedPrediction.predictedGift + " — " +
                    observedPrediction.confidencePercentage + "% من السجل السابق";
        }
        AlgorithmTrace.recordScreenState(screenState);
        List<ReadOnlyEventMonitor.Event> readOnlyEvents = readOnlyEventMonitor.observe(greenItems, yellowItems, screenState, timestampMs);
        correlationEngine.correlate(timestampMs, screenState.scene + "/" + screenState.lockState, readOnlyEvents);
        AnalysisResult result = new AnalysisResult(timestampMs,g,y,tiles,relations,recommendation,change,confidence,coordinates,screenState,ocrText);
        long elapsedNs = HighResolutionTimer.elapsedNanos(analysisStartNs);
        analytics.record(result,timestampMs,elapsedNs,previousGreenSignature,nextObserved);
        db.addAnalyticsSample(timestampMs,elapsedNs,g.size(),y.size(),confidence);
        if (visionBmp != bmp && visionBmp != null && !visionBmp.isRecycled()) visionBmp.recycle();
        return result;
    }

    private Bitmap cropConfiguredReadRegion(Bitmap source) {
        if (source == null || source.isRecycled()) return source;
        if (!gameSelectionPrefs.getBoolean("read_region_enabled", false)) return source;
        float l=gameSelectionPrefs.getFloat("read_region_left",0f);
        float t=gameSelectionPrefs.getFloat("read_region_top",0f);
        float r=gameSelectionPrefs.getFloat("read_region_right",1f);
        float b=gameSelectionPrefs.getFloat("read_region_bottom",1f);
        int left=Math.max(0,Math.min(source.getWidth()-1,Math.round(l*source.getWidth())));
        int top=Math.max(0,Math.min(source.getHeight()-1,Math.round(t*source.getHeight())));
        int right=Math.max(left+1,Math.min(source.getWidth(),Math.round(r*source.getWidth())));
        int bottom=Math.max(top+1,Math.min(source.getHeight(),Math.round(b*source.getHeight())));
        if(right-left<80 || bottom-top<80) return source;
        try { return Bitmap.createBitmap(source,left,top,right-left,bottom-top); }
        catch(Throwable ignored){ return source; }
    }

    private String extractCurrentKnownItem(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String one = OcrSanitizer.singleLine(text);
        for (String label : TemplateRepository.knownLabels()) {
            if (label != null && !label.isEmpty() && one.contains(label)) return label;
        }
        return "";
    }

    private String extractVisibleOutcome(String text) {
        if (text == null) return "";
        String t=text.toLowerCase(Locale.ROOT);
        if (containsAnyText(t,new String[]{"win","won","winner","فوز","فاز","رابح","ربح"})) return "فوز ظاهر";
        if (containsAnyText(t,new String[]{"loss","lose","lost","خسارة","خسر","خاسر"})) return "خسارة ظاهرة";
        return "";
    }

    private String observedMarkovState(GameRouter.GameMode mode, String visibleTitle, String ocr, String nextObserved) {
        if (visibleTitle != null && !visibleTitle.trim().isEmpty()) return visibleTitle.trim();
        if (nextObserved != null && !nextObserved.trim().isEmpty()) return nextObserved.trim();
        if (ocr != null && !ocr.trim().isEmpty()) {
            String label = firstRecognizedLabel(ocr);
            if (label != null && !label.trim().isEmpty()) return label.trim();
        }
        if (mode != null && mode != GameRouter.GameMode.UNKNOWN) return gameModeName(mode);
        return "";
    }

    private String mergeEvidenceText(String a, String b) {
        a = a == null ? "" : a.trim(); b = b == null ? "" : b.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        String as=OcrSanitizer.singleLine(a), bs=OcrSanitizer.singleLine(b);
        if (as.contains(bs)) return a;
        if (bs.contains(as)) return b;
        return a + "\n" + b;
    }

    private String predictionSourceSafe(String ocrText, String nextObserved) {
        if (ocrText != null && !ocrText.trim().isEmpty()) return firstRecognizedLabel(ocrText);
        return nextObserved == null ? "" : nextObserved;
    }

    public String foregroundPackageName() {
        return ScrollAccessibilityService.currentForegroundPackage();
    }

    public boolean isTakaForeground() { return ScrollAccessibilityService.isTakaForeground() || lastTakaVisualEvidence; }

    public int observedStake() { return lastObservedStake; }

    private int parseObservedStake(String ocr) {
        if (ocr == null || ocr.isEmpty()) return 0;
        String t = ocr.toLowerCase(Locale.ROOT).replace('،', ',')
                .replace('٠','0').replace('١','1').replace('٢','2').replace('٣','3').replace('٤','4')
                .replace('٥','5').replace('٦','6').replace('٧','7').replace('٨','8').replace('٩','9');
        String[] keys = {"إجمالي الرهان", "اجمالي الرهان", "الرهان", "bet", "stake", "total bet", "coins"};
        int pos = -1;
        for (String k : keys) { int x=t.indexOf(k.toLowerCase(Locale.ROOT)); if (x>=0 && (pos<0 || x<pos)) pos=x; }
        if (pos < 0) return 0;
        int start=Math.max(0,pos-20), end=Math.min(t.length(),pos+100);
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<![0-9])([0-9]{1,7})(?:\\.0+)?(?![0-9])").matcher(t.substring(start,end));
        int best=0;
        while(m.find()){ try { int v=Integer.parseInt(m.group(1)); if(v>0 && v<=1000000) best=Math.max(best,v); } catch(Exception ignored){} }
        return best;
    }

    public void close() { try { ocrEngine.close(); } catch (Throwable ignored) {} }
    public String systemScreenIndicators(String ocr) {
        String t = ocr == null ? "" : ocr.toLowerCase(Locale.ROOT);
        int mah = keywordConfidence(t, new String[]{"محظوظ", "mahzooz", "هدايا"});
        int income = keywordConfidence(t, new String[]{"الدخل", "income", "revenue", "earnings"});
        GameRouter.GameMode mode = gameRouter.currentMode();
        int route = gameRouter.confidence();

        if (mode == GameRouter.GameMode.LUCKY_GIFTS) {
            mah = Math.max(mah, route);
        } else if (mode != GameRouter.GameMode.UNKNOWN) {
            income = Math.max(income, route);
        }

        StringBuilder b = new StringBuilder();
        b.append("رصد محظوظ: ").append(mah).append("%\n");
        b.append("رصد الدخل/الألعاب: ").append(income).append("%\n");
        b.append("النسب هنا قوة تعرّف/رصد وليست احتمال ربح أو ضمان نتيجة.\n");
        return b.toString().trim();
    }

    /**
     * Dynamic game-specific overlay. It follows the game actually visible on the
     * captured screen, while the user's manual selection remains independent.
     * No game icons or fixed visual templates are injected into the overlay.
     */
    public String compactLivePanel() {
        GameRouter.GameMode detectedMode = gameRouter.currentMode();
        // Automatic detection remains visible in the header, but the detailed
        // panel follows the user's persisted manual selection when one exists.
        // This prevents a noisy frame from changing the user's selected area.
        GameRouter.GameMode mode = selectedGameMode == GameRouter.GameMode.UNKNOWN
                ? detectedMode : selectedGameMode;
        boolean taka = isTakaForeground();
        if (!taka) return "لم تثبت واجهة Taka بعد\nالتقاط الشاشة يعمل — في انتظار دليل مرئي.";

        StringBuilder b = new StringBuilder();
        b.append("الحالة الآن: " ).append(mode == GameRouter.GameMode.LUCKY_GIFTS ? "محظوظ / غرفة" :
                (mode == GameRouter.GameMode.UNKNOWN ? "غير محسومة" : "لعبة داخلية")).append('\n');
        int frameConfidence = latestInternalGameScene ? internalRecognitionConfidence() : (latestRoomScene ? mahzoozRecognitionConfidence() : 0);
        b.append("اللعبة الحالية: " ).append(currentGameModeName()).append(" | قوة التعرف: ").append(frameConfidence).append("%\n");
        b.append("الاختيار اليدوي: " ).append(selectedGameModeName()).append("\n");
        b.append("الضربة الحالية: ").append(latestObservedPlayLabel.isEmpty() ? "غير مقروءة بعد" : latestObservedPlayLabel).append('\n');
        if (!latestObservedOutcome.isEmpty()) b.append("النتيجة الظاهرة الآن: ").append(latestObservedOutcome).append('\n');
        if (lastObservedStake > 0) b.append("الرهان الظاهر الآن: ").append(lastObservedStake).append(" كوينز\n");
        if (latestBettingSignal != null && latestBettingSignal.side != null && !latestBettingSignal.side.isEmpty()) {
            b.append("الإشارة من السجل المرصود: ").append(latestBettingSignal.side)
             .append(" | ").append(latestBettingSignal.confidence).append("%\n");
            b.append("الضربة المرشحة من السجل: ").append(latestBettingSignal.side).append("\n");
        } else {
            b.append("الإشارة الحالية: لا توجد بيانات كافية\n");
        }
        b.append("محرك القراءة: ").append(ocrEngine.engineStatus()).append('\n');


        if (mode == GameRouter.GameMode.LUCKY_GIFTS) {
            b.append("محظوظ — الترابط المرصود\n");
            appendMahzoozRelations(b);
            String hitsPanel = bestObservedHitsPanel(gameSignalEngine.currentSignal());
            if (!hitsPanel.isEmpty()) b.append("\n\n").append(hitsPanel);
            b.append("\nملاحظة: النسب هنا ترابطات تاريخية مرصودة، وليست احتمال ربح مضمون.");
        } else if (mode != GameRouter.GameMode.UNKNOWN) {
            String subtype = detectInternalSubtype(latestOverlayOcr, latestBettingSignal == null ? "" : latestBettingSignal.side);
            b.append("الدخل — اللعبة الداخلية: " ).append(subtype).append('\n');
            if (lastObservedStake > 0) {
                b.append("الرهان الظاهر على الشاشة: " ).append(lastObservedStake).append(" كوينز\n");
            } else {
                b.append("الرهان الظاهر على الشاشة: غير مقروء\n");
            }
            appendObservedRows(b, 5);
            if (!latestObservedPlayLabel.isEmpty()) {
                AnalysisResult.Prediction p = predictFromHistory(latestObservedPlayLabel);
                if (p != null && !p.predictedGift.isEmpty()) {
                    b.append("\nالضربة التالية من السجل المرصود: ").append(p.predictedGift)
                     .append(" | ").append(p.confidencePercentage).append("%\n");
                }
            }
            GameSignalEngine.Signal cur = gameSignalEngine.currentSignal();
            GameSignalEngine.Signal alt = gameSignalEngine.strongestInternal();
            if (cur.mode != GameRouter.GameMode.UNKNOWN && alt.mode != GameRouter.GameMode.UNKNOWN &&
                    alt.mode != cur.mode && alt.score >= cur.score + 15 && cur.score < 55) {
                b.append("\nمؤشر ضعف اللعبة الحالية: " ).append(cur.score).append("%");
                b.append(" | لعبة داخلية أخرى مرصودة: " ).append(alt.name).append(" — " ).append(alt.score).append("%");
                b.append("\nهذا مؤشر للمراجعة فقط؛ لا يعني أن الضربة القادمة خسارة.");
            }
        } else {
            b.append("لم تثبت شاشة لعبة بعد — لن أعرض رهانًا أو نتيجة غير مقروءة.");
        }
        return b.toString().trim();
    }

    private void appendMahzoozRelations(StringBuilder b) {
        if (latestPrePlayDecisions == null || latestPrePlayDecisions.isEmpty()) {
            b.append("لا توجد بيانات تاريخية كافية لترتيب ضربة الآن.\n");
            b.append("الحلقة البصرية تعمل؛ اجعل عدة دورات/اختبارات مرئية حتى يبني البرنامج سجل العلاقات.\n");
            return;
        }
        b.append("الأولوية المرصودة الآن (اختيارات مبنية على السجل):\n");
        int shown=0;
        for (PrePlayDecisionEngine.Decision d : latestPrePlayDecisions) {
            if (d == null || d.label == null || d.label.isEmpty()) continue;
            b.append(shown+1).append(") ").append(d.label)
             .append(" — ").append(d.scorePct).append("% دليل");
            if (d.transitionTotal > 0) b.append(" | تسلسل ").append(d.transitionHits).append('/').append(d.transitionTotal);
            if (d.relationTotal > 0) b.append(" | ربط ").append(d.relationHits).append('/').append(d.relationTotal);
            if (d.observedTests > 0) b.append(" | اختبارات ").append(d.observedTests);
            b.append('\n');
            java.util.List<String> rel = db.relationsFor(d.label, 3);
            for (String row : rel) {
                String[] parts=row.split("\\|",-1);
                if (parts.length >= 3) b.append("   ← ").append(parts[0]).append(" | ").append(parts[1]).append("% | ").append(parts[2]).append('\n');
            }
            shown++;
            if (shown>=5) break;
        }
        b.append("\nهذه أولوية إحصائية من المشاهدات السابقة وليست ضماناً للفوز القادم.");
    }

    private void appendObservedRows(StringBuilder b, int max) {
        int shown = 0;
        if (latestPrePlayDecisions != null) {
            for (PrePlayDecisionEngine.Decision d : latestPrePlayDecisions) {
                if (d == null || d.label == null || d.label.trim().isEmpty() || !d.hasEvidence) continue;
                shown++;
                b.append(d.line(shown));
                HitPlanEngine.Plan hp = hitPlanEngine.best(d.label, db);
                if (hp != null) b.append(" | مشاهدات الخطة ").append(hp.observations);
                b.append('\n');
                if (shown >= max) break;
            }
        }
        if (shown == 0) {
            b.append("لا توجد نتائج تاريخية كافية للعنصر المرصود حتى الآن.\n");
        }
        b.append("\nالنسب = نتائج فعلية مسجلة في البرنامج، وليست ضمانًا للنتيجة القادمة.");
    }

    private String detectInternalSubtype(String screenText, String signalText) {
        String t = ((screenText == null ? "" : screenText) + " " +
                (signalText == null ? "" : signalText)).toLowerCase(Locale.ROOT);
        if (containsAnyText(t, new String[]{"فواكه", "fruit", "cherry", "lemon", "watermelon", "grape", "كرز", "ليمون", "بطيخ", "عنب"})) return "فواكه";
        if (containsAnyText(t, new String[]{"دوران", "spin", "wheel", "roulette", "لف", "عجلة"})) return "تدوير/عجلة";
        if (containsAnyText(t, new String[]{"نرد", "dice", "sicbo", "سيكبو"})) return "نرد/سيكبو";
        if (containsAnyText(t, new String[]{"بطاقات", "cards", "baccarat", "باكارات", "poker", "بوكر"})) return "بطاقات";
        return "واجهة داخلية عامة";
    }

    private boolean containsAnyText(String t, String[] values) {
        if (t == null) return false;
        for (String v : values) if (v != null && !v.isEmpty() && t.contains(v.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    /** Internal dashboard keeps raw evidence out of the floating execution panel. */
    public String internalGameDashboard() {
        StringBuilder b = new StringBuilder();
        GameSignalEngine.Signal detected = gameSignalEngine.currentSignal();
        GameSignalEngine.Signal selected = selectedGameMode == GameRouter.GameMode.UNKNOWN
                ? detected : gameSignalEngine.signalFor(selectedGameMode);

        b.append("الرصد التلقائي\n");
        b.append("المفتوح على الشاشة: ").append(detected.name)
         .append(" | ").append(detected.score).append("%\n");
        b.append("الاختيار اليدوي: ")
         .append(selectedGameMode == GameRouter.GameMode.UNKNOWN ? "غير مثبت" : selected.name)
         .append("\n\n");

        java.util.List<GameSignalEngine.Signal> signals = gameSignalEngine.ranking(8);
        if (signals.isEmpty()) {
            b.append("لا توجد أنظمة مرصودة بعد.");
        } else {
            b.append("الأنظمة التي رصدها البرنامج:\n");
            for (GameSignalEngine.Signal s : signals) {
                b.append("• ").append(s.name).append(" — ").append(s.score).append("%");
                if (s.mode == detected.mode) b.append(" — مفتوح على الشاشة");
                if (s.mode == selectedGameMode) b.append(" — اختيارك");
                b.append(" — ").append(s.status).append("\n");
            }
        }

        String hitsPanel=bestObservedHitsPanel(detected);
        if (!hitsPanel.isEmpty()) b.append("\n").append(hitsPanel).append("\n");

        if (latestBettingSignal != null) {
            b.append("\nآخر إشارة مرصودة: ")
             .append(latestBettingSignal.side == null || latestBettingSignal.side.isEmpty()
                     ? "غير محددة" : latestBettingSignal.side)
             .append(" | ").append(latestBettingSignal.confidence).append("%\n");
            if (latestBettingSignal.martingaleEnabled) {
                b.append("الرهان الافتراضي الحالي: ").append(latestBettingSignal.martingaleBet)
                 .append(" | خطوة ").append(latestBettingSignal.martingaleStep).append("\n");
            }
        }

        b.append("\nOCR والعلاقات والتاريخ الكامل محفوظة داخل البرنامج ولا تُعرض في اللوحة العائمة.");
        return b.toString().trim();
    }

    public GameRouter.GameMode selectedGameMode() { return selectedGameMode; }

    public String selectedGameModeName() {
        if (selectedGameMode == GameRouter.GameMode.UNKNOWN) return "غير مثبت";
        return gameModeName(selectedGameMode);
    }

    public void selectGameMode(GameRouter.GameMode mode) {
        if (mode == null || mode == GameRouter.GameMode.UNKNOWN) return;
        selectedGameMode = mode;
        gameSelectionPrefs.edit().putString("selected_mode", mode.name()).apply();
    }

    public void clearSelectedGameMode() {
        selectedGameMode = GameRouter.GameMode.UNKNOWN;
        gameSelectionPrefs.edit().putString("selected_mode", GameRouter.GameMode.UNKNOWN.name()).apply();
    }

    public String cycleSelectedGameMode() {
        java.util.List<GameSignalEngine.Signal> list = gameSignalEngine.ranking(8);
        if (list.isEmpty()) return selectedGameModeName();
        int idx=-1;
        for (int i=0;i<list.size();i++) if (list.get(i).mode == selectedGameMode) { idx=i; break; }
        int next=(idx+1)%list.size();
        selectGameMode(list.get(next).mode);
        return selectedGameModeName();
    }

    private String gameModeName(GameRouter.GameMode mode) {
        switch (mode) {
            case LUCKY_GIFTS: return "هدايا المحظوظ";
            case DRAGON_TIGER: return "التنين والنمر";
            case BACCARAT: return "باكارات";
            case POKER: return "بوكر / تكساس";
            case CARD_GAMES: return "ألعاب الورق";
            case DICE_GAMES: case DICE_GAME: return "النرد / سيكبو / لودو";
            case ROULETTE: case WHEEL_ROULETTE: return "العجلة / الروليت";
            case CRASH_GAMES: case CRASH_GAME: return "كراش / مضاعف";
            case TABLE_GAMES: return "ألعاب الطاولة";
            case ARCADE_INSTANT: return "ألعاب فورية";
            case SPORTS_GAMES: return "ألعاب رياضية";
            default: return "غير محدد";
        }
    }

    private String bestObservedHitsPanel(GameSignalEngine.Signal detected) {
        if (latestPrePlayDecisions == null || latestPrePlayDecisions.isEmpty()) return "";
        if (selectedGameMode != GameRouter.GameMode.UNKNOWN && selectedGameMode != detected.mode) return "";

        StringBuilder b=new StringBuilder();
        int n=Math.min(3, latestPrePlayDecisions.size());
        b.append("أقوى الضربات/العناصر المرصودة:\n");
        for (int i=0;i<n;i++) {
            PrePlayDecisionEngine.Decision d=latestPrePlayDecisions.get(i);
            b.append(i+1).append(") ").append(d.label)
             .append(" — قوة الدليل ").append(d.scorePct).append("%");
            HitPlanEngine.Plan hp=hitPlanEngine.best(d.label, db);
            if (hp != null) {
                b.append(" | خطة مرصودة ×").append(hp.hits)
                 .append(" | ").append(hp.confidencePct).append("%");
            }
            if (d.transitionTotal > 0) {
                b.append(" | بعدها: ");
                java.util.List<String> tr = db.rankedTransitions(d.label, 3);
                for (int j=0;j<tr.size();j++) {
                    String[] p = tr.get(j).split("\\|", -1);
                    if (p.length >= 3) {
                        if (j>0) b.append(" / ");
                        b.append(p[0]).append(" ").append(p[1]).append("%");
                    }
                }
            }
            if (d.relationTotal > 0) {
                b.append(" | ربط ").append(d.relationHits).append("/").append(d.relationTotal);
            }
            b.append('\n');
        }
        b.append("النسب المعروضة تاريخية/مرصودة من بيانات البرنامج، وليست ضمانًا للنتيجة القادمة.");
        return b.toString().trim();
    }

    private int keywordConfidence(String t, String[] keys) {
        if (t == null || t.isEmpty()) return 0;
        int hits = 0;
        for (String k : keys) if (t.contains(k.toLowerCase(Locale.ROOT))) hits++;
        return Math.min(100, hits * 50);
    }

    public String readRegionStatus() {
        if (!gameSelectionPrefs.getBoolean("read_region_enabled", false)) return "الشاشة كاملة";
        return "منطقة مخصصة";
    }

    public GameRouter.GameMode currentGameMode() { return gameRouter.currentMode(); }
    public String currentGameModeName() {
        if (!latestVisibleGameConfirmed) return "غير محددة";
        return !latestVisibleGameName.isEmpty() ? latestVisibleGameName : gameRouter.displayName();
    }

    public String visibleGameName() { return latestVisibleGameConfirmed ? latestVisibleGameName : ""; }
    public int visibleGameConfidence() { return latestVisibleGameConfirmed ? latestVisibleGameConfidence : 0; }

    /** Current-frame recognition only; historical signal scores are intentionally excluded. */
    public int mahzoozRecognitionConfidence() {
        if (!isTakaForeground() || !latestRoomScene) return 0;
        return latestSceneConfidence;
    }

    /** Current-frame recognition only; historical signal scores are intentionally excluded. */
    public int internalRecognitionConfidence() {
        if (!isTakaForeground() || !latestInternalGameScene || gameRouter.currentMode() == GameRouter.GameMode.LUCKY_GIFTS) return 0;
        return Math.max(latestSceneConfidence, gameRouter.confidence());
    }

    public boolean hasConfirmedInternalGame() {
        return internalRecognitionConfidence() >= 55 && latestVisibleGameConfirmed;
    }

    private boolean isLikelyTakaGameFrame(String ocr, String title) {
        if (ocr == null) return false;
        String t = ocr.toLowerCase(Locale.ROOT);
        boolean controls = hasInternalGameControls(t);
        boolean room = containsAnyText(t, new String[]{
                "إرسال", "ارسال", "الغرفة", "الكل في الغرفة", "تصنيف", "حقيبة", "خصم 70%"});
        // A known game title is stronger than the room header because Taka keeps
        // room UI visible around the embedded game.
        if (title != null && !title.trim().isEmpty()) return true;
        if (hasKnownInternalGameTitle(t)) return true;
        return !room && controls;
    }

    private boolean hasInternalGameControls(String text) {
        if (text == null) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return containsAnyText(t, new String[]{
                "win", "bet", "stake", "total bet", "spin", "play", "cash out",
                "الرهان", "الرهان الكلي", "فوز", "تدوير", "اضغط للعب", "الخطوط", "التكلفة"});
    }

    private boolean hasKnownInternalGameTitle(String text) {
        if (text == null || text.trim().isEmpty()) return false;
        String t = text.toLowerCase(Locale.ROOT);
        return containsAnyText(t, new String[]{
                "jungle hunt", "ocean hunt", "sphinx magic", "sphinx", "magic",
                "aztec", "azat", "lucky wheel", "luckywheel"
        });
    }

    private String extractVisibleGameName(String ocr) {
        if (ocr == null || ocr.trim().isEmpty()) return "";

        // Canonical titles are checked before generic line parsing. Taka often
        // renders the room header and jackpot numbers in the same OCR block.
        String oneLine = OcrSanitizer.singleLine(ocr).toLowerCase(Locale.ROOT);
        String[][] known = new String[][]{
                {"jungle hunt", "Jungle Hunt"},
                {"ocean hunt", "Ocean Hunt"},
                {"sphinx magic", "Sphinx Magic"},
                {"sphinx", "Sphinx Magic"},
                {"lucky wheel", "Lucky Wheel"}
        };
        for (String[] pair : known) {
            if (oneLine.contains(pair[0])) return pair[1];
        }

        String[] lines = ocr.replace('\r','\n').split("\n+");
        String best = "";
        for (String raw : lines) {
            String line = raw.trim().replaceAll("[ \\t]+", " ");
            if (line.length() < 4 || line.length() > 70) continue;
            String low = line.toLowerCase(Locale.ROOT);
            if (containsAnyText(low, new String[]{
                    "محظوظ", "الدخل", "الغرفة", "إرسال", "ارسال", "الرهان", "win", "bet",
                    "stake", "coins", "أهلا", "اهلا", "تصنيف", "هدايا", "game"})) continue;
            java.util.regex.Matcher latin = java.util.regex.Pattern.compile("[a-zA-Z]{2,}").matcher(line);
            int words=0;
            while (latin.find()) words++;
            if (words >= 2 && line.length() > best.length()) best=line;
        }
        return best;
    }


    /**
     * Taka routing fallback: accessibility package is preferred, but the monitor must
     * still work when Android does not emit the package event. It requires multiple
     * independent visual/text cues before claiming Taka is on screen.
     */
    private boolean hasTakaVisualEvidence(String text, Bitmap bmp, List<Detector.Marker> green, List<Detector.Marker> yellow, boolean roomUiEvidence, String title) {
        String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
        int cues = 0;
        if (containsAnyText(t, new String[]{"taka", "محظوظ", "المحظوظ", "في الغرفة", "الكل في الغرفة", "إرسال", "ارسال", "تصنيف", "هدايا", "lucky", "الحقيبة", "أكثر شعبية", "الحدث", "فخم", "svip"})) cues++;
        if (containsAnyText(t, new String[]{"bet", "stake", "total bet", "win", "spin", "game", "لعبة", "الرهان", "فوز", "coins"})) cues++;
        if (TakaGameKnowledge.hasVerifiedWheelEvidence(t) || TakaGameKnowledge.hasVerifiedGameUiEvidence(t) || TakaGameKnowledge.hasVerifiedResultEvidence(t)) cues++;
        if (roomUiEvidence) cues += 2;
        if (green != null && yellow != null && !green.isEmpty() && !yellow.isEmpty()) cues++;
        if (Detector.looksLikeGiftGrid(green == null ? Collections.emptyList() : green, yellow == null ? Collections.emptyList() : yellow, bmp)) cues++;
        if (title != null && !title.isEmpty() && looksLikeTakaGameCanvas(bmp)) cues++;
        return cues >= 2;
    }

    private boolean hasGiftRoomEvidence(String text) {
        String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
        int hits = 0;
        if (containsAnyText(t, new String[]{"الكل في الغرفة", "إرسال", "ارسال", "الحقيبة", "أكثر شعبية", "تصنيف", "محظوظ", "هدايا", "فخم", "svip"})) hits++;
        if (containsAnyText(t, new String[]{"180", "360", "500", "2000", "40", "50", "720"})) hits++;
        if (containsAnyText(t, new String[]{"بطة", "خوذة", "مقلاة", "حقيبة إسعاف", "إنزال جوي", "عبد الشمس", "شبشب", "عصا مضيئة"})) hits++;
        return hits >= 2;
    }

    private int gameTitleConfidence(String title, String text) {
        if (title == null || title.isEmpty()) return 0;
        String t = title.toLowerCase(Locale.ROOT);
        int score = 70;
        if (t.contains("sphinx") || t.contains("magic")) score += 12;
        if (containsAnyText(text, new String[]{"win", "bet", "stake", "spin", "play", "الرهان", "فوز"})) score += 10;
        return Math.min(96, score);
    }

    private GameRouter.GameMode modeFromVisibleGame(String title, String ocr) {
        String t = ((title == null ? "" : title) + " " + (ocr == null ? "" : ocr)).toLowerCase(Locale.ROOT);
        GameRouter.GameMode fromKnowledge = TakaGameKnowledge.modeFromVisibleText(t);
        if (fromKnowledge != GameRouter.GameMode.UNKNOWN && fromKnowledge != GameRouter.GameMode.LUCKY_GIFTS) return fromKnowledge;
        if (containsAnyText(t, new String[]{"roulette", "روليت", "wheel", "عجلة"})) return GameRouter.GameMode.WHEEL_ROULETTE;
        if (containsAnyText(t, new String[]{"baccarat", "باكارات", "poker", "بوكر", "blackjack", "بطاقات"})) return GameRouter.GameMode.CARD_GAMES;
        if (containsAnyText(t, new String[]{"dice", "sicbo", "نرد", "سيكبو"})) return GameRouter.GameMode.DICE_GAMES;
        if (containsAnyText(t, new String[]{"crash", "multiplier", "aviator", "مضاعف"})) return GameRouter.GameMode.CRASH_GAMES;
        return GameRouter.GameMode.ARCADE_INSTANT;
    }

    private boolean looksLikeTakaGameCanvas(Bitmap b) {
        if (b == null || b.isRecycled()) return false;
        int w=b.getWidth(), h=b.getHeight();
        if (w < 500 || h < 700) return false;
        // The internal game canvas has a dense, saturated lower/middle playfield.
        int samples=0, saturated=0, dark=0;
        float[] hsv=new float[3];
        int y0=(int)(h*0.34f), y1=(int)(h*0.90f);
        int step=Math.max(8, Math.min(w,h)/80);
        for(int y=y0;y<y1;y+=step) for(int x=0;x<w;x+=step){
            android.graphics.Color.colorToHSV(b.getPixel(x,y),hsv);
            if(hsv[1]>.55f && hsv[2]>.35f) saturated++;
            if(hsv[2]<.22f) dark++;
            samples++;
        }
        if(samples==0) return false;
        float sat=(float)saturated/samples, dk=(float)dark/samples;
        return sat>.18f && dk>.08f;
    }

    private static void sortMarkers(List<Detector.Marker> a){
        Collections.sort(a,(x,z)->{int d=Integer.compare(x.rect.top,z.rect.top);return d!=0?d:Integer.compare(x.rect.left,z.rect.left);});
    }

    private void applyKnownOcrItemLabels(List<Detector.Marker> greenMarkers, List<Detector.Tile> greenItems,
                                         List<Detector.Marker> yellowMarkers, List<Detector.Tile> yellowItems, String ocr) {
        if (ocr == null || ocr.trim().isEmpty()) return;
        class Ref { Detector.Marker m; Detector.Tile t; boolean green; Ref(Detector.Marker mm,Detector.Tile tt,boolean gg){m=mm;t=tt;green=gg;} }
        ArrayList<Ref> refs=new ArrayList<>();
        for(int i=0;i<greenMarkers.size() && i<greenItems.size();i++) refs.add(new Ref(greenMarkers.get(i),greenItems.get(i),true));
        for(int i=0;i<yellowMarkers.size() && i<yellowItems.size();i++) refs.add(new Ref(yellowMarkers.get(i),yellowItems.get(i),false));
        refs.sort((a,b)->{int d=Integer.compare(a.m.rect.top,b.m.rect.top);return d!=0?d:Integer.compare(a.m.rect.left,b.m.rect.left);});

        ArrayList<String> found=new ArrayList<>();
        String[] labels=TemplateRepository.knownLabels();
        String[] lines=ocr.replace('\r','\n').split("\n+");
        for(String line:lines){
            String clean=line==null?"":line.trim();
            if(clean.isEmpty()) continue;
            ArrayList<String> lineLabels=new ArrayList<>();
            for(String label:labels) if(clean.contains(label) && !lineLabels.contains(label)) lineLabels.add(label);
            lineLabels.sort((a,b)->Integer.compare(clean.indexOf(a),clean.indexOf(b)));
            for(String label:lineLabels) if(!found.contains(label)) found.add(label);
        }
        if(found.isEmpty()) return;
        int n=Math.min(refs.size(),found.size());
        for(int i=0;i<n;i++){
            Ref r=refs.get(i);
            if(r.t.label==null || r.t.label.isEmpty() || "غير معروف".equals(r.t.label) || r.t.similarity<0.74f){
                Detector.Tile replacement=new Detector.Tile(r.t.rect,r.t.hash,found.get(i),Math.max(r.t.similarity,0.86f));
                if(r.green) greenItems.set(greenMarkers.indexOf(r.m),replacement);
                else yellowItems.set(yellowMarkers.indexOf(r.m),replacement);
            }
        }
    }

    private List<Detector.Tile> attachMarkersToTiles(List<Detector.Marker> markers,List<Detector.Tile> tiles,Bitmap bmp,TemplateRepository repo){
        ArrayList<Detector.Tile> out=new ArrayList<>();
        Set<Integer> used=new HashSet<>();
        for(Detector.Marker m:markers){
            double best=Double.MAX_VALUE; int bi=-1;
            double mx=(m.rect.left+m.rect.right)/2.0, my=(m.rect.top+m.rect.bottom)/2.0;
            for(int i=0;i<tiles.size();i++) if(!used.contains(i)){
                Rect r=tiles.get(i).rect;
                double tx=(r.left+r.right)/2.0, ty=(r.top+r.bottom)/2.0;
                // Badge normally sits near the upper-right of its tile.
                double dx=mx-tx, dy=my-ty;
                double d=Math.hypot(dx,dy);
                if(d<best && dy>-r.height()*0.75 && dy<r.height()*0.75) {best=d;bi=i;}
            }
            if(bi>=0 && best<Math.max(bmp.getWidth()/4.0,120)) {used.add(bi); out.add(tiles.get(bi));}
            else out.add(new Detector.Tile(new Rect(),0,"غير معروف",0));
        }
        return out;
    }

    private List<String> buildRelations(List<Detector.Tile> green,List<Detector.Tile> yellow,
                                         String previousGreen,String previousYellow,
                                         String currentGreen,String currentYellow,
                                         InteractionReferenceLearner.Observation interaction){
        ArrayList<String> out=new ArrayList<>();
        Set<String> beforeG=labels(previousGreen), nowG=labels(currentGreen);
        Set<String> beforeY=labels(previousYellow), nowY=labels(currentYellow);
        Set<String> newG=new LinkedHashSet<>(nowG); newG.removeAll(beforeG);
        Set<String> consumedY=new LinkedHashSet<>(beforeY); consumedY.removeAll(nowY);

        // Conservative fallback for a real one-green/one-yellow change. The
        // relation belongs to the GREEN strip that was visible before the change,
        // not the newly appearing strip.
        if(interaction!=null && consumedY.size()==1){
            String g = !beforeG.isEmpty() ? beforeG.iterator().next() : (newG.size()==1 ? newG.iterator().next() : "");
            if(!g.isEmpty()){
                String y=consumedY.iterator().next();
                db.observeRelation(g,y);
                int hits=db.relationHits(g,y), total=db.relationTotal(g);
                int pct=total>0?Math.round(100f*hits/total):0;
                out.add(""+g+" ← "+y+" | نسبة الربط المرصودة: "+pct+"% ("+hits+"/"+total+")");
            }
        }

        // Also report the strongest previously learned relations for currently visible greens.
        for(String g:nowG){
            List<String> learned=db.relationsFor(g,3);
            for(String item:learned) if(!out.contains(item)) out.add(item);
        }
        return out;
    }

    private static Set<String> labels(String signature){
        LinkedHashSet<String> s=new LinkedHashSet<>();
        if(signature==null||signature.isEmpty()) return s;
        for(String x:signature.split(";")) if(!x.isEmpty()) s.add(x);
        return s;
    }

    private String signature(List<Detector.Tile> items){
        ArrayList<String> labels=new ArrayList<>();
        for (Detector.Tile t : items) if (t!=null && t.label!=null && !t.label.equals("غير معروف")) labels.add(t.label);
        Collections.sort(labels);
        StringBuilder s=new StringBuilder();
        String last="";
        for(String label:labels){
            if(!label.equals(last)){ s.append(label).append(';'); last=label; }
        }
        return s.toString();
    }

    private String updateAndRecommend(String previous,String current,InteractionReferenceLearner.Observation interaction){
        // A transition is counted only at the close of a real icon-interaction window.
        // Ordinary animation, scrolling, or page refreshes therefore cannot inflate the model.
        if(interaction==null || previous==null||previous.isEmpty()||current==null||current.isEmpty()||previous.equals(current)) return "";
        Set<String> before=new LinkedHashSet<>(Arrays.asList(previous.split(";")));
        String next="";
        for(String item:current.split(";")) if(!item.isEmpty()&&!before.contains(item)){ next=item; break; }
        if(next.isEmpty()) return "";
        int total=db.observeTransition(previous,next);
        int hits=db.transitionHits(previous,next);
        if(hits < 3) return "انتقال مرصود: "+next+" — نحتاج مشاهدات إضافية قبل تثبيت النسبة.";
        int pct=Math.round(100f*hits/Math.max(1,total));
        return "الشريط التالي المرصود: "+next+" — "+pct+"% ("+hits+"/"+total+")";
    }


    /** Remove consecutive duplicate observations caused by repeated screen/OCR frames. */
    private List<String> filteredRecentPlayLabels(int limit) {
        List<String> raw = db.recentPlayLabels(Math.max(20, limit * 3));
        ArrayList<String> out = new ArrayList<>();
        String last = "";
        for (String label : raw) {
            if (label == null) continue;
            label = label.trim();
            if (label.isEmpty() || label.equals(last)) continue;
            out.add(label);
            last = label;
        }
        int from = Math.max(0, out.size() - Math.max(1, limit));
        return new ArrayList<>(out.subList(from, out.size()));
    }

    private String firstRecognizedLabel(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        for (String label : filteredRecentPlayLabels(30)) {
            if (!label.isEmpty() && text.contains(label)) return label;
        }
        return text.trim();
    }

    /** Predict from persistent observed relations; unknown labels use general history. */
    private AnalysisResult.Prediction predictFromHistory(String currentLabel) {
        if (currentLabel == null || currentLabel.trim().isEmpty()) return null;
        currentLabel = currentLabel.trim();
        List<String> learned = db.relationsFor(currentLabel, 1);
        if (!learned.isEmpty()) {
            String row = learned.get(0);
            String token = "← ";
            int arrow = row.indexOf(token);
            if (arrow >= 0) {
                int start = arrow + token.length();
                int pipe = row.indexOf(" | ", start);
                String gift = (pipe > start ? row.substring(start, pipe) : row.substring(start)).trim();
                int hits = db.relationHits(currentLabel, gift);
                int total = db.relationTotal(currentLabel);
                int pct = total > 0 ? Math.round(100f * hits / total) : 0;
                return new AnalysisResult.Prediction(gift, pct);
            }
        }
        List<String> history = filteredRecentPlayLabels(200);
        if (history.isEmpty()) return new AnalysisResult.Prediction("تحليل أولي: تابع النمط العام", 50);
        LinkedHashMap<String,Integer> counts = new LinkedHashMap<>();
        for (String label : history) counts.put(label, counts.containsKey(label) ? counts.get(label)+1 : 1);
        String best = ""; int bestCount = 0;
        for (Map.Entry<String,Integer> e : counts.entrySet()) if (e.getValue() > bestCount) { best=e.getKey(); bestCount=e.getValue(); }
        if (best.isEmpty()) return new AnalysisResult.Prediction("تحليل أولي: تابع النمط العام", 50);
        int pct = Math.max(50, Math.min(99, Math.round(100f * bestCount / Math.max(1, history.size()))));
        return new AnalysisResult.Prediction(best, pct);
    }

    private String buildPrePlayPlan(List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,String currentGreenState){
        ArrayList<Detector.Tile> candidates=new ArrayList<>();
        candidates.addAll(greenItems);
        candidates.addAll(yellowItems);
        List<PrePlayDecisionEngine.Decision> ranked=prePlayDecisionEngine.rank(candidates,currentGreenState,db);
        if(ranked.isEmpty()) return "";
        StringBuilder s=new StringBuilder("تحليل العناصر المرصودة (بدون توصية مراهنة):\n");
        int n=Math.min(5,ranked.size());
        for(int i=0;i<n;i++){
            PrePlayDecisionEngine.Decision d=ranked.get(i);
            s.append(d.line(i+1));
            s.append(" | بيانات رصد فعلية فقط");
            s.append('\n');
        }
        s.append("ملاحظة: التحليل وصفي ولا يحدد نتيجة أو مبلغ مراهنة.");
        return s.toString().trim();
    }

    private String buildCoordinates(List<Detector.Marker> green,List<Detector.Marker> yellow,
                                    List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,
                                    int width,int height){
        StringBuilder s=new StringBuilder();
        if(!green.isEmpty()){
            s.append("إحداثيات الشرايط (x,y,w,h): ");
            for(int i=0;i<green.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=green.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!yellow.isEmpty()){
            s.append("إحداثيات الخزين (x,y,w,h): ");
            for(int i=0;i<yellow.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=yellow.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!greenItems.isEmpty()){
            s.append("📍 مراكز العناصر: ");
            for(int i=0;i<greenItems.size();i++){
                Detector.Tile t=greenItems.get(i); if(t.rect.isEmpty()) continue;
                if(s.charAt(s.length()-1)!=' ') s.append(" ؛ ");
                s.append("").append(t.label).append("@").append((t.rect.left+t.rect.right)/2)
                 .append(',').append((t.rect.top+t.rect.bottom)/2);
            }
        }
        return s.toString();
    }

    private static double centerDistance(Rect a,Rect b){
        double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0;
        double bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;
        return Math.hypot(ax-bx,ay-by);
    }
    private static String firstNewLabel(String previous,String current){
        Set<String> before=labels(previous);
        for(String x:labels(current)) if(!before.contains(x)) return x;
        return "";
    }
    public void save(AnalysisResult r){db.add(r);} public TemplateRepository templates(){return templates;} public HistoryDb db(){return db;} public AnalyticsEngine analytics(){return analytics;}
    public WebSocketReadOnlyMonitor webSocketMonitor(){return webSocketMonitor;}
    public OwnedTrafficMetadataMonitor trafficMetadataMonitor(){return trafficMetadataMonitor;}
    public SelfMemoryStateMonitor selfMemoryMonitor(){return selfMemoryMonitor;}
    public SignalRedundancyRouter signalRouter(){return signalRouter;}
    public FridaSafetyBoundary fridaBoundary(){return fridaBoundary;}
    public ParallelProcessingEngine parallelEngine(){return parallelEngine;}
    public HardwareAccelerationManager hardwareAcceleration(){return hardwareAcceleration;}
    public MultiprocessingBoundary multiprocessingBoundary(){return multiprocessingBoundary;}
    public InteractionReferenceLearner interactionLearner(){return interactionLearner;}
    public PrePlayDecisionEngine prePlayDecisionEngine(){return prePlayDecisionEngine;}
    public PatternAnalyticsEngine patternAnalyticsEngine(){return patternAnalyticsEngine;}
    public BettingSignalEngine bettingSignalEngine(){return bettingSignalEngine;}
    public DeepChainPatternEngine deepChainPatternEngine(){return deepChainPatternEngine;}
    public DynamicRiskStepper dynamicRiskStepper(){return dynamicRiskStepper;}
    public ZeroSecondTimingMonitor zeroSecondTimingMonitor(){return zeroSecondTimingMonitor;}
    /** Returns the observed signal for a specific game profile. */
    public GameSignalEngine.Signal signalForMode(GameRouter.GameMode mode) {
        return gameSignalEngine.signalFor(mode);
    }

    /** Returns the strongest observed signal among the internally tracked game profiles. */
    public GameSignalEngine.Signal strongestInternalSignal() {
        return gameSignalEngine.strongestInternal();
    }

    public GameSignalEngine gameSignalEngine(){return gameSignalEngine;}
}
