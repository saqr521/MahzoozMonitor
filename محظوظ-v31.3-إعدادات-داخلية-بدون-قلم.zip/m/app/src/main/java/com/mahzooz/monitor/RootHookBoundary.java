package com.mahzooz.monitor;

/**
 * Platform boundary for optional root/hook environments.
 * No Magisk/LSPosed hook implementation is included; the analyzer remains
 * independent of root access and process injection.
 */
public final class RootHookBoundary {
    public boolean isAvailable() { return false; }
    public boolean supportsProcessInjection() { return false; }
}
