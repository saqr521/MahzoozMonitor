package com.mahzooz.monitor;

import android.graphics.Bitmap;

/** One safe facade for screenshot, OpenCV and optical-flow capabilities. */
public final class ScreenshotAndCvTools {
    private final OpenCvVisionEngine cv = new OpenCvVisionEngine();
    private long lastSavedMs;
    private static final long SAVE_INTERVAL_MS = 5000;

    public boolean openCvAvailable() { return cv.isAvailable(); }
    public float opticalFlow(Bitmap bitmap) { return cv.opticalFlowMagnitude(bitmap); }

    public void maybeSaveScreenshot(android.content.Context context, Bitmap bitmap, long nowMs) {
        if (nowMs - lastSavedMs < SAVE_INTERVAL_MS) return;
        if (ScreenshotStore.savePng(context, bitmap) != null) lastSavedMs = nowMs;
    }

    public void reset() { cv.reset(); lastSavedMs = 0L; }
}
