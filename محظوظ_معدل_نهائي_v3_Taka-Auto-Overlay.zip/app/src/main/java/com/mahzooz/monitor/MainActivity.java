package com.mahzooz.monitor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Main screen: animated fire background with three independent settings entries. */
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        FrameLayout root = new FrameLayout(this);

        GifBackgroundView background = new GifBackgroundView(this);
        root.addView(background, new FrameLayout.LayoutParams(-1, -1));

        // Dark veil keeps the moving fire visible while making controls readable.
        View veil = new View(this);
        veil.setBackgroundColor(Color.argb(105, 0, 0, 0));
        root.addView(veil, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(18), dp(22), dp(18), dp(22));

        ImageButton settings = new ImageButton(this);
        settings.setImageResource(R.drawable.ic_settings_round);
        settings.setContentDescription("الإعدادات العامة");
        settings.setBackground(makeCircle(Color.argb(155, 0, 0, 0)));
        settings.setPadding(dp(12), dp(12), dp(12), dp(12));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(72), dp(72));
        sp.gravity = Gravity.CENTER_HORIZONTAL;
        sp.bottomMargin = dp(26);
        content.addView(settings, sp);

        TextView title = text("محظوظ", 32, true);
        title.setGravity(Gravity.CENTER);
        content.addView(title, widthWrap(dp(62)));

        TextView subtitle = text("إعدادات لعبة المحظوظ", 19, true);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(2), 0, dp(12));
        content.addView(subtitle, widthWrap(dp(50)));

        content.addView(settingCard(R.drawable.ic_mahzooz, "إعدادات لعبة المحظوظ",
                "المراقبة والتحليل والتعلّم والسجل", v ->
                        startActivity(new Intent(this, MahzoozGameSettingsActivity.class))),
                widthWrap(dp(96)));

        content.addView(settingCard(R.drawable.ic_games, "مركز البرامج",
                "إضافة Taka وZena وبرامج أخرى وتشغيلها مع المراقبة",
                v -> startActivity(new Intent(this, ProgramCenterActivity.class))),
                widthWrap(dp(96)));

        TextView internalTitle = text("الألعاب الداخلية", 21, true);
        internalTitle.setGravity(Gravity.CENTER);
        internalTitle.setPadding(0, dp(22), 0, dp(10));
        content.addView(internalTitle, widthWrap(dp(50)));

        content.addView(settingCard(R.drawable.ic_games, "إعدادات الألعاب الداخلية",
                "خصائص كل لعبة وطريقة اكتشافها", v ->
                        startActivity(new Intent(this, InternalGamesSettingsActivity.class))),
                widthWrap(dp(96)));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -1);
        cp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        root.addView(content, cp);
        setContentView(root);
    }

    private LinearLayout settingCard(int iconRes, String title, String desc, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setBackground(round(Color.argb(165, 10, 12, 16), dp(18)));
        card.setClickable(true);
        card.setOnClickListener(click);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setPadding(dp(8), dp(8), dp(8), dp(8));
        card.addView(icon, new LinearLayout.LayoutParams(dp(72), dp(72)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        TextView t = text(title, 18, true);
        t.setGravity(Gravity.RIGHT);
        TextView d = text(desc, 12, false);
        d.setTextColor(Color.LTGRAY);
        d.setGravity(Gravity.RIGHT);
        labels.addView(t);
        labels.addView(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(8), 0, 0, 0);
        card.addView(labels, lp);
        return card;
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams widthWrap(int topBottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = topBottom / 8;
        p.bottomMargin = topBottom / 8;
        return p;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        g.setStroke(dp(1), Color.argb(80, 255, 255, 255));
        return g;
    }

    private GradientDrawable makeCircle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(dp(1), Color.argb(90, 255, 255, 255));
        return g;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
