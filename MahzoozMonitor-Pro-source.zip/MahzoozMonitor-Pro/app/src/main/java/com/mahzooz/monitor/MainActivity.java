package com.mahzooz.monitor;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 7001;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);

        findViewById(R.id.start).setOnClickListener(v -> startCaptureFlow());
        findViewById(R.id.stop).setOnClickListener(v ->
            stopService(new Intent(this, CaptureService.class)));
        findViewById(R.id.calibrate).setOnClickListener(v ->
            status.setText("المعايرة: استخدم وضع التعلّم لإضافة قوالب العناصر لاحقًا."));
        findViewById(R.id.history).setOnClickListener(v ->
            status.setText(ResultStore.summary(this)));
    }

    private void startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
            status.setText("فعّل الظهور فوق التطبيقات ثم اضغط ابدأ مرة أخرى.");
            return;
        }
        MediaProjectionManager mpm =
            (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("resultCode", resultCode);
            i.putExtra("data", data);
            startForegroundService(i);
            status.setText("المراقبة تعمل: جارٍ تحليل الشاشة...");
        }
    }
}
