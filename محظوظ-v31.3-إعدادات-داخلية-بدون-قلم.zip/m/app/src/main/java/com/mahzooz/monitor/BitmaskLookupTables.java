package com.mahzooz.monitor;

/** Fast local classification helpers using bitmasks and precomputed lookup tables. */
public final class BitmaskLookupTables {
    private static final int GREEN = 1;
    private static final int YELLOW = 1 << 1;
    private static final int MOVING = 1 << 2;
    private static final int CONFIDENT = 1 << 3;
    private static final int KNOWN = 1 << 4;
    private static final int[] POPCOUNT = new int[256];
    private static final byte[] COLOR_MASK = new byte[256];

    static {
        for (int i = 0; i < 256; i++) {
            POPCOUNT[i] = Integer.bitCount(i);
            int m = 0;
            if (i >= 80 && i <= 165) m |= GREEN;
            if (i >= 35 && i <= 65) m |= YELLOW;
            COLOR_MASK[i] = (byte)m;
        }
    }

    private BitmaskLookupTables() {}

    public static int mask(boolean green, boolean yellow, boolean moving, boolean confident, boolean known) {
        int m = 0;
        if (green) m |= GREEN;
        if (yellow) m |= YELLOW;
        if (moving) m |= MOVING;
        if (confident) m |= CONFIDENT;
        if (known) m |= KNOWN;
        return m;
    }

    public static boolean has(int mask, int flag) { return (mask & flag) != 0; }
    public static int popcount8(int value) { return POPCOUNT[value & 0xFF]; }
    public static int colorMaskForHue(int hue) { return COLOR_MASK[Math.max(0, Math.min(255, hue))] & 0xFF; }
    public static String describe(int mask) {
        StringBuilder s = new StringBuilder();
        if (has(mask,GREEN)) s.append("GREEN|");
        if (has(mask,YELLOW)) s.append("YELLOW|");
        if (has(mask,MOVING)) s.append("MOVING|");
        if (has(mask,CONFIDENT)) s.append("CONFIDENT|");
        if (has(mask,KNOWN)) s.append("KNOWN|");
        if (s.length()>0) s.setLength(s.length()-1);
        return s.toString();
    }
}
