package com.mahzooz.monitor;

import java.util.ArrayList;
import java.util.List;

public class AnalysisResult {
    public static class Prediction {
        public final String predictedGift;
        public final int confidencePercentage;
        public Prediction(String predictedGift, int confidencePercentage) {
            this.predictedGift = predictedGift == null ? "" : predictedGift;
            this.confidencePercentage = Math.max(0, Math.min(100, confidencePercentage));
        }
    }
    public final long timestamp;
    public final List<Detector.Marker> green;
    public final List<Detector.Marker> yellow;
    public final List<Detector.Tile> tiles;
    public final List<String> relations;
    public final String recommendation;
    public final String observedChange;
    public final float confidence;
    public final String coordinateSummary;
    public final ScreenStateDetector.State screenState;
    public String ocrText;

    public AnalysisResult(long timestamp,
                          List<Detector.Marker> green,
                          List<Detector.Marker> yellow,
                          List<Detector.Tile> tiles,
                          List<String> relations,
                          String recommendation,
                          String observedChange,
                          float confidence,
                          String coordinateSummary, ScreenStateDetector.State screenState) {
        this.timestamp = timestamp;
        this.green = green == null ? new ArrayList<>() : green;
        this.yellow = yellow == null ? new ArrayList<>() : yellow;
        this.tiles = tiles == null ? new ArrayList<>() : tiles;
        this.relations = relations == null ? new ArrayList<>() : relations;
        this.recommendation = recommendation == null ? "" : recommendation;
        this.observedChange = observedChange == null ? "" : observedChange;
        this.confidence = confidence;
        this.coordinateSummary = coordinateSummary == null ? "" : coordinateSummary;
        this.screenState = screenState == null ? new ScreenStateDetector.State(ScreenStateDetector.LockState.UNKNOWN,"غير محسوم",0f) : screenState;
        this.ocrText = "";
    }

    public AnalysisResult(long timestamp,
                          List<Detector.Marker> green,
                          List<Detector.Marker> yellow,
                          List<Detector.Tile> tiles,
                          List<String> relations,
                          String recommendation,
                          String observedChange,
                          float confidence,
                          String coordinateSummary,
                          ScreenStateDetector.State screenState,
                          String ocrText) {
        this(timestamp, green, yellow, tiles, relations, recommendation, observedChange, confidence, coordinateSummary, screenState);
        this.ocrText = ocrText == null ? "" : ocrText;
    }
}
