package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Multiple independent, read-only signal readers with fallback behavior. */
public final class SignalReaders {
    public interface Reader<T> { T read(T input); }

    private SignalReaders() {}

    /** Reader #1: visual screen state, available immediately after first captured frame. */
    public static String visualState(Bitmap bitmap, List<Detector.Marker> green, List<Detector.Marker> yellow) {
        if (bitmap == null) return "NO_SCREEN";
        return "SCREEN green=" + green.size() + " yellow=" + yellow.size() +
                " size=" + bitmap.getWidth() + "x" + bitmap.getHeight();
    }

    /** Reader #2: accessibility tree when the game exposes semantic nodes. */
    public static List<String> accessibilityText(AccessibilityNodeInfo root) {
        if (root == null) return Collections.emptyList();
        ArrayList<String> out = new ArrayList<>();
        collect(root, out);
        return out;
    }

    private static void collect(AccessibilityNodeInfo n, List<String> out) {
        CharSequence t=n.getText();
        CharSequence d=n.getContentDescription();
        if (t!=null && t.length()>0) out.add(t.toString());
        else if (d!=null && d.length()>0) out.add(d.toString());
        for(int i=0;i<n.getChildCount();i++) {
            AccessibilityNodeInfo c=n.getChild(i);
            if(c!=null) { collect(c,out); c.recycle(); }
        }
    }

    /** Reader #3: already-exported telemetry; never captures packets itself. */
    public static List<ImportedTelemetryRecord> exportedTelemetry(ScapyMitmproxyHybridCaptureAdapter adapter) {
        return adapter == null ? Collections.emptyList() : adapter.snapshot();
    }
}
