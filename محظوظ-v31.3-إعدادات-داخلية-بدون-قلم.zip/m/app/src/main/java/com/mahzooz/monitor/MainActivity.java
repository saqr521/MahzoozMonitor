package com.mahzooz.monitor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.ImageButton;
import android.widget.LinearLayout;

/** Main screen: presentation only. All monitor controls live inside Settings. */
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        // No fixed image background: keep the main screen clean and solid.
        root.setBackgroundColor(Color.rgb(16, 21, 28));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        ImageButton settings = new ImageButton(this);
        settings.setContentDescription("الإعدادات");
        settings.setImageResource(android.R.drawable.ic_menu_manage);
        settings.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        settings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        top.addView(settings, new LinearLayout.LayoutParams(64, 64));

        root.addView(top, new LinearLayout.LayoutParams(-1, 72));
        setContentView(root);
    }
}
