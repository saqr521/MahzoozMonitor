package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class Detector {
    public static class Marker { public Rect rect; public float score; public String type; public Marker(Rect r,float s,String t){rect=r;score=s;type=t;} }
    public static class Tile { public Rect rect; public long hash; public String label; public float similarity; public Tile(Rect r,long h,String l,float s){rect=r;hash=h;label=l;similarity=s;} }

    private Detector() {}

    public static List<Marker> findMarkers(Bitmap src, boolean green) {
        int w=src.getWidth(), h=src.getHeight();
        // Scan the complete captured game frame. The storage/inventory can be in the upper
        // half of the screen, so restricting detection to the lower 45% made the
        // monitor silently miss the very icons it was supposed to read.
        int startY=0;
        // Work on a 2x2 logical grid. Badges in the supplied game are ~17-28 px,
        // so this keeps their geometry while cutting per-frame pixel work roughly 4x.
        int step=2, gw=(w+step-1)/step, gh=(h-startY+step-1)/step;
        boolean[] seen=new boolean[gw*gh];
        ArrayList<Marker> out=new ArrayList<>();
        int[] q=new int[Math.min(gw*gh,180000)];
        for(int gy=0;gy<gh;gy++){
            int y0=startY+gy*step;
            for(int gx=0;gx<gw;gx++){
                int idx=gy*gw+gx; if(seen[idx]) continue;
                if(!blockMatches(src,gx*step,y0,step,green)){seen[idx]=true;continue;}
                int head=0,tail=0,minX=gx,maxX=gx,minY=gy,maxY=gy,count=0;
                if(tail<q.length) q[tail++]=idx; else {seen[idx]=true;continue;}
                seen[idx]=true;
                while(head<tail){
                    int p=q[head++], cx=p%gw, cy=p/gw; count++;
                    minX=Math.min(minX,cx);maxX=Math.max(maxX,cx);minY=Math.min(minY,cy);maxY=Math.max(maxY,cy);
                    if(count>500) break;
                    int ni;
                    if(cx>0){ni=p-1;if(!seen[ni]&&blockMatches(src,(cx-1)*step,startY+cy*step,step,green)){seen[ni]=true;if(tail<q.length)q[tail++]=ni;}}
                    if(cx+1<gw){ni=p+1;if(!seen[ni]&&blockMatches(src,(cx+1)*step,startY+cy*step,step,green)){seen[ni]=true;if(tail<q.length)q[tail++]=ni;}}
                    if(cy>0){ni=p-gw;if(!seen[ni]&&blockMatches(src,cx*step,startY+(cy-1)*step,step,green)){seen[ni]=true;if(tail<q.length)q[tail++]=ni;}}
                    if(cy+1<gh){ni=p+gw;if(!seen[ni]&&blockMatches(src,cx*step,startY+(cy+1)*step,step,green)){seen[ni]=true;if(tail<q.length)q[tail++]=ni;}}
                }
                int bw=(maxX-minX+1)*step,bh=(maxY-minY+1)*step;
                int px=Math.max(0,minX*step-1), py=Math.max(startY,minY*step+startY-1);
                // Area is scaled by ~4 because the grid is 2x2.
                int area=count*4;
                if(area>=45&&area<=1100&&bw>=9&&bh>=9&&bw<=38&&bh<=38&&((double)bw/bh)>=.55&&((double)bw/bh)<=1.65){
                    float density=(float)area/Math.max(1,bw*bh);
                    if(density>.18f) out.add(new Marker(new Rect(px,py,Math.min(w,px+bw+2),Math.min(h,py+bh+2)),Math.min(1f,density*1.35f),green?"GREEN":"YELLOW"));
                }
            }
        }
        dedupe(out); return out;
    }

    private static boolean blockMatches(Bitmap b,int x,int y,int step,boolean green){
        int w=b.getWidth(),h=b.getHeight();
        int maxX=Math.min(w,x+step), maxY=Math.min(h,y+step), good=0,total=0;
        float[] hsv=new float[3];
        for(int py=y;py<maxY;py++) for(int px=x;px<maxX;px++){
            int c=b.getPixel(px,py); Color.colorToHSV(c,hsv); total++;
            float hue=hsv[0],sat=hsv[1],val=hsv[2];
            if(sat>=0.45f && val>=0.45f && (green ? hue>=80f&&hue<=165f : hue>=35f&&hue<=65f)) good++;
        }
        // Requiring most pixels in the block to share the badge hue suppresses
        // thin green leaves/text and keeps the small square markers stable.
        return total>0 && good>=Math.max(1,(int)Math.ceil(total*0.60f));
    }

    private static boolean matches(float[] hsv, boolean green){
        float hue=hsv[0], sat=hsv[1], val=hsv[2];
        if(sat<0.45f || val<0.45f) return false;
        // Green badge and yellow badge ranges observed in the supplied gameplay frames.
        if(green) return hue>=80 && hue<=165;
        return hue>=35 && hue<=65;
    }

    private static void dedupe(List<Marker> list){
        Collections.sort(list,(a,b)->{
            int d=Integer.compare(a.rect.top,b.rect.top);
            return d!=0?d:Integer.compare(a.rect.left,b.rect.left);
        });
        ArrayList<Marker> keep=new ArrayList<>();
        for(Marker m:list){
            boolean dup=false;
            for(Marker k:keep){
                if(Rect.intersects(m.rect,k.rect) || centerDistance(m.rect,k.rect)<7){dup=true;break;}
            }
            if(!dup) keep.add(m);
        }
        list.clear(); list.addAll(keep);
    }

    private static double centerDistance(Rect a,Rect b){double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0,bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;return Math.hypot(ax-bx,ay-by);}

    /** Finds a likely grid of square/near-square tiles in the lower portion of the screen. */
    public static List<Tile> findTiles(Bitmap src, TemplateRepository repo){
        int w=src.getWidth(),h=src.getHeight();
        ArrayList<Tile> out=new ArrayList<>();
        int start=(int)(h*0.52f), cell=Math.max(48,w/6), gap=Math.max(3,cell/12);
        for(int y=start;y<h-cell/3;y+=cell){
            for(int x=0;x+cell<=w;x+=cell){
                Rect r=new Rect(x+gap,y+gap,x+cell-gap,y+cell-gap);
                if(r.width()<32||r.height()<32) continue;
                long hash=phash(src,r);
                TemplateRepository.Match m=repo.best(hash);
                out.add(new Tile(r,hash,m.label,m.similarity));
            }
        }
        return out;
    }


    /** Matches the icon directly below a green/yellow marker. The game places its
     * classification badge at the upper-right of each gift tile. */
    public static Tile itemForMarker(Bitmap src, Marker marker, TemplateRepository repo) {
        // In the game video the small badge is at the upper-right of the icon.
        // Crop the icon area to the left/below it, while avoiding the price text.
        int mw=Math.max(8,marker.rect.width());
        int mh=Math.max(8,marker.rect.height());
        int cx=marker.rect.centerX();
        int cy=marker.rect.centerY();
        // The badge is at the upper-right of the tile. Estimate the tile from the
        // badge itself instead of using screen width. The old width/4 heuristic
        // produced huge crops on phones and caused template matching to fail.
        int size=Math.max(48,Math.min(112,Math.round(Math.max(mw,mh)*5.2f)));
        int centerX=cx-Math.round(mw*1.35f);
        int centerY=cy+Math.round(mh*1.25f);
        int left=Math.max(0,centerX-size/2);
        int top=Math.max(0,centerY-size/2);
        int right=Math.min(src.getWidth(),left+size);
        int bottom=Math.min(src.getHeight(),top+size);
        if(right-left<48 || bottom-top<48) return new Tile(new Rect(),0,"غير معروف",0);
        Rect r=new Rect(left,top,right,bottom);
        long hash=phash(src,r);
        TemplateRepository.Match m=repo.best(hash);
        return new Tile(r,hash,m.label,m.similarity);
    }

    public static long phash(Bitmap src, Rect r){
        final int N=8; double[] gray=new double[N*N];
        for(int yy=0;yy<N;yy++) for(int xx=0;xx<N;xx++){
            int sx=r.left+(xx*r.width())/N, sy=r.top+(yy*r.height())/N;
            int c=src.getPixel(Math.max(0,Math.min(src.getWidth()-1,sx)),Math.max(0,Math.min(src.getHeight()-1,sy)));
            gray[yy*N+xx]=0.299*Color.red(c)+0.587*Color.green(c)+0.114*Color.blue(c);
        }
        double sum=0; for(double v:gray)sum+=v; double avg=sum/gray.length; long hash=0;
        for(int i=0;i<gray.length;i++) if(gray[i]>=avg) hash|=(1L<<i);
        return hash;
    }
}
