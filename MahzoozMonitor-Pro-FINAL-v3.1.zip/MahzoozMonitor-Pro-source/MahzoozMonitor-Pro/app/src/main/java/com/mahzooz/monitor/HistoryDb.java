package com.mahzooz.monitor;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class HistoryDb extends SQLiteOpenHelper {
    public HistoryDb(Context c) { super(c, "mahzooz_history.db", null, 2); }

    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, green INTEGER, yellow INTEGER, tiles TEXT, observed TEXT, confidence REAL, recommendation TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {
        if (oldV < 2) d.execSQL("ALTER TABLE events ADD COLUMN recommendation TEXT DEFAULT ''");
    }

    public void add(AnalysisResult r) {
        StringBuilder t = new StringBuilder();
        for (Detector.Tile x : r.tiles) {
            if (t.length() > 0) t.append(',');
            t.append(x.label).append(':')
                    .append(String.format(java.util.Locale.US, "%.2f", x.similarity));
        }
        getWritableDatabase().execSQL(
                "INSERT INTO events(ts,green,yellow,tiles,observed,confidence,recommendation) VALUES(?,?,?,?,?,?,?)",
                new Object[]{r.timestamp, r.green.size(), r.yellow.size(), t.toString(),
                        r.observedChange, r.confidence, r.recommendation});
    }

    public List<String> recent(int n) {
        ArrayList<String> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT ts,green,yellow,tiles,confidence,recommendation FROM events ORDER BY id DESC LIMIT ?",
                new String[]{String.valueOf(n)});
        while (c.moveToNext()) {
            String rec = c.getString(5);
            out.add(new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    .format(new java.util.Date(c.getLong(0)))
                    + " | 🟩 " + c.getInt(1) + " | 🟨 " + c.getInt(2)
                    + " | " + c.getString(3)
                    + " | " + String.format(java.util.Locale.US, "%.0f%%", c.getDouble(4) * 100)
                    + (rec == null || rec.isEmpty() ? "" : "\n" + rec));
        }
        c.close();
        return out;
    }

    public String stats() {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*),AVG(confidence),SUM(green),SUM(yellow) FROM events", null);
        String s = "لا توجد بيانات بعد";
        if (c.moveToFirst()) {
            s = "الرصد: " + c.getInt(0)
                    + " | متوسط الثقة: "
                    + String.format(java.util.Locale.US, "%.0f%%", c.getDouble(1) * 100)
                    + " | 🟩 " + c.getInt(2) + " | 🟨 " + c.getInt(3);
        }
        c.close();
        return s;
    }
}
