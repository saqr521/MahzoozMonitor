Project configuration.
