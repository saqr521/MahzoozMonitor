package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Read-only virtual risk progression. It records observed outcomes and exposes
 * both neutral recovery-style and anti-martingale-style paper values. It never
 * sends input or changes a real wager.
 */
public final class DynamicRiskStepper {
    public static final class Snapshot {
        public final int base;
        public final int virtualRecovery;
        public final int virtualAnti;
        public final int winStreak;
        public final int lossStreak;
        public final String text;
        Snapshot(int base, int recovery, int anti, int wins, int losses, String text) {
            this.base=base; this.virtualRecovery=recovery; this.virtualAnti=anti;
            this.winStreak=wins; this.lossStreak=losses; this.text=text;
        }
    }

    private static final String PREF="dynamic_risk";
    private final SharedPreferences sp;
    public DynamicRiskStepper(Context c){ sp=c.getSharedPreferences(PREF,Context.MODE_PRIVATE); }
    public int base(){ return Math.max(1,sp.getInt("base",5)); }
    public int max(){ return Math.max(base(),sp.getInt("max",320)); }
    public int winStreak(){ return Math.max(0,sp.getInt("winStreak",0)); }
    public int lossStreak(){ return Math.max(0,sp.getInt("lossStreak",0)); }
    public int recovery(){ return Math.max(base(),sp.getInt("recovery",base())); }
    public int anti(){ return Math.max(base(),sp.getInt("anti",base())); }
    public void reset(){ sp.edit().putInt("winStreak",0).putInt("lossStreak",0).putInt("recovery",base()).putInt("anti",base()).apply(); }

    public void observe(String ocr){
        if(ocr==null || ocr.trim().isEmpty()) return;
        String t=ocr.toLowerCase(java.util.Locale.ROOT);
        boolean win=contains(t,"win","wins","winner","فاز","فوز","ربح");
        boolean loss=contains(t,"loss","lost","lose","خسر","خسارة");
        if(win==loss) return;
        if(win){
            int ws=winStreak()+1;
            int ls=0;
            int nextAnti=safeMul(anti(),2);
            if(nextAnti>max()) nextAnti=base();
            sp.edit().putInt("winStreak",ws).putInt("lossStreak",ls)
                    .putInt("recovery",base()).putInt("anti",nextAnti).apply();
        } else {
            int ls=lossStreak()+1;
            int ws=0;
            int nextRecovery=safeMul(recovery(),2);
            if(nextRecovery>max()) nextRecovery=base();
            sp.edit().putInt("winStreak",ws).putInt("lossStreak",ls)
                    .putInt("recovery",nextRecovery).putInt("anti",base()).apply();
        }
    }

    public Snapshot snapshot(){
        String text="إدارة مخاطر افتراضية: بعد الفوز المتتالي="+winStreak()+
                " | بعد الخسارة المتتالية="+lossStreak()+
                " | قيمة التعافي الافتراضية="+recovery()+
                " | قيمة Anti-Martingale الافتراضية="+anti()+
                " | حد المحاكاة="+max()+". لا يتم تنفيذ أي رهان.";
        return new Snapshot(base(),recovery(),anti(),winStreak(),lossStreak(),text);
    }
    private int safeMul(int v,int m){ long n=(long)v*m; return n>Integer.MAX_VALUE?Integer.MAX_VALUE:(int)n; }
    private boolean contains(String s,String... xs){for(String x:xs)if(s.contains(x))return true;return false;}
}
