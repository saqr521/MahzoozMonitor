#include <atomic>
#include <cstdint>

// Optional native counterpart for future NDK builds. It only stores counters
// owned by the Mahzooz Monitor process; it does not attach to other processes.
namespace mahzooz {
std::atomic<std::uint64_t> analyzed_frames{0};
std::atomic<std::uint64_t> last_timestamp_ms{0};

void record_frame(std::uint64_t timestamp_ms) noexcept {
    last_timestamp_ms.store(timestamp_ms, std::memory_order_relaxed);
    analyzed_frames.fetch_add(1, std::memory_order_relaxed);
}

std::uint64_t frame_count() noexcept {
    return analyzed_frames.load(std::memory_order_relaxed);
}
}
