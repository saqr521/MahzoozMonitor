package com.mahzooz.monitor;

import java.util.Arrays;

/** Lightweight statistics that run locally on Android without a Python runtime. */
public final class StatisticalAnalysis {
    private StatisticalAnalysis() {}
    public static double mean(double[] x){
        if(x==null||x.length==0)return 0;
        double s=0; for(double v:x)s+=v; return s/x.length;
    }
    public static double variance(double[] x){
        if(x==null||x.length<2)return 0;
        double m=mean(x),s=0; for(double v:x){double d=v-m;s+=d*d;} return s/(x.length-1);
    }
    public static double standardDeviation(double[] x){return Math.sqrt(variance(x));}
    public static double percentile(double[] input,double p){
        if(input==null||input.length==0)return 0;
        double[] x=input.clone(); Arrays.sort(x);
        p=Math.max(0,Math.min(100,p));
        double pos=(p/100.0)*(x.length-1), lo=Math.floor(pos), hi=Math.ceil(pos);
        if(lo==hi)return x[(int)lo];
        return x[(int)lo]+(x[(int)hi]-x[(int)lo])*(pos-lo);
    }
}
