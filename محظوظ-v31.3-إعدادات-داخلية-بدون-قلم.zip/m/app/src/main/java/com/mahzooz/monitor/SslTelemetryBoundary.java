package com.mahzooz.monitor;

/**
 * TLS-safe telemetry boundary. It accepts already-decrypted/user-exported
 * application events; it never installs a CA, proxies sockets, or bypasses
 * certificate validation.
 */
public final class SslTelemetryBoundary {
    public boolean acceptsUserExportedData() { return true; }
    public boolean supportsSslProxyingOrBypass() { return false; }
}
