package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

public class TemplateRepository {
    public static class Entry { String label; long hash; Entry(String l,long h){label=l;hash=h;} }
    public static class Match { public final String label; public final float similarity; Match(String l,float s){label=l;similarity=s;} }
    private final SharedPreferences p;
    private final List<Entry> entries=new ArrayList<>();

    // Built-in visual fingerprints for the known game icons.
    // They are local templates only; relation mapping is learned from observations.
    private static final String[][] BUILTIN = {
        {"عصا مضيئة","0x7c00383878e80000"},
        {"شبشب","0x380030381cdc0091"},
        {"بطة","0x18001c3c1cdc0007"},
        {"عباد الشمس","0x3e00081c1c6c4030"},
        {"إنزال جوي","0x7c0010183cf88038"},
        {"حقيبة إسعاف","0x7e00003c3cd80038"},
        {"خوذة","0x1c00000c3cf84018"},
        {"مقلاة","0x1c08001c1c68401c"},
        {"قط","0x387c38f80020"},
        {"قنبلة","0x38383cdc0038"},
        {"يحب","0x3c3c38d80018"},
        {"بيضة","0x1c1c1c6c0018"},
        {"هامبورغ","0x80383838387038a7"},
        {"كب كيك","0xc030383c003c7c99"},
        {"دونات","0xc018181800301cef"},
        {"مصاصة","0x40181c7f00181873"},
        {"بطيخ","0x8020203800387878"},
        {"عنب","0x8030383c18383838"},
        {"خوخ","0x40101018003c3c3c"},
        {"فراولة","0x4018181c000e1c3c"},
        {"شريحة لحم","0x8038207c003c3ca7"},
        {"قهوة","0x80383818181c38b9"},
        {"بطاطس مقلية","0x18187e001c1cef"},
        {"دراق","0x20001000787c38"},
        {"مانجو","0x301018001c3c3c"},
        {"موز","0x181818001c3c38"},
        {"كرز","0x501c1c1c00001e1c"},
        {"حب","0x183c3e3e3e98"},
        {"الشواء","0x1c0001071e3efcd8"},
    };

    public TemplateRepository(Context c){p=c.getSharedPreferences("templates",Context.MODE_PRIVATE);load();}
    private void load(){
        entries.clear();
        for(String[] a:BUILTIN) try { entries.add(new Entry(a[0],parseHash(a[1]))); } catch(Exception ignored) {}
        String raw=p.getString("data","");
        if(!raw.isEmpty()) for(String s:raw.split("\\n")){String[] a=s.split("\\|",2);if(a.length==2)try{entries.add(new Entry(a[1],Long.parseUnsignedLong(a[0])));}catch(Exception ignored){}}
    }
    private static long parseHash(String s){
        String x=s.startsWith("0x")||s.startsWith("0X")?s.substring(2):s;
        return Long.parseUnsignedLong(x,16);
    }

    private void save(){StringBuilder b=new StringBuilder();for(Entry e:entries)b.append(e.hash).append('|').append(e.label.replace("|","/")).append('\n');p.edit().putString("data",b.toString()).apply();}
    public synchronized void add(String label,long hash){
        if(label==null||label.isEmpty()||"غير معروف".equals(label)||hash==0)return;
        for(Entry e:entries) if(e.label.equals(label)) return;
        entries.add(new Entry(label,hash)); save();
    }
    public synchronized void remember(String label,long hash){ add(label,hash); }
    public synchronized Match best(long hash){
        String best="غير معروف";float score=0;
        for(Entry e:entries){long x=hash^e.hash;int d=Long.bitCount(x);float s=1f-d/64f;if(s>score){score=s;best=e.label;}}
        return new Match(score>=0.62f?best:"غير معروف",score);
    }
    public synchronized int size(){return entries.size();}
}
