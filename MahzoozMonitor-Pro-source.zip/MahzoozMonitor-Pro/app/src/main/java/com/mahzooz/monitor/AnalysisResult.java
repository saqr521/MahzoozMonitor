package com.mahzooz.monitor;

import java.util.ArrayList;
import java.util.List;

public class AnalysisResult {
    public final long timestamp;
    public final List<Detector.Marker> green;
    public final List<Detector.Marker> yellow;
    public final List<Detector.Tile> tiles;
    public final String observedChange;
    public final float confidence;

    public AnalysisResult(long timestamp, List<Detector.Marker> green, List<Detector.Marker> yellow,
                          List<Detector.Tile> tiles, String observedChange, float confidence) {
        this.timestamp = timestamp;
        this.green = green == null ? new ArrayList<>() : green;
        this.yellow = yellow == null ? new ArrayList<>() : yellow;
        this.tiles = tiles == null ? new ArrayList<>() : tiles;
        this.observedChange = observedChange == null ? "" : observedChange;
        this.confidence = confidence;
    }
}
