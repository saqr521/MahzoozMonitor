package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Persistent visual catalog for the Mahzooz board.
 *
 * The catalog contains the bundled 30-card reference sheet plus any learned
 * hashes. Matching accepts either a raw pHash or a real card bitmap. The bitmap
 * path is used by the live grid reader because it preserves the card geometry
 * instead of guessing an icon from a tiny badge.
 */
public class TemplateRepository {
    private static final String[] SEEDED_LABELS={
            "عصا مضيئة","شبشب","بطة","عباد الشمس","إنزال جوي","حقيبة إسعاف",
            "خوذة","مقلاة","قطة","قنبلة","إعجاب","بيضة","مطرقة","جولد بريك",
            "حلوى","طاحونة هوائية","هامبورجر","كب كيك","دونات","مصاصة","شريحة لحم",
            "قهوة","بطاطس مقلية","مقص","دراق","مانجو","موز","كرز","حب","الشواء"};

    public static class Entry {
        String label;
        long hash;
        Bitmap reference;
        Entry(String l,long h){label=l;hash=h;}
        Entry(String l,long h,Bitmap b){label=l;hash=h;reference=b;}
    }

    public static class Match {
        public final String label;
        public final float similarity;
        Match(String l,float s){label=l;similarity=s;}
    }

    private final SharedPreferences p;
    private final List<Entry> entries=new ArrayList<>();
    private final Context context;

    public TemplateRepository(Context c){
        context=c.getApplicationContext();
        p=c.getSharedPreferences("templates",Context.MODE_PRIVATE);
        load();
    }

    private void load(){
        entries.clear();
        loadSeedTemplates();
        String raw=p.getString("data","");
        if(!raw.isEmpty()){
            for(String s:raw.split("\\n")){
                String[] a=s.split("\\|",2);
                if(a.length==2) try {
                    entries.add(new Entry(a[1],Long.parseUnsignedLong(a[0])));
                } catch(Exception ignored){}
            }
        }
    }

    /** Load the supplied 6x5 reference sheet once per repository instance. */
    private void loadSeedTemplates(){
        try(InputStream in=context.getAssets().open("mahzooz_templates.jpg")){
            Bitmap sheet=BitmapFactory.decodeStream(in);
            if(sheet==null) return;
            int cols=6, rows=5;
            int cw=sheet.getWidth()/cols, ch=sheet.getHeight()/rows;
            for(int i=0;i<SEEDED_LABELS.length;i++){
                int col=i%cols,row=i/cols;
                int left=col*cw, top=row*ch;
                int right=Math.min(sheet.getWidth(),left+cw);
                int bottom=Math.min(sheet.getHeight(),top+ch);
                if(right-left<16||bottom-top<16) continue;
                Bitmap tile=Bitmap.createBitmap(sheet,left,top,right-left,bottom-top);
                long hash=Detector.phash(tile,new android.graphics.Rect(0,0,tile.getWidth(),tile.getHeight()));
                if(hash!=0) entries.add(new Entry(SEEDED_LABELS[i],hash,tile));
                else tile.recycle();
            }
            sheet.recycle();
        }catch(Throwable ignored){}
    }

    private void save(){
        StringBuilder b=new StringBuilder();
        for(Entry e:entries)
            if(e.reference==null)
                b.append(e.hash).append('|').append(e.label.replace("|","/")).append('\n');
        p.edit().putString("data",b.toString()).apply();
    }

    public synchronized void add(String label,long hash){
        if(label==null||label.isEmpty()||"غير معروف".equals(label)||hash==0)return;
        for(Entry e:entries) if(e.label.equals(label)) return;
        entries.add(new Entry(label,hash)); save();
    }

    public synchronized void remember(String label,long hash){ add(label,hash); }

    public synchronized Match best(long hash){
        String best="غير معروف";float score=0;
        for(Entry e:entries){
            long x=hash^e.hash;
            int d=Long.bitCount(x);
            float s=1f-d/64f;
            if(s>score){score=s;best=e.label;}
        }
        return new Match(score>=0.62f?best:"غير معروف",score);
    }

    /**
     * Compare a real card crop against the bundled reference cards.
     * The crop is resized to the reference geometry before pHash comparison.
     * A small luminance agreement term reduces false matches between similarly
     * shaped icons on the same dark background.
     */
    public synchronized Match best(Bitmap crop){
        if(crop==null||crop.isRecycled()||crop.getWidth()<24||crop.getHeight()<24)
            return new Match("غير معروف",0);

        String best="غير معروف";
        float bestScore=0;
        long cropHash=Detector.phash(crop,new android.graphics.Rect(0,0,crop.getWidth(),crop.getHeight()));
        float cropMean=meanLuma(crop);

        for(Entry e:entries){
            float hashScore=1f-Long.bitCount(cropHash^e.hash)/64f;
            float meanScore=1f-Math.min(1f,Math.abs(cropMean-referenceMean(e.reference,cropMean))/70f);
            float score=hashScore*.78f+meanScore*.22f;
            if(score>bestScore){bestScore=score;best=e.label;}
        }
        return new Match(bestScore>=0.56f?best:"غير معروف",bestScore);
    }

    private float referenceMean(Bitmap b,float fallback){
        return b==null||b.isRecycled()?fallback:meanLuma(b);
    }

    private float meanLuma(Bitmap b){
        int w=b.getWidth(),h=b.getHeight();
        int sx=Math.max(1,w/12), sy=Math.max(1,h/12);
        double sum=0; int n=0;
        for(int y=0;y<h;y+=sy) for(int x=0;x<w;x+=sx){
            int c=b.getPixel(x,y);
            sum += .299*android.graphics.Color.red(c)+
                   .587*android.graphics.Color.green(c)+
                   .114*android.graphics.Color.blue(c);
            n++;
        }
        return n==0?0:(float)(sum/n);
    }

    public static String[] knownLabels(){ return SEEDED_LABELS.clone(); }
    public synchronized int size(){return entries.size();}
}
