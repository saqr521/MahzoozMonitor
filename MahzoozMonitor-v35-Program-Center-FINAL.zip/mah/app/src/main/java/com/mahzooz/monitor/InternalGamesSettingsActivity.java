package com.mahzooz.monitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Per-game settings entry point. Values shown here are configuration UI only. */
public class InternalGamesSettingsActivity extends Activity {
    private final String[] games = {"هدايا المحظوظ", "البطاقات", "تنين ونمر", "باكارات", "بوكر", "النرد", "العجلة والروليت", "ألعاب الكراش", "ألعاب الطاولة", "الألعاب الرياضية"};
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(22),dp(18),dp(18)); root.setBackgroundColor(Color.rgb(9,14,20));
        TextView title=new TextView(this); title.setText("إعدادات الألعاب الداخلية"); title.setTextColor(Color.WHITE); title.setTextSize(25); title.setGravity(Gravity.RIGHT); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,dp(64)));
        TextView note=new TextView(this); note.setText("اختر اللعبة لفتح خصائص ملف الاكتشاف الخاص بها."); note.setTextColor(Color.LTGRAY); note.setTextSize(14); note.setGravity(Gravity.RIGHT); root.addView(note,new LinearLayout.LayoutParams(-1,dp(55)));
        for(String game:games){ Button btt=new Button(this); btt.setText(game); btt.setTextColor(Color.WHITE); btt.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); btt.setOnClickListener(v->showGame(game)); root.addView(btt,lp(dp(8),dp(58))); }
        setContentView(root);
    }
    private void showGame(String game){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(12),dp(4),dp(12),0);
        TextView t=new TextView(this); t.setText("خصائص " + game + "\n\nملف اللعبة: " + TakaReferenceCatalog.profileForText(game) + "\nمرجع البيانات: idgame / item_name / item_number\n\nيمكن تخصيص ملف الاكتشاف، مستوى الثقة، ونطاق القراءة من هذا القسم."); t.setTextSize(15); t.setTextColor(Color.DKGRAY); t.setGravity(Gravity.RIGHT); c.addView(t);
        new AlertDialog.Builder(this).setTitle(game).setView(c).setPositiveButton("حفظ",null).setNegativeButton("إغلاق",null).show();
    }
    private LinearLayout.LayoutParams lp(int top,int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h);p.topMargin=top;return p;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
