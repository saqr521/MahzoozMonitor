package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Bounded parallel pipeline for independent, read-only screen-analysis tasks.
 * Android does not expose desktop-style multiprocessing pools inside an APK;
 * this engine uses a bounded worker pool and reports process isolation separately.
 */
public final class ParallelProcessingEngine implements AutoCloseable {
    private final ExecutorService pool;
    private final int workers;

    public ParallelProcessingEngine() {
        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        workers = Math.max(2, Math.min(4, cores));
        pool = Executors.newFixedThreadPool(workers, r -> {
            Thread t = new Thread(r, "Mahzooz-Parallel");
            t.setPriority(Thread.NORM_PRIORITY);
            return t;
        });
    }

    public int workerCount() { return workers; }

    public <T> List<T> invokeAll(List<Callable<T>> tasks) {
        ArrayList<T> out = new ArrayList<>();
        if (tasks == null || tasks.isEmpty()) return out;
        try {
            for (Future<T> f : pool.invokeAll(tasks)) out.add(f.get());
        } catch (Throwable ignored) { }
        return out;
    }

    /** Parallel, read-only pixel statistics. Useful for vectorized CV prechecks. */
    public float[] pixelChannelMeans(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return new float[]{0f,0f,0f};
        final int w = bitmap.getWidth(), h = bitmap.getHeight();
        final int rows = Math.max(1, workers);
        List<Callable<float[]>> tasks = new ArrayList<>();
        for (int part = 0; part < rows; part++) {
            final int y0 = part * h / rows;
            final int y1 = (part + 1) * h / rows;
            tasks.add(() -> {
                long r=0,g=0,b=0,n=0;
                int[] px = new int[Math.max(1, w * Math.max(1, Math.min(32, y1-y0)))];
                for (int y=y0; y<y1; y+=32) {
                    int end=Math.min(y1,y+32);
                    bitmap.getPixels(px,0,w,0, y,w,end-y);
                    for(int yy=0;yy<end-y;yy++) for(int x=0;x<w;x++) {
                        int c=px[yy*w+x]; r+=(c>>16)&255; g+=(c>>8)&255; b+=c&255; n++;
                    }
                }
                return new float[]{n==0?0:(float)r/n,n==0?0:(float)g/n,n==0?0:(float)b/n};
            });
        }
        List<float[]> parts = invokeAll(tasks);
        float[] sum=new float[3];
        float count=0f;
        for(float[] p:parts){ sum[0]+=p[0]; sum[1]+=p[1]; sum[2]+=p[2]; count++; }
        if(count>0){sum[0]/=count;sum[1]/=count;sum[2]/=count;}
        return sum;
    }

    public boolean supportsProcessIsolation() { return Build.VERSION.SDK_INT >= 26; }
    public String backendSummary() {
        return "Threading=" + workers + " workers | Multiprocessing=" +
                (supportsProcessIsolation()?"process-isolation-capable":"not-used") +
                " | Vectorization=primitive-array";
    }

    @Override public void close() { pool.shutdownNow(); }
}
