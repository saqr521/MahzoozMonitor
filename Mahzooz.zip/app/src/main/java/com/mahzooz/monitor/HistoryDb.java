package com.mahzooz.monitor;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.*;

public class HistoryDb extends SQLiteOpenHelper {
    public HistoryDb(Context c) { super(c,"mahzooz_history.db",null,11); }
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, green INTEGER, yellow INTEGER, tiles TEXT, observed TEXT, confidence REAL, recommendation TEXT)");
        d.execSQL("CREATE TABLE relations(green TEXT, yellow TEXT, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(green,yellow))");
        d.execSQL("CREATE TABLE transitions(previous TEXT, next TEXT, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous,next))");
        d.execSQL("CREATE TABLE analytics_samples(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, elapsed_ns INTEGER NOT NULL, green INTEGER NOT NULL, yellow INTEGER NOT NULL, confidence REAL NOT NULL)");
        d.execSQL("CREATE TABLE readonly_events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, type TEXT NOT NULL, name TEXT NOT NULL, confidence REAL NOT NULL)");
        d.execSQL("CREATE TABLE websocket_events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, direction TEXT NOT NULL, endpoint TEXT NOT NULL, bytes INTEGER NOT NULL, summary TEXT NOT NULL, confidence REAL NOT NULL)");
        d.execSQL("CREATE TABLE traffic_metadata(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, direction TEXT NOT NULL, endpoint TEXT NOT NULL, bytes INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE correlations(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, summary TEXT NOT NULL)");
        d.execSQL("CREATE TABLE interaction_references(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, label TEXT NOT NULL, before_state TEXT NOT NULL, after_state TEXT NOT NULL, row_idx INTEGER NOT NULL, col_idx INTEGER NOT NULL, confidence REAL NOT NULL)");
        d.execSQL("CREATE TABLE hit_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, label TEXT NOT NULL, hit_count INTEGER NOT NULL, source TEXT NOT NULL, confidence REAL NOT NULL)");
        d.execSQL("CREATE TABLE play_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL DEFAULT 0, last_hit_ms INTEGER NOT NULL DEFAULT 0, hit_count INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'OPEN')");
        d.execSQL("CREATE TABLE play_hits(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, ts_ms INTEGER NOT NULL, hit_no INTEGER NOT NULL, label TEXT NOT NULL, confidence REAL NOT NULL, next_label TEXT NOT NULL DEFAULT '', validation_pct INTEGER NOT NULL DEFAULT -1, FOREIGN KEY(session_id) REFERENCES play_sessions(id) ON DELETE CASCADE)");
        d.execSQL("CREATE TABLE play_links(previous_label TEXT NOT NULL, next_label TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous_label,next_label))");
        d.execSQL("CREATE TABLE play_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, hit_no INTEGER NOT NULL, label TEXT NOT NULL, confidence REAL NOT NULL, next_label TEXT NOT NULL DEFAULT '', validation_pct INTEGER NOT NULL DEFAULT -1)");
        d.execSQL("CREATE TABLE game_transitions(previous TEXT NOT NULL, next TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous,next))");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<2) d.execSQL("ALTER TABLE events ADD COLUMN recommendation TEXT DEFAULT ''");
        if(oldV<3){
            d.execSQL("CREATE TABLE IF NOT EXISTS relations(green TEXT, yellow TEXT, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(green,yellow))");
            d.execSQL("CREATE TABLE IF NOT EXISTS transitions(previous TEXT, next TEXT, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous,next))");
        }
        if(oldV<4){
            d.execSQL("CREATE TABLE IF NOT EXISTS analytics_samples(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, elapsed_ns INTEGER NOT NULL, green INTEGER NOT NULL, yellow INTEGER NOT NULL, confidence REAL NOT NULL)");
        }
        if(oldV<5){
            d.execSQL("CREATE TABLE IF NOT EXISTS readonly_events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, type TEXT NOT NULL, name TEXT NOT NULL, confidence REAL NOT NULL)");
        }
        if(oldV<6){
            d.execSQL("CREATE TABLE IF NOT EXISTS websocket_events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, direction TEXT NOT NULL, endpoint TEXT NOT NULL, bytes INTEGER NOT NULL, summary TEXT NOT NULL, confidence REAL NOT NULL)");
            d.execSQL("CREATE TABLE IF NOT EXISTS traffic_metadata(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, direction TEXT NOT NULL, endpoint TEXT NOT NULL, bytes INTEGER NOT NULL)");
            d.execSQL("CREATE TABLE IF NOT EXISTS correlations(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, summary TEXT NOT NULL)");
        }
        if(oldV<7){
            d.execSQL("CREATE TABLE IF NOT EXISTS interaction_references(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, label TEXT NOT NULL, before_state TEXT NOT NULL, after_state TEXT NOT NULL, row_idx INTEGER NOT NULL, col_idx INTEGER NOT NULL, confidence REAL NOT NULL)");
        }
        if(oldV<8){
            d.execSQL("CREATE TABLE IF NOT EXISTS hit_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, label TEXT NOT NULL, hit_count INTEGER NOT NULL, source TEXT NOT NULL, confidence REAL NOT NULL)");
        }
        if(oldV<9){
            d.execSQL("CREATE TABLE IF NOT EXISTS play_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, start_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL DEFAULT 0, last_hit_ms INTEGER NOT NULL DEFAULT 0, hit_count INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'OPEN')");
            d.execSQL("CREATE TABLE IF NOT EXISTS play_hits(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, ts_ms INTEGER NOT NULL, hit_no INTEGER NOT NULL, label TEXT NOT NULL, confidence REAL NOT NULL, next_label TEXT NOT NULL DEFAULT '', validation_pct INTEGER NOT NULL DEFAULT -1, FOREIGN KEY(session_id) REFERENCES play_sessions(id) ON DELETE CASCADE)");
            d.execSQL("CREATE TABLE IF NOT EXISTS play_links(previous_label TEXT NOT NULL, next_label TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous_label,next_label))");
        }
        if(oldV<10){
            d.execSQL("CREATE TABLE IF NOT EXISTS play_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, hit_no INTEGER NOT NULL, label TEXT NOT NULL, confidence REAL NOT NULL, next_label TEXT NOT NULL DEFAULT '', validation_pct INTEGER NOT NULL DEFAULT -1)");
            // Migrate legacy session-based hit rows into one continuous chronological log.
            Cursor mc=d.rawQuery("SELECT ts_ms,label,confidence,next_label,validation_pct FROM play_hits ORDER BY ts_ms ASC,id ASC",null);
            int no=0;
            while(mc.moveToNext()){
                no++;
                d.execSQL("INSERT INTO play_log(ts_ms,hit_no,label,confidence,next_label,validation_pct) VALUES(?,?,?,?,?,?)",new Object[]{mc.getLong(0),no,mc.getString(1),mc.getFloat(2),mc.getString(3),mc.getInt(4)});
            }
            mc.close();
        }
        if(oldV<11){
            d.execSQL("CREATE TABLE IF NOT EXISTS game_transitions(previous TEXT NOT NULL, next TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous,next))");
        }
    }

    /** Observed visual-symbol transition inside the selected live game region. */
    public synchronized void observeGameTransition(String previous, String next){
        if(previous==null||next==null||previous.isEmpty()||next.isEmpty()||previous.equals(next)) return;
        getWritableDatabase().execSQL("INSERT INTO game_transitions(previous,next,hits) VALUES(?,?,1) ON CONFLICT(previous,next) DO UPDATE SET hits=hits+1",new Object[]{previous,next});
    }

    /** Ranked next symbols for the current visual symbol, based only on observed transitions. */
    public synchronized List<String> rankedGameTransitions(String previous,int n){
        ArrayList<String> out=new ArrayList<>();
        if(previous==null||previous.isEmpty()) return out;
        Cursor c=getReadableDatabase().rawQuery("SELECT next,hits FROM game_transitions WHERE previous=? ORDER BY hits DESC,next ASC LIMIT ?",new String[]{previous,String.valueOf(Math.max(1,n))});
        Cursor tc=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(hits),0) FROM game_transitions WHERE previous=?",new String[]{previous});
        int total=0; if(tc.moveToFirst()) total=tc.getInt(0); tc.close();
        while(c.moveToNext()){ int hits=c.getInt(1); int pct=total>0?Math.round(100f*hits/total):0; out.add(c.getString(0)+"|"+pct+"|"+hits+"/"+total); }
        c.close(); return out;
    }

    public synchronized int gameTransitionCount(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(hits),0) FROM game_transitions",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
    }

    public synchronized void recordInteractionReference(long tsMs,String label,String beforeState,String afterState,int row,int col,float confidence){
        if(label==null||label.isEmpty()) return;
        getWritableDatabase().execSQL("INSERT INTO interaction_references(ts_ms,label,before_state,after_state,row_idx,col_idx,confidence) VALUES(?,?,?,?,?,?,?)",new Object[]{tsMs,label,beforeState==null?"":beforeState,afterState==null?"":afterState,row,col,confidence});
    }
    public synchronized List<String> recentInteractionReferences(int n){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT ts_ms,label,row_idx,col_idx,confidence FROM interaction_references ORDER BY id DESC LIMIT ?",new String[]{String.valueOf(Math.max(1,n))});
        while(c.moveToNext()) out.add(new java.text.SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date(c.getLong(0)))+" | "+c.getString(1)+" ["+c.getInt(2)+","+c.getInt(3)+"] | "+Math.round(c.getFloat(4)*100)+"%");
        c.close(); return out;
    }
    public synchronized int interactionReferenceCount(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM interaction_references",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
    }
    public synchronized void observeRelation(String green,String yellow){
        if(green==null||yellow==null||green.isEmpty()||yellow.isEmpty())return;
        getWritableDatabase().execSQL("INSERT INTO relations(green,yellow,hits) VALUES(?,?,1) ON CONFLICT(green,yellow) DO UPDATE SET hits=hits+1",new Object[]{green,yellow});
    }
    public synchronized int observeTransition(String previous,String next){
        getWritableDatabase().execSQL("INSERT INTO transitions(previous,next,hits) VALUES(?,?,1) ON CONFLICT(previous,next) DO UPDATE SET hits=hits+1",new Object[]{previous,next});
        Cursor c=getReadableDatabase().rawQuery("SELECT SUM(hits) FROM transitions WHERE previous=?",new String[]{previous});
        int n=0;if(c.moveToFirst())n=c.isNull(0)?0:c.getInt(0);c.close();return n;
    }
    public synchronized List<String> relationsFor(String green,int n){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT yellow,hits FROM relations WHERE green=? ORDER BY hits DESC LIMIT ?",new String[]{green,String.valueOf(n)});
        while(c.moveToNext()){
            int hits=c.getInt(1), total=relationTotal(green);
            int pct=total>0?Math.round(100f*hits/total):0;
            out.add("🟩 "+green+" ← 🟨 "+c.getString(0)+" | "+pct+"% ("+hits+"/"+total+")");
        }
        c.close(); return out;
    }

    public synchronized int relationHits(String green,String yellow){
        if(green==null||yellow==null) return 0;
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT hits FROM relations WHERE green=? AND yellow=?",
                new String[]{green,yellow});
        int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
    }

    public synchronized int bestRelationHits(String green){
        if(green==null) return 0;
        Cursor c=getReadableDatabase().rawQuery("SELECT MAX(hits) FROM relations WHERE green=?",new String[]{green});
        int n=0;if(c.moveToFirst())n=c.isNull(0)?0:c.getInt(0);c.close();return n;
    }

    public synchronized int interactionTestCount(String label){
        if(label==null||label.isEmpty()) return 0;
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM interaction_references WHERE label=?",new String[]{label});
        int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;
    }

    public synchronized int relationTotal(String green){
        if(green==null) return 0;
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(hits),0) FROM relations WHERE green=?",
                new String[]{green});
        int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
    }


    /** Returns observed transition strength for a visible/current state, without guessing. */
    public synchronized List<String> rankedTransitions(String previous, int n){
        ArrayList<String> out=new ArrayList<>();
        if(previous==null||previous.isEmpty()) return out;
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT next,hits FROM transitions WHERE previous=? ORDER BY hits DESC LIMIT ?",
                new String[]{previous,String.valueOf(Math.max(1,n))});
        int total=0;
        Cursor tc=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(hits),0) FROM transitions WHERE previous=?",new String[]{previous});
        if(tc.moveToFirst()) total=tc.isNull(0)?0:tc.getInt(0);
        tc.close();
        while(c.moveToNext()){
            int hits=c.getInt(1);
            int pct=total>0?Math.round(100f*hits/total):0;
            out.add(c.getString(0)+"|"+pct+"|"+hits+"/"+total);
        }
        c.close();
        return out;
    }

    public synchronized int transitionHits(String previous,String next){
        Cursor c=getReadableDatabase().rawQuery("SELECT hits FROM transitions WHERE previous=? AND next=?",new String[]{previous,next});
        int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;
    }

    public synchronized int bestTransitionCount(String previous){
        Cursor c=getReadableDatabase().rawQuery("SELECT MAX(hits) FROM transitions WHERE previous=?",new String[]{previous});
        int n=0;if(c.moveToFirst())n=c.isNull(0)?0:c.getInt(0);c.close();return n;
    }

    /**
     * Reports the longest currently learned run for a single transition.
     * This is historical continuity of the observed pattern, not a promise of a win.
     */
    public synchronized String continuitySummary(int limit){
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT next,MAX(hits) AS h FROM transitions GROUP BY next ORDER BY h DESC LIMIT ?",
                new String[]{String.valueOf(Math.max(1, limit))});
        StringBuilder s=new StringBuilder();
        while(c.moveToNext()){
            if(s.length()>0) s.append(" | ");
            int hits=c.getInt(1);
            int rounds=hits<=0?0:Math.min(5,hits);
            s.append(c.getString(0)).append(" → ");
            if(rounds>=5) s.append("5+ ضربات");
            else if(rounds==1) s.append("ضربة");
            else s.append(rounds).append(" ضربات");
        }
        c.close();
        return s.toString();
    }
    public void add(AnalysisResult r){
        StringBuilder t=new StringBuilder();
        for(Detector.Tile x:r.tiles){if(t.length()>0)t.append(',');t.append(x.label).append(':').append(String.format(Locale.US,"%.2f",x.similarity));}
        getWritableDatabase().execSQL("INSERT INTO events(ts,green,yellow,tiles,observed,confidence,recommendation) VALUES(?,?,?,?,?,?,?)",new Object[]{r.timestamp,r.green.size(),r.yellow.size(),t.toString(),r.observedChange,r.confidence,r.recommendation});
    }
    public List<String> recent(int n){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT ts,green,yellow,tiles,confidence,recommendation FROM events ORDER BY id DESC LIMIT ?",new String[]{String.valueOf(n)});
        while(c.moveToNext()){
            String rec=c.getString(5);
            out.add(new java.text.SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date(c.getLong(0)))+" | 🟩 "+c.getInt(1)+" | 🟨 "+c.getInt(2)+" | "+c.getString(3)+" | "+String.format(Locale.US,"%.0f%%",c.getDouble(4)*100)+(rec==null||rec.isEmpty()?"":"\n"+rec));
        } c.close(); return out;
    }
    public synchronized List<String> learnedRelations(int n){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT green,yellow,hits FROM relations ORDER BY hits DESC LIMIT ?",new String[]{String.valueOf(n)});
        while(c.moveToNext()) out.add("🟩 "+c.getString(0)+" ← 🟨 "+c.getString(1)+" | "+c.getInt(2)+" مشاهدة");
        c.close(); return out;
    }

    public synchronized List<String> learnedTransitions(int n){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT next,MAX(hits) FROM transitions GROUP BY next ORDER BY MAX(hits) DESC LIMIT ?",new String[]{String.valueOf(n)});
        while(c.moveToNext()) out.add("➡ "+c.getString(0)+" | "+c.getInt(1)+" مرات");
        c.close(); return out;
    }

    public synchronized void addAnalyticsSample(long tsMs,long elapsedNs,int green,int yellow,float confidence){
        getWritableDatabase().execSQL("INSERT INTO analytics_samples(ts_ms,elapsed_ns,green,yellow,confidence) VALUES(?,?,?,?,?)",new Object[]{tsMs,elapsedNs,green,yellow,confidence});
    }

    public synchronized int analyticsSampleCount(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM analytics_samples",null);
        int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;
    }

    /** Compact event history only; raw frames are never stored here. */
    public synchronized void recordReadOnlyEvent(long tsMs,String type,String name,float confidence){
        if(type==null||name==null) return;
        getWritableDatabase().execSQL("INSERT INTO readonly_events(ts_ms,type,name,confidence) VALUES(?,?,?,?)",new Object[]{tsMs,type,name,confidence});
    }

    public synchronized List<String> recentReadOnlyEvents(int n){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT ts_ms,type,name,confidence FROM readonly_events ORDER BY id DESC LIMIT ?",new String[]{String.valueOf(Math.max(1,n))});
        while(c.moveToNext()) out.add(new java.text.SimpleDateFormat("HH:mm:ss.SSS",Locale.getDefault()).format(new Date(c.getLong(0)))+" | "+c.getString(1)+" | "+c.getString(2)+" | "+String.format(Locale.US,"%.0f%%",c.getDouble(3)*100));
        c.close(); return out;
    }

    public String stats(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*),AVG(confidence),SUM(green),SUM(yellow) FROM events",null);
        String s="لا توجد بيانات بعد";
        if(c.moveToFirst())s="الرصد: "+c.getInt(0)+" | متوسط الثقة: "+String.format(Locale.US,"%.0f%%",c.isNull(1)?0:c.getDouble(1)*100)+" | 🟩 "+c.getInt(2)+" | 🟨 "+c.getInt(3);
        c.close(); return s;
    }
    public synchronized void recordWebSocketEvent(long tsMs,String direction,String endpoint,int bytes,String summary,float confidence){
        getWritableDatabase().execSQL("INSERT INTO websocket_events(ts_ms,direction,endpoint,bytes,summary,confidence) VALUES(?,?,?,?,?,?)",new Object[]{tsMs,direction,endpoint,bytes,summary,confidence});
    }
    public synchronized List<String> recentWebSocketEvents(int n){
        ArrayList<String> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT ts_ms,direction,endpoint,bytes,summary,confidence FROM websocket_events ORDER BY id DESC LIMIT ?",new String[]{String.valueOf(Math.max(1,n))});
        while(c.moveToNext()) out.add(new java.text.SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date(c.getLong(0)))+" | WS "+c.getString(1)+" | "+c.getString(2)+" | "+c.getInt(3)+"B | "+c.getString(4)+" | "+Math.round(c.getFloat(5)*100)+"%");
        c.close(); return out;
    }
    public synchronized void recordTrafficMetadata(long tsMs,String direction,String endpoint,int bytes){
        getWritableDatabase().execSQL("INSERT INTO traffic_metadata(ts_ms,direction,endpoint,bytes) VALUES(?,?,?,?)",new Object[]{tsMs,direction,endpoint,bytes});
    }
    public synchronized void recordCorrelation(long tsMs,String summary){
        getWritableDatabase().execSQL("INSERT INTO correlations(ts_ms,summary) VALUES(?,?)",new Object[]{tsMs,summary});
    }

    /** Explicit user action only: removes all stored learning/history records.
     * Nothing in the monitoring loop calls this method, so closing/restarting the app
     * never clears the history automatically.
     */
    public synchronized void clearAllHistory() {
        SQLiteDatabase d = getWritableDatabase();
        d.beginTransaction();
        try {
            d.execSQL("DELETE FROM events");
            d.execSQL("DELETE FROM relations");
            d.execSQL("DELETE FROM transitions");
            d.execSQL("DELETE FROM analytics_samples");
            d.execSQL("DELETE FROM readonly_events");
            d.execSQL("DELETE FROM websocket_events");
            d.execSQL("DELETE FROM traffic_metadata");
            d.execSQL("DELETE FROM correlations");
            d.execSQL("DELETE FROM interaction_references");
            d.execSQL("DELETE FROM hit_plans");
            d.execSQL("DELETE FROM play_hits");
            d.execSQL("DELETE FROM play_sessions");
            d.execSQL("DELETE FROM play_links");
            d.execSQL("DELETE FROM play_log");
            d.setTransactionSuccessful();
        } finally {
            d.endTransaction();
        }
    }

    /**
     * Records one real observed/manual hit in a single continuous history.
     * There are intentionally NO user-visible sessions: every hit is its own row
     * and the chronological order is the sequence the user can keep or delete.
     */
    public synchronized long recordPlayHit(String label,float confidence,long nowMs) {
        if(label==null||label.isEmpty()) return 0;
        SQLiteDatabase d=getWritableDatabase();
        int hitNo=1;
        Cursor c=d.rawQuery("SELECT COALESCE(MAX(hit_no),0)+1 FROM play_log",null);
        if(c.moveToFirst()) hitNo=c.getInt(0); c.close();

        long previousId=0; String previousLabel="";
        Cursor pc=d.rawQuery("SELECT id,label FROM play_log ORDER BY hit_no DESC,id DESC LIMIT 1",null);
        if(pc.moveToFirst()){ previousId=pc.getLong(0); previousLabel=pc.getString(1); } pc.close();

        d.execSQL("INSERT INTO play_log(ts_ms,hit_no,label,confidence) VALUES(?,?,?,?)",new Object[]{nowMs,hitNo,label,confidence});
        Cursor idc=d.rawQuery("SELECT last_insert_rowid()",null); long hid=0; if(idc.moveToFirst()) hid=idc.getLong(0); idc.close();

        if(previousId>0 && !previousLabel.isEmpty()){
            d.execSQL("INSERT INTO play_links(previous_label,next_label,hits) VALUES(?,?,1) ON CONFLICT(previous_label,next_label) DO UPDATE SET hits=hits+1",new Object[]{previousLabel,label});
            Cursor tc=d.rawQuery("SELECT COALESCE(SUM(hits),0) FROM play_links WHERE previous_label=?",new String[]{previousLabel}); int total=0; if(tc.moveToFirst()) total=tc.getInt(0); tc.close();
            Cursor lc=d.rawQuery("SELECT hits FROM play_links WHERE previous_label=? AND next_label=?",new String[]{previousLabel,label}); int hits=0; if(lc.moveToFirst()) hits=lc.getInt(0); lc.close();
            int pct=total>0?Math.round(100f*hits/total):0;
            d.execSQL("UPDATE play_log SET next_label=?,validation_pct=? WHERE id=?",new Object[]{label,pct,previousId});
        }
        return hid;
    }

    /** Flat chronological hit list; no grouping into sessions. */
    /** Returns only observed labels in chronological order for local pattern summaries. */
    public synchronized List<String> recentPlayLabels(int limit){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT label FROM play_log ORDER BY hit_no DESC,id DESC LIMIT ?",
                new String[]{String.valueOf(Math.max(1,limit))});
        while(c.moveToNext()){
            String label=c.getString(0);
            if(label!=null && !label.isEmpty()) out.add(label);
        }
        c.close();
        Collections.reverse(out);
        return out;
    }

    public synchronized List<String> playLog(int limit){
        ArrayList<String> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,ts_ms,hit_no,label,confidence,next_label,validation_pct FROM play_log ORDER BY hit_no DESC,id DESC LIMIT ?",new String[]{String.valueOf(Math.max(1,limit))});
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("dd/MM HH:mm:ss",Locale.getDefault());
        while(c.moveToNext()){
            long id=c.getLong(0); String next=c.getString(5); int pct=c.getInt(6);
            String validation=pct<0?"تحقق: —":("تحقق: "+pct+"%");
            String after=(next==null||next.isEmpty())?"":" → بعدها: "+next;
            out.add("ضربة "+c.getInt(2)+": "+c.getString(3)+" | "+f.format(new Date(c.getLong(1)))+" | ثقة "+Math.round(c.getFloat(4)*100)+"% | "+validation+after+" | ID="+id);
        }
        c.close(); return out;
    }

    /** Deletes ONE hit only, then rebuilds the chronological links around the remaining hits. */
    public synchronized void deletePlayHit(long hitId){
        SQLiteDatabase d=getWritableDatabase(); d.beginTransaction();
        try {
            d.execSQL("DELETE FROM play_log WHERE id=?",new Object[]{hitId});
            rebuildPlayLogLinks(d);
            d.setTransactionSuccessful();
        } finally { d.endTransaction(); }
    }

    private void rebuildPlayLogLinks(SQLiteDatabase d){
        d.execSQL("DELETE FROM play_links");
        d.execSQL("UPDATE play_log SET next_label='',validation_pct=-1");
        Cursor c=d.rawQuery("SELECT id,label FROM play_log ORDER BY hit_no ASC,id ASC",null);
        long previousId=0; String previousLabel="";
        while(c.moveToNext()){
            long id=c.getLong(0); String label=c.getString(1);
            if(previousId>0 && !previousLabel.isEmpty()){
                d.execSQL("INSERT INTO play_links(previous_label,next_label,hits) VALUES(?,?,1) ON CONFLICT(previous_label,next_label) DO UPDATE SET hits=hits+1",new Object[]{previousLabel,label});
            }
            previousId=id; previousLabel=label;
        }
        c.close();
        Cursor p=d.rawQuery("SELECT id,label FROM play_log WHERE next_label='' ORDER BY hit_no ASC,id ASC",null);
        // Fill each row's immediate next hit and observed transition percentage.
        ArrayList<long[]> ids=new ArrayList<>(); ArrayList<String> labels=new ArrayList<>();
        p.close();
        Cursor q=d.rawQuery("SELECT id,label FROM play_log ORDER BY hit_no ASC,id ASC",null);
        while(q.moveToNext()){ids.add(new long[]{q.getLong(0)}); labels.add(q.getString(1));}
        q.close();
        for(int i=0;i+1<labels.size();i++){
            String prev=labels.get(i), next=labels.get(i+1);
            Cursor tc=d.rawQuery("SELECT COALESCE(SUM(hits),0) FROM play_links WHERE previous_label=?",new String[]{prev}); int total=0; if(tc.moveToFirst()) total=tc.getInt(0); tc.close();
            Cursor lc=d.rawQuery("SELECT hits FROM play_links WHERE previous_label=? AND next_label=?",new String[]{prev,next}); int hits=0; if(lc.moveToFirst()) hits=lc.getInt(0); lc.close();
            int pct=total>0?Math.round(100f*hits/total):0;
            d.execSQL("UPDATE play_log SET next_label=?,validation_pct=? WHERE id=?",new Object[]{next,pct,ids.get(i)[0]});
        }
    }

    /** Records an exact observed hit-count plan. No synthetic counts are created. */
    public synchronized void observeHitPlan(String label,int hitCount,String source,float confidence){
        if(label==null||label.isEmpty()||hitCount<=0)return;
        getWritableDatabase().execSQL(
                "INSERT INTO hit_plans(ts_ms,label,hit_count,source,confidence) VALUES(?,?,?,?,?)",
                new Object[]{System.currentTimeMillis(),label,hitCount,source==null?"":source,confidence});
    }

    /** Returns the strongest exact observed plan as: xN|observations|confidence. */
    public synchronized String bestHitPlan(String label){
        if(label==null||label.isEmpty()) return "";
        Cursor c=getReadableDatabase().rawQuery(
                "SELECT hit_count,COUNT(*),AVG(confidence) FROM hit_plans WHERE label=? GROUP BY hit_count ORDER BY COUNT(*) DESC, AVG(confidence) DESC, hit_count ASC LIMIT 1",
                new String[]{label});
        String out="";
        if(c.moveToFirst()){
            int hits=c.getInt(0), observations=c.getInt(1);
            int confidence=Math.round(c.getFloat(2)*100f);
            out="x"+hits+"|"+observations+"|"+confidence+"%";
        }
        c.close();
        return out;
    }

    /** Legacy session close hook retained for compatibility; history is now flat. */
    public synchronized void endPlaySession(long nowMs){
        SQLiteDatabase d=getWritableDatabase();
        d.execSQL("UPDATE play_sessions SET end_ms=?, status='CLOSED' WHERE status='OPEN'",new Object[]{nowMs});
    }

    public synchronized int playLogCount(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM play_log",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;
    }

    /** Number of persisted observation rows across the learning/history tables. */
    public synchronized long storedRecordCount() {
        SQLiteDatabase d=getReadableDatabase();
        long total=0;
        String[] tables={"events","relations","transitions","analytics_samples","readonly_events",
                "websocket_events","traffic_metadata","correlations","interaction_references","hit_plans","play_sessions","play_hits","play_links","play_log"};
        for(String table:tables){
            Cursor c=d.rawQuery("SELECT COUNT(*) FROM "+table,null);
            if(c.moveToFirst()) total += c.getLong(0);
            c.close();
        }
        return total;
    }

}
