# v31.9 Observational Chain & Risk

- Added local five-step **observed sequence** history.
- Added observational win/loss streak tracking.
- The overlay reports observed history only.
- Future outcome prediction and real wager/stake recommendations are not surfaced.
- Existing screen capture remains RAM-only; no screenshots are written by this change.

## Universal Game Router integration
- Expanded GameRouter to score OCR + green/yellow inventory markers + lightweight visual/layout fingerprints.
- Added profiles for lucky gifts, card games, dragon/tiger, baccarat, poker, dice, wheel/roulette, crash, table, instant/arcade, and sports screens.
- Added confidence/evidence reporting and two-frame stabilization to avoid mode flapping.
- Router remains read-only: it does not click, submit bets, or control the game.
