# v44 — Live Sequential Hit Reader

- The user-selected read rectangle is now the direct input to a dedicated live game-grid reader.
- The reader samples the 5x3 game board inside that rectangle and waits for a stable frame before committing a new board state.
- Visual symbols are assigned persistent local IDs from their real appearance; no screenshots are stored.
- Observed symbol-to-symbol transitions are persisted in `game_transitions` and kept separate from Mahzooz room relations.
- The live overlay now shows sequential observed suggestions as:
  - `ضربة 1: <symbol> | <percentage>% | hits/total`
  - `ضربة 2: <symbol> | <percentage>% | hits/total`
  - etc.
- Suggestions refresh automatically whenever the captured game state changes or the detected game/system mode changes.
- Percentages are calculated from observed transition frequency only; no synthetic 95%/85% values are inserted.
- The existing one-finger drag, two-finger resize, region selector, OCR, and room/inventory logic remain intact.
