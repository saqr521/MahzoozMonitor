# v20.1 — Pre-Play Decision Layer

- Added an evidence-only pre-play ranking for currently visible icons.
- Uses learned interaction references, observed transitions, and green→yellow relation evidence.
- The live overlay now presents the ranked choice before play instead of waiting for a new play.
- No fabricated win probability or required-hit count is generated.
- Preserves all v20 read-only, performance, CV, persistence, and safety boundaries.
