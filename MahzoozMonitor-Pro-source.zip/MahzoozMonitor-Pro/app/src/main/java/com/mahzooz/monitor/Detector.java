package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.*;

public final class Detector {
    public static class Marker {
        public int x,y,w,h; public float score;
        Marker(int x,int y,int w,int h,float s){this.x=x;this.y=y;this.w=w;this.h=h;this.score=s;}
        @Override public String toString(){return "("+x+","+y+","+w+"x"+h+","+Math.round(score*100)+"%)";}
    }

    public static List<Marker> find(Bitmap b, boolean green) {
        int W=b.getWidth(), H=b.getHeight();
        int sx=Math.max(1,W/180), sy=Math.max(1,H/360);
        boolean[][] hit=new boolean[(H+sy-1)/sy][(W+sx-1)/sx];
        for(int y=0,yy=0;y<H;y+=sy,yy++) for(int x=0,xx=0;x<W;x+=sx,xx++){
            int c=b.getPixel(x,y), r=Color.red(c), g=Color.green(c), bl=Color.blue(c);
            float[] hsv=new float[3]; Color.RGBToHSV(r,g,bl,hsv);
            boolean ok = green ? (hsv[0]>75&&hsv[0]<155&&hsv[1]>.45f&&hsv[2]>.35f)
                               : (hsv[0]>35&&hsv[0]<75&&hsv[1]>.35f&&hsv[2]>.45f);
            hit[yy][xx]=ok;
        }
        List<Marker> out=new ArrayList<>();
        int gh=hit.length, gw=hit[0].length;
        for(int yy=0;yy<gh;yy++) for(int xx=0;xx<gw;xx++) if(hit[yy][xx]){
            int count=0,x0=xx,x1=xx,y0=yy,y1=yy;
            for(int y=Math.max(0,yy-4);y<=Math.min(gh-1,yy+4);y++)
                for(int x=Math.max(0,xx-4);x<=Math.min(gw-1,xx+4);x++)
                    if(hit[y][x]){count++;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
            if(count>=8){
                float s=Math.min(1f,count/35f);
                out.add(new Marker(x0*sx,y0*sy,(x1-x0+1)*sx,(y1-y0+1)*sy,s));
            }
        }
        return dedupe(out);
    }

    private static List<Marker> dedupe(List<Marker> in){
        List<Marker> o=new ArrayList<>();
        for(Marker m:in){
            boolean dup=false;
            for(Marker n:o){
                int dx=Math.abs(m.x-n.x), dy=Math.abs(m.y-n.y);
                if(dx<Math.max(m.w,n.w) && dy<Math.max(m.h,n.h)){dup=true;break;}
            }
            if(!dup)o.add(m);
        }
        return o;
    }
}
