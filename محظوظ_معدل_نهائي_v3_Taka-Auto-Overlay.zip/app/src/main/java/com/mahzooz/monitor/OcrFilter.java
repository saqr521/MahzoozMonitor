package com.mahzooz.monitor;

/** Prevents repeated OCR work/results from the same live screen. */
public final class OcrFilter {
    private final long minIntervalMs;
    private long lastAttemptAt;
    private String lastText = "";
    private long lastAcceptedAt;

    public OcrFilter(long minIntervalMs) {
        this.minIntervalMs = Math.max(300L, minIntervalMs);
    }

    /** Returns true when enough time has passed to run OCR again. */
    public synchronized boolean allow(long now) {
        if (lastAttemptAt != 0L && now - lastAttemptAt < minIntervalMs) return false;
        lastAttemptAt = now;
        return true;
    }

    /** Returns true only for a materially new OCR string. */
    public synchronized boolean accept(String text, long now) {
        String normalized = normalize(text);
        if (normalized.isEmpty()) return false;
        if (normalized.equals(lastText)) return false;
        lastText = normalized;
        lastAcceptedAt = now;
        return true;
    }

    public synchronized long lastAcceptedAt() { return lastAcceptedAt; }

    public static String normalize(String text) {
        if (text == null) return "";
        return text.replace('\u200B',' ')
                .replaceAll("\\s+", " ")
                .trim();
    }
}
