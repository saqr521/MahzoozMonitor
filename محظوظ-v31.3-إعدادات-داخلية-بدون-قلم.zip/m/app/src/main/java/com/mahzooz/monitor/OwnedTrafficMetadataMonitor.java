package com.mahzooz.monitor;

/** Metadata sink for connections explicitly owned by this monitor/app. No packet capture or TLS decryption. */
public final class OwnedTrafficMetadataMonitor {
    private final HistoryDb db;
    public OwnedTrafficMetadataMonitor(HistoryDb database){db=database;}
    public synchronized void recordInbound(String endpoint,int bytes){record("INBOUND",endpoint,bytes);}
    public synchronized void recordOutbound(String endpoint,int bytes){record("OUTBOUND",endpoint,bytes);}
    public boolean capturesPackets(){return false;}
    public boolean decryptsTls(){return false;}
    private void record(String direction,String endpoint,int bytes){
        long ts=System.currentTimeMillis(); String ep=endpoint==null?"":endpoint;
        if(db!=null) db.recordTrafficMetadata(ts,direction,ep,Math.max(0,bytes));
        AlgorithmTrace.recordTrafficMetadata(direction,ep,Math.max(0,bytes));
    }
}
