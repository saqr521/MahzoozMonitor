# Mahzooz v46 — Final repair

- Simplified project archive name to `Mahzooz-v46.zip` for GitHub Actions upload.
- Workflow now uses that exact ZIP name and never selects an older ZIP by wildcard.
- Live grid reader respects the selected read rectangle and no longer manufactures symbols for flat/background cells.
- Grid detection requires visual evidence before reporting a valid grid.
- Live results are no longer blocked solely because OCR/accessibility did not confirm the Taka interface.
- Existing observed-only history, transitions, relations, and confidence percentages remain intact; the app does not invent win probabilities.
- Final APK artifact remains `Mahzooz-debug.apk`.


## v46 visual-reader correction
- Corrected the live board geometry to support the observed Taka 5-column × 2-row board.
- Added semantic visual prototypes for the four visible board symbols: كلب، أرنب، باندا، دب.
- Removed the old arbitrary visual-symbol namespace that could surface values such as "رمز 81".
- OCR text such as "Time is money" is no longer accepted as the game title.
- The overlay identifies a visually detected Taka board instead of inventing a game name.
- Historical suggestions are filtered to known board symbols; no fake confidence is generated when there is insufficient history.
