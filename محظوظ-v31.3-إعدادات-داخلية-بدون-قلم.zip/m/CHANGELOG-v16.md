# محظوظ v16 / 6.8.0

## Performance layer
- Added bounded parallel worker pool for independent read-only analysis tasks.
- Added NumPy-style vectorized primitive-array math utilities for fast numeric operations.
- Added hardware capability probing for OpenCV native backend, ARM NEON, and Android render-thread availability.
- Added multiprocessing boundary: Android process isolation is documented/available for components owned by this app only; no attachment to the game process.
- Added runtime telemetry for worker count, vectorization backend, hardware capabilities, and process-isolation status.
- Existing OpenCV, optical flow, screenshots, WebSocket read-only monitoring, event correlation, traffic metadata, and safety boundaries are preserved.

## Safety
- No packet interception/decryption.
- No private game-memory access.
- No Frida injection or hooks into the game process.
- No automated input/control of the game.
