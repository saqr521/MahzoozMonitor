package com.mahzooz.monitor;

/**
 * Observational rate tracker. A valid outcome must be supplied by an explicitly
 * visible result; it never infers wins/losses from a visual transition.
 */
public final class RtpTrackingAlgorithm {
    private long observations;
    private long positiveOutcomes;
    private double observedReturn;
    private double observedStake;

    public synchronized void observeOutcome(boolean positive,double returnValue,double stake){
        if(stake<=0 || !Double.isFinite(returnValue)) return;
        observations++;
        if(positive) positiveOutcomes++;
        observedReturn += returnValue;
        observedStake += stake;
    }
    public synchronized long observations(){return observations;}
    public synchronized long positiveOutcomes(){return positiveOutcomes;}
    public synchronized double observedRtp(){return observedStake<=0?0:observedReturn/observedStake;}
    public synchronized double positiveRate(){return observations==0?0:(double)positiveOutcomes/observations;}
}
