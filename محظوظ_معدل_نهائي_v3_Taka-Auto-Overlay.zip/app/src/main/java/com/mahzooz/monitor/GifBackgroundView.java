package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.io.InputStream;

/** Lightweight GIF renderer used only for the main screen background. */
public class GifBackgroundView extends View {
    private Movie movie;
    private long startTime;

    public GifBackgroundView(Context context) {
        super(context);
        init();
    }

    public GifBackgroundView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        try (InputStream in = getResources().openRawResource(com.mahzooz.monitor.R.drawable.mahzooz_fire)) {
            movie = Movie.decodeStream(in);
        } catch (Exception ignored) {
            movie = null;
        }
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        startTime = SystemClock.uptimeMillis();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (movie == null) return;

        int duration = movie.duration() <= 0 ? 1000 : movie.duration();
        int relTime = (int) ((SystemClock.uptimeMillis() - startTime) % duration);
        movie.setTime(relTime);

        float sx = getWidth() / (float) movie.width();
        float sy = getHeight() / (float) movie.height();
        float scale = Math.max(sx, sy); // cover the whole screen
        float drawW = movie.width() * scale;
        float drawH = movie.height() * scale;
        float left = (getWidth() - drawW) / 2f;
        float top = (getHeight() - drawH) / 2f;

        canvas.save();
        canvas.translate(left, top);
        canvas.scale(scale, scale);
        movie.draw(canvas, 0, 0);
        canvas.restore();
        postInvalidateOnAnimation();
    }
}
