package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.media.Image;
import java.nio.ByteBuffer;

public final class ImageUtils {
    private ImageUtils() {}

    public static Bitmap toBitmap(Image image) {
        Image.Plane p = image.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int ps = p.getPixelStride();
        int rs = p.getRowStride();
        int w = image.getWidth();
        int h = image.getHeight();
        int padding = Math.max(0, rs - ps * w);
        int paddedWidth = w + (ps > 0 ? padding / ps : 0);
        Bitmap bitmap = Bitmap.createBitmap(paddedWidth, h, Bitmap.Config.ARGB_8888);
        buf.rewind();
        bitmap.copyPixelsFromBuffer(buf);
        if (paddedWidth != w) {
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, w, h);
            if (cropped != bitmap) bitmap.recycle();
            bitmap = cropped;
        }
        return bitmap;
    }
}
