package com.mahzooz.monitor;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Settings dedicated to the Mahzooz monitoring profile. */
public class MahzoozGameSettingsActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(9, 14, 20));

        TextView title = new TextView(this);
        title.setText("إعدادات لعبة المحظوظ");
        title.setTextColor(Color.WHITE); title.setTextSize(25); title.setGravity(Gravity.RIGHT);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, params(0, 0, dp(64)));

        add(root, "المراقبة وتحليل الشاشة", "بدء أو إيقاف الالتقاط واللوحة العائمة", v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        add(root, "التعلّم والاستكشاف", "تعليم العناصر وحفظ العلاقات المكتشفة", v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        add(root, "سجل اللعب والبيانات", "النتائج والعلاقات والتسلسلات المحفوظة", v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        add(root, "الصلاحيات", "الظهور فوق التطبيقات وإمكانية الوصول", v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        setContentView(root);
    }
    private void add(LinearLayout root, String title, String desc, android.view.View.OnClickListener l) {
        Button b = new Button(this); b.setText(title + "\n" + desc); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL); b.setOnClickListener(l);
        root.addView(b, params(0, dp(10), dp(76)));
    }
    private LinearLayout.LayoutParams params(int top, int bottom, int h) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h); p.topMargin=top; p.bottomMargin=bottom; return p; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
