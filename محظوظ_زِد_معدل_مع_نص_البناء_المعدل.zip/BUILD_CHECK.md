# Build check — latest repair pass

- Source archive inspected: `Mahzooz.zip`.
- No `app/src/main/assets/icon_templates/` directory is present in this archive.
- `TakaGameKnowledge.java`, `TakaReferenceCatalog.java`, `MartingaleManager.java`,
  `taka_reference_map.tsv`, and `taka_verified_resources.tsv` are present.
- All `R.id.*` references used by Java source were checked against resource IDs; no missing IDs were found.
- The live read-region selector and analyzer use the same `game_selection/read_region_*` keys.
- The dashboard signal text now uses real line breaks instead of literal `\n`.
- The Android build could not be executed in this environment because the Gradle 8.10.2
  distribution is not cached and outbound access to services.gradle.org is unavailable.
- No source/resource files were intentionally deleted during this repair pass.

The app remains read-only with respect to the target game: it observes the screen and reports
observed signals/history; it does not click or place wagers.
