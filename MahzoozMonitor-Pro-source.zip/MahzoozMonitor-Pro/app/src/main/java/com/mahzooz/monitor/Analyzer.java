package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.Image;
import java.nio.ByteBuffer;
import java.util.*;

public class Analyzer {
    private final Context ctx;
    private long last;
    public Analyzer(Context c) { ctx=c; }

    public AnalysisResult analyze(Image image) {
        int w=image.getWidth(), h=image.getHeight();
        Image.Plane p=image.getPlanes()[0];
        ByteBuffer buf=p.getBuffer();
        int pixelStride=p.getPixelStride(), rowStride=p.getRowStride();
        int rowPadding=rowStride-pixelStride*w;
        Bitmap bmp=Bitmap.createBitmap(w+rowPadding/pixelStride,h,Bitmap.Config.ARGB_8888);
        bmp.copyPixelsFromBuffer(buf);
        Bitmap cropped=Bitmap.createBitmap(bmp,0,0,w,h);
        List<Detector.Marker> green=Detector.find(cropped,true);
        List<Detector.Marker> yellow=Detector.find(cropped,false);
        float c=(green.isEmpty()&&yellow.isEmpty())?0.0f:
            Math.min(1f,(green.size()+yellow.size())/6f);
        if (cropped != bmp) cropped.recycle();
        bmp.recycle();
        last=System.currentTimeMillis();
        return new AnalysisResult(last,green,yellow,c);
    }
}
