package com.mahzooz.monitor;

/**
 * Documents the Android equivalent of multiprocessing. Heavy analysis stays
 * in bounded worker threads; a separate Android process can be enabled later
 * for owned components, but this boundary never attaches to the game process.
 */
public final class MultiprocessingBoundary {
    public boolean allowedForOwnProcessOnly() { return true; }
    public boolean attachesToGameProcess() { return false; }
    public String status() { return "OWN_PROCESS_ONLY"; }
}
