package com.mahzooz.monitor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses result data that has already been delivered to this app through an
 * app-owned/exported data source. It does not open sockets, bypass TLS, or
 * inspect another application's private traffic.
 */
public final class ReadOnlyResultDataParser {
    public static final class Result {
        public final String game;
        public final String spin;
        public final String result;
        public final String raw;
        public final long timestampMs;
        public final float confidence;

        Result(String game, String spin, String result, String raw, long ts, float confidence) {
            this.game = safe(game); this.spin = safe(spin); this.result = safe(result);
            this.raw = safe(raw); this.timestampMs = ts; this.confidence = confidence;
        }
        public boolean hasResult() { return !result.isEmpty(); }
        public String displayText() {
            StringBuilder s = new StringBuilder();
            if (!game.isEmpty()) s.append("اللعبة: ").append(game).append('\n');
            if (!spin.isEmpty()) s.append("الجولة: ").append(spin).append('\n');
            s.append(hasResult() ? "النتيجة: " + result : "النتيجة: غير متاحة");
            return s.toString();
        }
    }

    private static final Pattern KV = Pattern.compile("(?i)(?:^|[&,;\\s])(?:game|idgame|game_name|spin|result|value|outcome)\\s*[=:]\\s*([^&,;\\s]+)");

    private ReadOnlyResultDataParser() {}

    public static Result parse(String raw) {
        String input = raw == null ? "" : raw.trim();
        if (input.isEmpty()) return new Result("", "", "", "", System.currentTimeMillis(), 0f);
        try {
            if (input.startsWith("{") && input.endsWith("}")) {
                JSONObject o = new JSONObject(input);
                String game = first(o, "game", "idgame", "game_name");
                String spin = first(o, "spin", "round", "round_id");
                String result = first(o, "result", "value", "outcome", "symbol");
                if (result.isEmpty()) result = findNestedResult(o);
                return new Result(game, spin, result, input, System.currentTimeMillis(), result.isEmpty() ? .25f : .95f);
            }
        } catch (Throwable ignored) { }

        String game = match(input, "game|idgame|game_name");
        String spin = match(input, "spin|round|round_id");
        String result = match(input, "result|value|outcome|symbol");
        float confidence = result.isEmpty() ? .20f : .80f;
        return new Result(game, spin, result, input, System.currentTimeMillis(), confidence);
    }

    private static String findNestedResult(JSONObject o) {
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next();
            try {
                Object v = o.get(k);
                if (v instanceof JSONObject) {
                    String r = first((JSONObject)v, "result", "value", "outcome", "symbol");
                    if (!r.isEmpty()) return r;
                } else if (v instanceof JSONArray) {
                    JSONArray a = (JSONArray)v;
                    for (int i=0;i<a.length();i++) if (a.opt(i) instanceof JSONObject) {
                        String r = first((JSONObject)a.opt(i), "result", "value", "outcome", "symbol");
                        if (!r.isEmpty()) return r;
                    }
                }
            } catch (Throwable ignored) { }
        }
        return "";
    }

    private static String first(JSONObject o, String... keys) {
        for (String k : keys) if (o.has(k) && !o.isNull(k)) {
            String v = String.valueOf(o.opt(k)).trim();
            if (!v.isEmpty() && !"null".equalsIgnoreCase(v)) return v;
        }
        return "";
    }

    private static String match(String input, String keys) {
        Pattern p = Pattern.compile("(?i)(?:^|[&,;\\s])(?:" + keys + ")\\s*[=:]\\s*([^&,;\\s]+)");
        Matcher m = p.matcher(input);
        return m.find() ? m.group(1) : "";
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }
}
