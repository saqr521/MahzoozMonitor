package com.mahzooz.monitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/** Settings for the monitor itself. The game is never modified here. */
public class SettingsActivity extends Activity {
    private HistoryDb db;
    private TextView count;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new HistoryDb(this);
        build();
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);
        root.setBackgroundColor(Color.rgb(8,17,29));

        TextView title=new TextView(this);
        title.setText("⚙️ إعدادات محظوظ"); title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));

        TextView subtitle=new TextView(this);
        subtitle.setText("إعدادات البرنامج وسجل اللعب المحفوظ"); subtitle.setTextSize(15);
        subtitle.setTextColor(Color.LTGRAY); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,8,0,20);
        root.addView(subtitle);

        Button history=new Button(this);
        history.setText("🥊  سجل اللعب — الضربات والتحقق"); history.setTextSize(17);
        history.setOnClickListener(v->showPlayLog()); root.addView(history,new LinearLayout.LayoutParams(-1,62));

        count=new TextView(this); count.setTextColor(Color.rgb(80,230,140)); count.setTextSize(15);
        count.setGravity(Gravity.CENTER); count.setPadding(0,12,0,12); root.addView(count);

        TextView note=new TextView(this);
        note.setText("✓ كل ضربة تظهر كسطر مستقل بالترتيب\n"+
                "✓ الضربة التالية تُكتب أمام السابقة لفهم التسلسل\n"+
                "✓ لو خسرت ضربة، احذف هذه الضربة وحدها فقط\n"+
                "✓ باقي الضربات تظل محفوظة والتسلسل يُعاد حسابه بينها\n"+
                "✓ السجل لا يُمسح عند إغلاق البرنامج أو التوقف عن اللعب\n"+
                "✓ النتيجة أو المكسب لا يظهر إلا إذا تم رصده فعليًا");
        note.setTextColor(Color.WHITE); note.setTextSize(15); note.setPadding(16,12,16,18); root.addView(note);

        Button allHistory=new Button(this);
        allHistory.setText("📊  المشاهدات والعلاقات العامة");
        allHistory.setOnClickListener(v->showGeneralHistory()); root.addView(allHistory,new LinearLayout.LayoutParams(-1,58));

        Button delete=new Button(this); delete.setText("🗑️  مسح كل البيانات يدويًا"); delete.setTextSize(16);
        delete.setOnClickListener(v->confirmDeleteAll()); root.addView(delete,new LinearLayout.LayoutParams(-1,60));

        Button close=new Button(this); close.setText("رجوع"); close.setOnClickListener(v->finish());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,60); cp.topMargin=18; root.addView(close,cp);
        setContentView(root); refreshCount();
    }

    @Override protected void onResume(){super.onResume(); if(db!=null) refreshCount();}
    private void refreshCount(){count.setText("الضربات المحفوظة: "+db.playLogCount()+" | إجمالي السجلات: "+db.storedRecordCount());}

    private void showPlayLog(){
        List<String> rows=db.playLog(500);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(8,8,8,8);
        if(rows.isEmpty()){
            TextView empty=new TextView(this); empty.setText("لا توجد ضربات محفوظة بعد.\nابدأ المراقبة والعب يدويًا وستظهر كل ضربة هنا.");
            empty.setTextSize(16); empty.setTextColor(Color.WHITE); empty.setPadding(16,24,16,24); list.addView(empty);
        } else {
            for(String line:rows){
                long id=parseId(line);
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(4,4,4,4);
                TextView text=new TextView(this); text.setText("• "+line.replace(" | ID="+id,"")); text.setTextSize(15); text.setTextColor(Color.WHITE); text.setPadding(8,8,8,8);
                row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
                Button del=new Button(this); del.setText("🗑️"); del.setContentDescription("حذف هذه الضربة فقط");
                del.setOnClickListener(v->confirmDeleteHit(id)); row.addView(del,new LinearLayout.LayoutParams(60,60));
                list.addView(row);
            }
        }
        ScrollView scroll=new ScrollView(this); scroll.addView(list);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("🥊 سجل اللعب — كل ضربة مستقلة").setView(scroll).setPositiveButton("إغلاق",null).create();
        dialog.show();
    }

    private long parseId(String line){try{int p=line.lastIndexOf("ID="); return Long.parseLong(line.substring(p+3).trim());}catch(Exception e){return -1;}}

    private void confirmDeleteHit(long id){
        if(id<1)return;
        new AlertDialog.Builder(this).setTitle("حذف هذه الضربة؟")
                .setMessage("سيتم حذف هذه الضربة فقط. باقي الضربات ستظل محفوظة، وسيُعاد ترتيب الربط بينها.")
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("حذف",(d,w)->{db.deletePlayHit(id);refreshCount();Toast.makeText(this,"تم حذف الضربة فقط",Toast.LENGTH_SHORT).show();showPlayLog();}).show();
    }

    private void showGeneralHistory(){
        List<String>x=db.recent(100), rel=db.learnedRelations(100), seq=db.learnedTransitions(100);
        StringBuilder msg=new StringBuilder("بيانات التعلم العامة وليست سجل الضربات الفردي.\n\n=== المشاهدات ===\n");
        msg.append(x.isEmpty()?"لا توجد مشاهدات بعد.\n":android.text.TextUtils.join("\n",x));
        msg.append("\n\n=== الخزين المرتبط بالشرايط ===\n");
        msg.append(rel.isEmpty()?"لا توجد علاقات مكتشفة بعد.\n":android.text.TextUtils.join("\n",rel));
        msg.append("\n\n=== تسلسل الشرايط ===\n");
        msg.append(seq.isEmpty()?"لا يوجد تسلسل مثبت بعد.\n":android.text.TextUtils.join("\n",seq));
        new AlertDialog.Builder(this).setTitle("📊 البيانات العامة").setMessage(msg.toString()).setPositiveButton("إغلاق",null).show();
    }

    private void confirmDeleteAll(){
        new AlertDialog.Builder(this).setTitle("مسح كل البيانات؟")
                .setMessage("سيتم حذف كل المشاهدات والعلاقات والتسلسلات وخطط الضرب وسجل الضربات. هذا الإجراء يدوي فقط.")
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("مسح بالكامل",(d,w)->{db.clearAllHistory();refreshCount();Toast.makeText(this,"تم مسح كل البيانات يدويًا.",Toast.LENGTH_SHORT).show();}).show();
    }
}
