# v39 Live Fusion — Rewired build 40

This is the v39 project reworked so the live-analysis components are actually connected as one pipeline instead of existing as separate modules.

## Runtime pipeline

MediaProjection screen stream
→ overlay masking
→ OpenCV optical-flow / visual checks
→ fused ML Kit Latin OCR + Tesseract Arabic/English OCR
→ Taka room vs internal-game classifier
→ gift-marker validation only on the gift-room surface
→ seeded Mahzooz image catalog + persistent learned templates
→ observed sequence/history
→ Markov transition model
→ overlay/dashboard.

## Important fixes

- OCR now preserves line boundaries, so game titles such as `SPHINX MAGIC` can be extracted instead of being collapsed into one long line.
- OCR now reads targeted top and game regions in addition to the full frame.
- Tesseract uses Arabic + English `tessdata_best` supplied by CI.
- Arabic-Indic digits are normalized when reading the visible bet.
- Saturated casino artwork is no longer automatically treated as Mahzooz green/yellow badges.
- Gift markers are accepted only after independent room/inventory evidence is found.
- Added the supplied 30-item Mahzooz sprite sheet as a seeded visual catalog for local image matching.
- Strong visible game titles are promoted into the same GameRouter/GameSignalEngine path, so the top status and live panel use the same detected mode.
- Markov now receives the actual observed visible-game/item state transitions instead of only the old green-strip path.
- Python/MSS/OpenCV/Tesseract/EasyOCR remains a desktop validation companion; the Android runtime uses native MediaProjection/OpenCV/Tesseract/ML Kit and does not require Python.

Build version: 40
Version name: 8.9.1-live-fusion-rewired
