package com.mahzooz.monitor;

import java.util.*;

/** Deterministic, explainable rule engine over observations already produced by our analyzer. */
public final class MultiConditionRuleEngine {
    public static final class Rule {
        public final String name;
        public final int minGreen, minYellow;
        public final float minConfidence, minFlow;
        public final String requiredGreen, requiredYellow;
        public Rule(String name,int minGreen,int minYellow,float minConfidence,float minFlow,String requiredGreen,String requiredYellow){
            this.name=name;this.minGreen=minGreen;this.minYellow=minYellow;this.minConfidence=minConfidence;this.minFlow=minFlow;this.requiredGreen=requiredGreen;this.requiredYellow=requiredYellow;
        }
    }
    public static final class Match { public final String rule; public final String explanation; Match(String r,String e){rule=r;explanation=e;} }

    private final List<Rule> rules=new ArrayList<>();
    public MultiConditionRuleEngine(){
        rules.add(new Rule("VISIBLE_ITEMS",1,1,.45f,0f,"",""));
        rules.add(new Rule("MOVING_LAYOUT",1,0,.50f,.35f,"",""));
    }
    public synchronized void addRule(Rule r){if(r!=null)rules.add(r);}
    public synchronized List<Match> evaluate(List<Detector.Tile> green,List<Detector.Tile> yellow,float confidence,float flow){
        Set<String> gs=labels(green), ys=labels(yellow); ArrayList<Match> out=new ArrayList<>();
        for(Rule r:rules){
            if(green.size()<r.minGreen||yellow.size()<r.minYellow||confidence<r.minConfidence||flow<r.minFlow) continue;
            if(!r.requiredGreen.isEmpty()&&!gs.contains(r.requiredGreen)) continue;
            if(!r.requiredYellow.isEmpty()&&!ys.contains(r.requiredYellow)) continue;
            out.add(new Match(r.name,"green="+green.size()+", yellow="+yellow.size()+", confidence="+fmt(confidence)+", flow="+fmt(flow)));
        }
        return out;
    }
    private static Set<String> labels(List<Detector.Tile> x){Set<String>s=new HashSet<>();if(x!=null)for(Detector.Tile t:x)if(t.label!=null&&!t.label.isEmpty())s.add(t.label);return s;}
    private static String fmt(float x){return String.format(Locale.US,"%.2f",x);}
}
