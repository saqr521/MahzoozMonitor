package com.mahzooz.monitor;

import android.graphics.Bitmap;
import java.util.List;

public class Analyzer {
    private final TemplateRepository templates;
    private final HistoryDb db;
    private long lastFrameHash=0;
    public Analyzer(android.content.Context c){templates=new TemplateRepository(c);db=new HistoryDb(c);}
    public AnalysisResult analyze(Bitmap bmp){
        List<Detector.Marker> g=Detector.findMarkers(bmp,true), y=Detector.findMarkers(bmp,false);
        List<Detector.Tile> tiles=Detector.findTiles(bmp,templates);
        long screenHash=Detector.phash(bmp,new android.graphics.Rect(0,0,bmp.getWidth(),bmp.getHeight()));
        String change=lastFrameHash==0?"بدء الرصد":(Long.bitCount(screenHash^lastFrameHash)>10?"تغير ملحوظ في الشاشة":"");
        lastFrameHash=screenHash;
        float c=0.5f;if(!g.isEmpty()||!y.isEmpty())c+=0.2f;if(!tiles.isEmpty())c+=0.1f;if(!change.isEmpty())c+=0.1f;return new AnalysisResult(System.currentTimeMillis(),g,y,tiles,change,Math.min(1,c));
    }
    public void save(AnalysisResult r){db.add(r);}
    public TemplateRepository templates(){return templates;}
    public HistoryDb db(){return db;}
}
