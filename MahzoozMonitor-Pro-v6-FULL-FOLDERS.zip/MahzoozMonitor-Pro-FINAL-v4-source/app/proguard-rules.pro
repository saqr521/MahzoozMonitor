# Project rules intentionally minimal for the first build.
