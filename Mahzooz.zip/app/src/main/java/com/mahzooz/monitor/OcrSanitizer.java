package com.mahzooz.monitor;

/** Removes emoji/punctuation noise while preserving Arabic, Latin, digits and OCR line boundaries. */
public final class OcrSanitizer {
    private OcrSanitizer() {}

    public static String clean(String rawText) {
        if (rawText == null) return "";
        return rawText
                .replace("\r", "\n")
                .replaceAll("[\\p{So}\\p{Cs}]", " ")
                .replaceAll("[^\\p{L}\\p{N}\\s.,:%xX×kKmM_\\-]", " ")
                .replaceAll("[ \t]+", " ")
                .replaceAll("\n{3,}", "\n\n")
                .trim();
    }

    /** One-line form for parsers that do not care about OCR layout. */
    public static String singleLine(String rawText) {
        String t = clean(rawText);
        return t.replace('\n', ' ').replaceAll("\\s+", " ").trim();
    }
}
