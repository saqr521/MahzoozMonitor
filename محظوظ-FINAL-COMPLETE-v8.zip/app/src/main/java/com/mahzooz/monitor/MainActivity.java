package com.mahzooz.monitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.provider.Settings;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ = 42;
    private TextView status, stats;
    private Analyzer analyzer;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        analyzer = new Analyzer(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("محظوظ — تحليل 🟩 الشرايط و🟨 الخزين");
        title.setTextSize(21);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);

        status = new TextView(this);
        status.setText("جاهز — اضغط ابدأ المراقبة");
        status.setTextSize(17);
        status.setPadding(0, 20, 0, 20);
        root.addView(status);

        Button permissions = new Button(this);
        permissions.setText("تجهيز الصلاحيات");
        permissions.setOnClickListener(v -> preparePermissions());
        root.addView(permissions);

        Button start = new Button(this);
        start.setText("ابدأ المراقبة والتحليل");
        start.setOnClickListener(v -> startCapture());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("إيقاف المراقبة");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            status.setText("تم الإيقاف");
        });
        root.addView(stop);

        Button calibrate = new Button(this);
        calibrate.setText("تعليم اسم عنصر (بط / جولد / بطيخ...)");
        calibrate.setOnClickListener(v -> calibrate());
        root.addView(calibrate);

        Button hidden = new Button(this);
        hidden.setText("مسح الإيقونات المخفية (سحب)");
        hidden.setOnClickListener(v -> revealHidden());
        root.addView(hidden);

        Button history = new Button(this);
        history.setText("السجل والإحصائيات");
        history.setOnClickListener(v -> showHistory());
        root.addView(history);

        stats = new TextView(this);
        stats.setText(analyzer.db().stats());
        stats.setPadding(0, 20, 0, 0);
        root.addView(stats);

        setContentView(root);
        registerReceiver(receiver, new IntentFilter(CaptureService.ACTION_RESULT),
                Build.VERSION.SDK_INT >= 33 ? Context.RECEIVER_NOT_EXPORTED : 0);
    }

    private void startCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            status.setText("وافق على إشعارات المراقبة ثم اضغط البدء مرة أخرى.");
            return;
        }

        MediaProjectionManager m =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        // Android requires an explicit user approval for screen capture; this cannot be
        // silently bypassed by an app, even when every manifest permission is declared.
        startActivityForResult(m.createScreenCaptureIntent(), REQ);
    }

    private void preparePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
                status.setText("فعّل الظهور فوق التطبيقات ثم ارجع واضغط تجهيز الصلاحيات مرة أخرى.");
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
            return;
        }
        if (!isAccessibilityEnabled()) {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                status.setText("فعّل خدمة محظوظ لإتاحة سحب الصفوف المخفية، ثم ارجع واضغط تجهيز الصلاحيات مرة أخرى.");
            } catch (Exception e) {
                status.setText("فعّل إمكانية الوصول من إعدادات أندرويد.");
            }
            return;
        }
        status.setText("تم تجهيز الصلاحيات المتاحة. التقاط الشاشة سيطلب موافقة أندرويد عند البدء.");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            boolean granted = grantResults.length > 0 &&
                    grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            status.setText(granted
                    ? "تم السماح بالإشعارات. اضغط ابدأ المراقبة."
                    : "إشعارات المراقبة مرفوضة؛ يمكنك السماح بها من إعدادات أندرويد.");
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ) return;
        if (result != RESULT_OK || data == null) {
            status.setText("تم إلغاء صلاحية التقاط الشاشة.");
            return;
        }

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        Intent i = new Intent(this, CaptureService.class);
        i.putExtra("resultCode", result);
        i.putExtra("data", data);
        i.putExtra("width", dm.widthPixels);
        i.putExtra("height", dm.heightPixels);
        i.putExtra("densityDpi", dm.densityDpi);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);

        status.setText("جاري تشغيل التحليل… انتظر أول لقطة.");
    }

    private void calibrate() {
        final EditText e = new EditText(this);
        e.setHint("اسم العنصر");
        new AlertDialog.Builder(this)
                .setTitle("تعليم عنصر")
                .setMessage("الاسم وحده لا ينشئ قالبًا بصريًا. التعرف الدقيق على بط/جولد/بطيخ يحتاج لقطة واضحة من شاشة اللعبة.")
                .setView(e)
                .setPositiveButton("حفظ الاسم", (d, w) ->
                        Toast.makeText(this, "تم إدخال: " + e.getText(), Toast.LENGTH_SHORT).show())
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void revealHidden() {
        if (!isAccessibilityEnabled()) {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                status.setText("فعّل خدمة محظوظ للوصول، ثم ارجع واضغط مسح الإيقونات المخفية.");
            } catch (Exception e) {
                Toast.makeText(this, "تعذر فتح إعدادات إمكانية الوصول", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        Intent swipe = new Intent(ScrollAccessibilityService.ACTION_REVEAL_HIDDEN);
        swipe.setPackage(getPackageName());
        sendBroadcast(swipe);
        status.setText("تم طلب سحب الشاشة. انتظر نصف ثانية ليقرأ الصفوف الجديدة.");
    }

    private boolean isAccessibilityEnabled() {
        android.view.accessibility.AccessibilityManager am =
                (android.view.accessibility.AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        for (android.accessibilityservice.AccessibilityServiceInfo info :
                am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
            if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null &&
                    getPackageName().equals(info.getResolveInfo().serviceInfo.packageName)) return true;
        }
        return false;
    }

    private void showHistory() {
        List<String> x = analyzer.db().recent(30);
        List<String> rel = analyzer.db().learnedRelations(20);
        StringBuilder msg = new StringBuilder(analyzer.db().stats()).append("\n\n");
        if (!rel.isEmpty()) {
            msg.append("الروابط المتعلمة:\n")
               .append(android.text.TextUtils.join("\n", rel)).append("\n\n");
        }
        msg.append(android.text.TextUtils.join("\n", x));
        new AlertDialog.Builder(this)
                .setTitle("السجل والإحصائيات")
                .setMessage(msg.toString())
                .setPositiveButton("حسنًا", null)
                .show();
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            status.setText(i.getStringExtra("text"));
            stats.setText(analyzer.db().stats());
        }
    };

    @Override protected void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
