# v18 — Grid Mapping + Multi-Condition Rules + Sequential Apriori

- Added read-only Grid Mapping Analysis for detected tiles using screen coordinates.
- Added deterministic Multi-Condition Rule Engine for explainable local observations.
- Added Sequential Apriori-style mining over the bounded observed state sequence.
- Integrated all three into Analyzer and AlgorithmTrace.
- No game input, process injection, private-memory access, packet interception, or TLS bypass.
