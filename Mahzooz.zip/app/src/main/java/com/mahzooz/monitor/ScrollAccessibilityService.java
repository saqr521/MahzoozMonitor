package com.mahzooz.monitor;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/** Optional helper: performs a single user-requested vertical swipe to reveal
 * inventory rows that are below the currently visible area. It never taps items. */
public class ScrollAccessibilityService extends AccessibilityService {
    private static volatile String foregroundPackage = "";
    private static volatile long foregroundChangedAt = 0L;
    private static volatile String foregroundText = "";
    private static volatile long lastSemanticReadAt = 0L;
    public static String currentForegroundPackage() { return foregroundPackage; }
    public static boolean isTakaForeground() { return "com.taka.vhgyk".equals(foregroundPackage); }
    public static long foregroundChangedAt() { return foregroundChangedAt; }
    public static String currentForegroundText() { return foregroundText; }

    public static final String ACTION_REVEAL_HIDDEN = "com.mahzooz.monitor.REVEAL_HIDDEN";
    private android.content.BroadcastReceiver receiver;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        if (Build.VERSION.SDK_INT >= 26) {
            receiver = new android.content.BroadcastReceiver() {
                @Override public void onReceive(android.content.Context c, android.content.Intent i) {
                    if (ACTION_REVEAL_HIDDEN.equals(i.getAction())) swipeUp();
                }
            };
            registerReceiver(receiver, new android.content.IntentFilter(ACTION_REVEAL_HIDDEN),
                    android.content.Context.RECEIVER_NOT_EXPORTED);
        }
    }

    private void swipeUp() {
        if (Build.VERSION.SDK_INT < 24) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.5f;
        float y1 = dm.heightPixels * 0.78f;
        float y2 = dm.heightPixels * 0.35f;
        Path path = new Path(); path.moveTo(x, y1); path.lineTo(x, y2);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 500);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg != null) {
            String value = pkg.toString();
            if (!value.equals(foregroundPackage)) {
                foregroundPackage = value;
                foregroundChangedAt = System.currentTimeMillis();
            }
            if ("com.taka.vhgyk".equals(value)) {
                long now = System.currentTimeMillis();
                if (now - lastSemanticReadAt < 300L) return;
                lastSemanticReadAt = now;
                try {
                    AccessibilityNodeInfo root = event.getSource();
                    if (root != null) {
                        java.util.ArrayList<String> texts = new java.util.ArrayList<>();
                        collect(root, texts);
                        StringBuilder b = new StringBuilder();
                        for (String t : texts) {
                            if (t == null || t.trim().isEmpty()) continue;
                            if (b.length() > 0) b.append('\n');
                            b.append(t.trim());
                            if (b.length() > 6000) break;
                        }
                        foregroundText = b.toString();
                        root.recycle();
                    }
                } catch (Throwable ignored) {}
            } else if (!"com.taka.vhgyk".equals(value)) {
                foregroundText = "";
            }
        }
    }
    private static void collect(AccessibilityNodeInfo n, java.util.List<String> out) {
        if (n == null || out.size() > 300) return;
        CharSequence t=n.getText();
        CharSequence d=n.getContentDescription();
        if (t!=null && t.length()>0) out.add(t.toString());
        if (d!=null && d.length()>0) out.add(d.toString());
        for(int i=0;i<n.getChildCount() && out.size()<300;i++){
            AccessibilityNodeInfo c=n.getChild(i);
            if(c!=null){ collect(c,out); c.recycle(); }
        }
    }

    @Override public void onInterrupt() {}

    @Override public void onDestroy() {
        if (receiver != null) { try { unregisterReceiver(receiver); } catch (Exception ignored) {} receiver = null; }
        super.onDestroy();
    }
}
