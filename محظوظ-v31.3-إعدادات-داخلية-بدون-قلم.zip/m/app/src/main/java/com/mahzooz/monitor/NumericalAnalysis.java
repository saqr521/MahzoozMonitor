package com.mahzooz.monitor;

/** NumPy/SciPy-style numerical primitives implemented directly in Java for Android. */
public final class NumericalAnalysis {
    private NumericalAnalysis() {}
    public static double[] diff(double[] x){
        if(x==null||x.length<2)return new double[0]; double[] d=new double[x.length-1]; for(int i=0;i<d.length;i++)d[i]=x[i+1]-x[i]; return d;
    }
    public static double dot(double[] a,double[] b){
        if(a==null||b==null)return 0; int n=Math.min(a.length,b.length); double s=0; for(int i=0;i<n;i++)s+=a[i]*b[i]; return s;
    }
    public static double correlation(double[] a,double[] b){
        if(a==null||b==null||a.length<2||b.length<2)return 0; int n=Math.min(a.length,b.length); double ma=0,mb=0; for(int i=0;i<n;i++){ma+=a[i];mb+=b[i];}ma/=n;mb/=n; double num=0,da=0,db=0; for(int i=0;i<n;i++){double x=a[i]-ma,y=b[i]-mb;num+=x*y;da+=x*x;db+=y*y;} return da==0||db==0?0:num/Math.sqrt(da*db);
    }
}
