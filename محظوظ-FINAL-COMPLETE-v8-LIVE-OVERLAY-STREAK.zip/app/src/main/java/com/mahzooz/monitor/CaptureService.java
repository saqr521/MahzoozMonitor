package com.mahzooz.monitor;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;

public class CaptureService extends Service {
    public static final String ACTION_RESULT = "com.mahzooz.monitor.RESULT";
    private MediaProjection projection;
    private ImageReader reader;
    private android.hardware.display.VirtualDisplay display;
    private Analyzer analyzer;
    private HandlerThread workerThread;
    private Handler worker;
    private Handler mainHandler;
    private long lastFrame = 0;
    private boolean running = false;
    private WindowManager overlayManager;
    private LinearLayout overlayView;
    private WindowManager.LayoutParams overlayParams;
    private TextView liveText;
    private TextView exploreText;
    private TextView liveHeader;
    private TextView exploreHeader;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        createChannel();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"));
        }

        if (running) return START_STICKY;

        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = intent.getParcelableExtra("data");
        }

        if (resultCode != Activity.RESULT_OK || data == null) {
            broadcast("لم يتم منح صلاحية التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager pm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = pm.getMediaProjection(resultCode, data);
        if (projection == null) {
            broadcast("تعذر بدء التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = intent.getIntExtra("width", dm.widthPixels);
        int h = intent.getIntExtra("height", dm.heightPixels);
        int dpi = intent.getIntExtra("densityDpi", dm.densityDpi);

        mainHandler = new Handler(getMainLooper());
        workerThread = new HandlerThread("MahzoozCapture");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        analyzer = new Analyzer(this);
        AlgorithmTrace.init(this);

        reader = ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 3);

        // Android 14+ requires the MediaProjection callback to be registered
        // before creating the VirtualDisplay.
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                running = false;
                broadcast("تم إيقاف التقاط الشاشة.");
                stopSelf();
            }
        }, worker);

        display = projection.createVirtualDisplay(
                "MahzoozMonitor", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, worker);

        reader.setOnImageAvailableListener(r -> {
            running = true;
            long now = System.currentTimeMillis();
            if (now - lastFrame < 300) return;
            lastFrame = now;
            Image image = null;
            Bitmap bitmap = null;
            try {
                image = r.acquireLatestImage();
                if (image == null) return;
                bitmap = ImageUtils.toBitmap(image);
                AnalysisResult result = analyzer.analyze(bitmap);
                analyzer.save(result);
                broadcast(format(result));
                updateOverlay(result);
            } catch (Throwable e) {
                broadcast("خطأ أثناء تحليل اللقطة: " + e.getClass().getSimpleName());
            } finally {
                if (image != null) image.close();
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }, worker);

        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            updateOverlay(null);
        }
        broadcast("تم بدء التقاط الشاشة — في انتظار عناصر 🟩 و🟨...");
        return START_STICKY;
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, "capture")
                .setContentTitle("محظوظ")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void broadcast(String text) {
        Intent out = new Intent(ACTION_RESULT);
        out.setPackage(getPackageName());
        out.putExtra("text", text);
        sendBroadcast(out);
    }

    private String format(AnalysisResult r) {
        StringBuilder s = new StringBuilder();
        s.append("🟩 الأشرطة: ").append(r.green.size())
                .append("   🟨 الخزين: ").append(r.yellow.size()).append("\n");
        if (!r.relations.isEmpty()) {
            s.append("الربط والنسب:\n");
            for (String rel : r.relations) s.append("• ").append(rel).append("\n");
        }
        if (!r.recommendation.isEmpty()) s.append(r.recommendation).append("\n");
        if (!r.tiles.isEmpty()) {
            s.append("العناصر: ");
            int n = 0;
            for (Detector.Tile t : r.tiles) {
                if (n++ >= 10) break;
                if (n > 1) s.append("، ");
                s.append(t.label);
            }
            s.append("\n");
        }
        if (!r.observedChange.isEmpty()) s.append(r.observedChange).append("\n");
        if (!r.coordinateSummary.isEmpty()) s.append(r.coordinateSummary).append("\n");
        s.append("الثقة البصرية: ").append(Math.round(r.confidence * 100)).append('%').append('\n');
        s.append(AlgorithmTrace.snapshot());
        return s.toString();
    }

    private void updateOverlay(AnalysisResult r) {
        if (Build.VERSION.SDK_INT < 23 || !Settings.canDrawOverlays(this)) return;
        if (mainHandler != null && android.os.Looper.myLooper() != mainHandler.getLooper()) {
            mainHandler.post(() -> updateOverlay(r));
            return;
        }
        try {
            ensureOverlay();
            if (r == null) {
                liveText.setText("جاري بدء التحليل…");
                exploreText.setText("في انتظار أول قراءة للعناصر 🟩 و🟨");
                return;
            }
            liveText.setText(buildLiveOverlay(r));
            exploreText.setText(buildExploreOverlay(r));
        } catch (Throwable ignored) {}
    }

    private void ensureOverlay() {
        if (overlayManager == null) overlayManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        overlayView = new LinearLayout(this);
        overlayView.setOrientation(LinearLayout.HORIZONTAL);
        overlayView.setPadding(0, 0, 0, 0);
        overlayView.setElevation(12f);

        LinearLayout explore = makeSection("الاستكشاف", false);
        LinearLayout live = makeSection("اللعب الحالي", true);
        overlayView.addView(explore, new LinearLayout.LayoutParams(0, -2, 1f));
        overlayView.addView(live, new LinearLayout.LayoutParams(0, -2, 1f));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        overlayParams = new WindowManager.LayoutParams(
                dp(330), dp(210), type, flags, PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        android.content.SharedPreferences sp = getSharedPreferences("overlay", MODE_PRIVATE);
        overlayParams.x = sp.getInt("x", 8);
        overlayParams.y = sp.getInt("y", 70);
        overlayManager.addView(overlayView, overlayParams);

        View.OnTouchListener drag = new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = overlayParams.x; startY = overlayParams.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        overlayParams.x = startX + Math.round(e.getRawX() - downX);
                        overlayParams.y = startY + Math.round(e.getRawY() - downY);
                        try { overlayManager.updateViewLayout(overlayView, overlayParams); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences("overlay", MODE_PRIVATE).edit()
                                .putInt("x", overlayParams.x).putInt("y", overlayParams.y).apply();
                        return true;
                }
                return false;
            }
        };
        overlayView.setOnTouchListener(drag);
        liveHeader.setOnTouchListener(drag);
        exploreHeader.setOnTouchListener(drag);
    }

    private LinearLayout makeSection(String title, boolean live) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE8171720);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), live ? 0xB04CAF50 : 0xB0E0B83B);
        box.setBackground(bg);

        TextView header = new TextView(this);
        header.setText(title + "  ⋮⋮");
        header.setTextSize(13);
        header.setTextColor(0xFFFFFFFF);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, dp(2), 0, dp(5));
        box.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView body = new TextView(this);
        body.setTextSize(11.5f);
        body.setTextColor(0xFFFFFFFF);
        body.setGravity(Gravity.RIGHT | Gravity.TOP);
        body.setLineSpacing(0f, 1.05f);
        body.setPadding(dp(2), dp(2), dp(2), dp(2));
        box.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));

        if (live) { liveHeader = header; liveText = body; }
        else { exploreHeader = header; exploreText = body; }
        return box;
    }

    private String buildLiveOverlay(AnalysisResult r) {
        StringBuilder s = new StringBuilder();
        s.append("الحالة: ").append(r.confidence >= .70f ? "قوية" : r.confidence >= .45f ? "متوسطة" : "ضعيفة")
                .append(" — ").append(Math.round(r.confidence * 100)).append("%\n");
        if (!r.recommendation.isEmpty()) s.append("▶ ").append(r.recommendation).append("\n");
        if (!r.observedChange.isEmpty()) s.append("تغيير: ").append(r.observedChange).append("\n");
        String continuity = analyzer != null ? analyzer.db().continuitySummary(3) : "";
        if (!continuity.isEmpty()) s.append("استمرارية اللعب: ").append(continuity).append("\n");
        int shown = 0;
        for (String rel : r.relations) {
            if (shown++ >= 3) break;
            s.append(rel).append("\n");
        }
        if (shown == 0) s.append("في انتظار تثبيت الشريط التالي…\n");
        if (r.green.isEmpty()) s.append("لا يوجد شريط 🟩 واضح الآن");
        else s.append("🟩 الشرايط الآن: ").append(r.green.size());
        return s.toString();
    }

    private String buildExploreOverlay(AnalysisResult r) {
        StringBuilder s = new StringBuilder();
        if (r.relations.isEmpty()) {
            s.append("لا توجد روابط متعلمة بعد.\n");
            s.append("ستظهر هنا علاقة كل 🟩 شريط مع 🟨 الخزين عند رصدها.");
            return s.toString();
        }
        int n = 0;
        for (String rel : r.relations) {
            if (n++ >= 7) break;
            s.append(rel).append("\n");
        }
        return s.toString().trim();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void removeOverlay() {
        if (overlayView != null && overlayManager != null) {
            try { overlayManager.removeView(overlayView); } catch (Exception ignored) {}
        }
        overlayView = null; overlayManager = null; overlayParams = null;
        liveText = null; exploreText = null; liveHeader = null; exploreHeader = null;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "capture", "مراقبة الشاشة", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public void onDestroy() {
        running = false;
        if (reader != null) { reader.close(); reader = null; }
        if (display != null) { display.release(); display = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (workerThread != null) { workerThread.quitSafely(); workerThread = null; }
        removeOverlay();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
