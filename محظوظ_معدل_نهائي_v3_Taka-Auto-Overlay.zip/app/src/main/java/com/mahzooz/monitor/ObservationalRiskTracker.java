package com.mahzooz.monitor;

/**
 * Risk/session statistics only.
 *
 * This class deliberately does not calculate or recommend a real wager amount.
 * It can be used to display win/loss streaks and a hypothetical session state
 * without telling the user what to stake.
 */
final class ObservationalRiskTracker {
    private int wins;
    private int losses;
    private int winStreak;
    private int lossStreak;
    private long lastOutcomeAt;

    synchronized void observeOutcome(Boolean won, long now) {
        if (won == null) return;
        lastOutcomeAt = now;
        if (won) {
            wins++;
            winStreak++;
            lossStreak = 0;
        } else {
            losses++;
            lossStreak++;
            winStreak = 0;
        }
    }

    synchronized String summary() {
        if (wins == 0 && losses == 0) {
            return "إدارة المخاطر: رصد فقط — لا توجد نتائج كافية";
        }
        return "إدارة المخاطر: رصد فقط | فوز " + wins +
                " | خسارة " + losses +
                " | سلسلة فوز " + winStreak +
                " | سلسلة خسارة " + lossStreak;
    }

    synchronized void clear() {
        wins = losses = winStreak = lossStreak = 0;
        lastOutcomeAt = 0L;
    }
}
