package com.mahzooz.monitor;

import java.util.*;

/** Correlates independently observed screen/events with explicitly delivered telemetry by time. */
public final class EventCorrelationEngine {
    private final HistoryDb db;
    public EventCorrelationEngine(HistoryDb database){db=database;}
    public synchronized String correlate(long timestampMs,String screenSignature,List<ReadOnlyEventMonitor.Event> events){
        if(events==null||events.isEmpty()) return "";
        String sig=screenSignature==null?"":screenSignature;
        StringBuilder s=new StringBuilder("ارتباط مرصود: ");
        for(int i=0;i<events.size();i++){
            if(i>0)s.append(" ؛ ");
            s.append(events.get(i).type).append("=").append(events.get(i).name);
        }
        if(!sig.isEmpty()) s.append(" | حالة الشاشة=").append(sig);
        String out=s.toString();
        if(db!=null) db.recordCorrelation(timestampMs,out);
        AlgorithmTrace.recordCorrelation(out);
        return out;
    }
}
