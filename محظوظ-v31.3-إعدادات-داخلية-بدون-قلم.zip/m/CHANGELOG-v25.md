# محظوظ v25 — Flat Persistent Hit Log

- Removed the user-facing concept of play sessions from the play-history screen.
- Every observed manual hit is now a separate chronological row.
- Each row keeps hit number, icon label, time, observation confidence, immediate next observed hit, and validation percentage when available.
- Each row has its own delete button, so a lost/incorrect play can be removed without deleting the successful surrounding history.
- After deleting one hit, remaining chronological links are rebuilt so the sequence stays understandable.
- Existing v24 session-based hit rows are migrated into the flat log on database upgrade.
- History remains persistent across app close/restart; nothing is auto-deleted.
- Full-history deletion remains an explicit manual option.
- No game input automation, hooks, traffic interception, or modification of the game.
