package com.mahzooz.monitor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Informational round-timer parser. It never triggers or suppresses a wager. */
public final class RoundCountdown {
    private static final Pattern MMSS = Pattern.compile("(?<!\\d)(\\d{1,2}):(\\d{2})(?!\\d)");
    private static final Pattern SECONDS = Pattern.compile("(?<!\\d)(\\d{1,3})\\s*(?:s|sec|ثانية|ثواني)(?!\\p{L})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private RoundCountdown() {}

    public static int parseSeconds(String text) {
        if (text == null) return -1;
        Matcher m = MMSS.matcher(text);
        if (m.find()) {
            try { return Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2)); }
            catch (Exception ignored) {}
        }
        m = SECONDS.matcher(text);
        if (m.find()) {
            try { return Integer.parseInt(m.group(1)); } catch (Exception ignored) {}
        }
        return -1;
    }
}
