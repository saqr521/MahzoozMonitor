package com.mahzooz.monitor;

/** Three safe processing accelerators: adaptive cadence, duplicate-frame skip, ROI hints. */
public final class AnalysisAccelerators {
    public enum Level { FAST, BALANCED, PRECISE }
    private final Level level;
    private long lastHash;
    private long lastAt;
    public AnalysisAccelerators(Level l){ level=l==null?Level.BALANCED:l; }
    public long minIntervalMs(){
        switch(level){case FAST:return 120; case PRECISE:return 220; default:return 160;}
    }
    public boolean shouldAnalyze(long now,long hash){
        if(lastAt!=0 && now-lastAt<minIntervalMs()) return false;
        if(lastHash!=0 && hash==lastHash && level!=Level.PRECISE) return false;
        lastAt=now; lastHash=hash; return true;
    }
    public int roiHintRows(){ return level==Level.PRECISE ? 6 : 4; }
}
