package com.mahzooz.monitor;

import java.util.*;

/** Read-only monitor for WebSocket events explicitly delivered by an app-owned/client-owned socket. */
public final class WebSocketReadOnlyMonitor {
    public enum Direction { INBOUND, OUTBOUND }
    public static final class Event {
        public final long timestampMs; public final Direction direction; public final String endpoint;
        public final int bytes; public final String summary; public final float confidence;
        Event(long ts, Direction d, String e, int b, String s, float c){timestampMs=ts;direction=d;endpoint=e;bytes=b;summary=s;confidence=c;}
        @Override public String toString(){return "WS | "+direction+" | "+endpoint+" | "+bytes+"B | "+summary+" | "+Math.round(confidence*100)+"%";}
    }
    private final HistoryDb db;
    public WebSocketReadOnlyMonitor(HistoryDb database){db=database;}
    public synchronized Event recordInbound(String endpoint,int bytes,String summary,float confidence){return record(Direction.INBOUND,endpoint,bytes,summary,confidence);}
    public synchronized Event recordOutbound(String endpoint,int bytes,String summary,float confidence){return record(Direction.OUTBOUND,endpoint,bytes,summary,confidence);}
    public boolean acceptsOnlyOwnedOrExplicitlyExportedEvents(){return true;}
    public boolean interceptsOtherApps(){return false;}
    private Event record(Direction d,String endpoint,int bytes,String summary,float confidence){
        Event e=new Event(System.currentTimeMillis(),d,safe(endpoint),Math.max(0,bytes),safe(summary),clamp(confidence));
        if(db!=null) db.recordWebSocketEvent(e.timestampMs,d.name(),e.endpoint,e.bytes,e.summary,e.confidence);
        AlgorithmTrace.recordWebSocketEvent(e); return e;
    }
    private static String safe(String s){return s==null?"":s.length()>180?s.substring(0,180):s;}
    private static float clamp(float x){return Math.max(0f,Math.min(1f,x));}
}
