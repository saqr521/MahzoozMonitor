package com.mahzooz.monitor;

import java.util.*;

/** Compatibility facade over the verified Taka APK reference catalog. */
public final class TakaReferenceCatalog {
    public static final List<String> ITEM_FIELDS = Collections.unmodifiableList(Arrays.asList(
            "gameId", "item_name", "item_number"
    ));
    public static final List<String> CLIENT_COMPONENTS = Collections.unmodifiableList(Arrays.asList(
            "AndItem", "ResultGetIntent", "StreamClassifier", "FullscreenVideoView"
    ));

    private TakaReferenceCatalog() {}

    public static String profileForText(String text) {
        String verified = TakaGameKnowledge.profileForText(text);
        if (!"غير محدد".equals(verified)) return verified;
        return GameRouterTextProfile.profile(text);
    }

    public static String referenceSummary() {
        return "Taka " + TakaGameKnowledge.VERSION + " | " +
                TakaGameKnowledge.PACKAGE + " | " +
                "بصمات واجهة ألعاب/عجلة/نتائج محلية فقط";
    }

    private static final class GameRouterTextProfile {
        static String profile(String text) {
            if (text == null) return "غير محدد";
            String t = text.toLowerCase(Locale.ROOT);
            if (t.contains("محظوظ") || t.contains("هدايا")) return "هدايا المحظوظ";
            if (t.contains("roulette") || t.contains("روليت") || t.contains("wheel") || t.contains("عجلة")) return "العجلة / الروليت";
            if (t.contains("crash") || t.contains("multiplier") || t.contains("مضاعف")) return "كراش / مضاعف";
            return "غير محدد";
        }
    }
}
