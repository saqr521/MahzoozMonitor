# v20 / 7.2.0 — One-icon interaction reference learning

- Integrated the supplied one-icon-at-a-time gameplay video as a local visual reference dataset (multiple real screenshot crops + manifest).
- Added `InteractionReferenceLearner`: detects the selected inventory card from the visible selection highlight and records the inventory → room → inventory cycle without sending input.
- Added persistent `interaction_references` SQLite table (schema v7) so learned icon interaction references survive restarts.
- Strengthened green←yellow relation learning: a new relation is now learned only when an actual completed icon-interaction window supplies temporal evidence, reducing false pairings from scrolling/page refreshes.
- Fixed marker-to-icon crop anchoring so the crop follows the badge location and avoids the price/label region.
- Optimized marker detection with a 2x2 logical scan and direct RGB gating to reduce CPU/GC pressure while preserving the small badge geometry.
- Added 84 screenshot reference samples covering 34 icon labels observed in the supplied video; raw video is not bundled into the APK.
- Preserved all previous read-only analytics, OpenCV, optical-flow, sequence, grid, rule, Apriori, atomic/bitmask, telemetry-boundary, overlay, and persistence features.
