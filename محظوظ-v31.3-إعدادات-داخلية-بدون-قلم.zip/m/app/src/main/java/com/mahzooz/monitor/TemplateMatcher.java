package com.mahzooz.monitor;

import android.graphics.Bitmap;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

/** Local OpenCV matchTemplate adapter. It compares screenshots against supplied templates only. */
public final class TemplateMatcher {
    public static final class Match {
        public final boolean found;
        public final double score;
        public final Point location;
        public final Size size;
        Match(boolean found, double score, Point location, Size size) {
            this.found = found; this.score = score; this.location = location; this.size = size;
        }
    }

    private TemplateMatcher() {}

    public static Match match(Bitmap screenshot, Bitmap template, double threshold) {
        if (screenshot == null || template == null || screenshot.isRecycled() || template.isRecycled())
            return new Match(false, 0, new Point(), new Size());
        if (template.getWidth() > screenshot.getWidth() || template.getHeight() > screenshot.getHeight())
            return new Match(false, 0, new Point(), new Size());
        Mat src = new Mat(), tpl = new Mat(), graySrc = new Mat(), grayTpl = new Mat(), result = new Mat();
        try {
            Utils.bitmapToMat(screenshot, src); Utils.bitmapToMat(template, tpl);
            Imgproc.cvtColor(src, graySrc, Imgproc.COLOR_RGBA2GRAY);
            Imgproc.cvtColor(tpl, grayTpl, Imgproc.COLOR_RGBA2GRAY);
            Imgproc.matchTemplate(graySrc, grayTpl, result, Imgproc.TM_CCOEFF_NORMED);
            Core.MinMaxLocResult mm = Core.minMaxLoc(result);
            double score = mm.maxVal;
            Point p = mm.maxLoc;
            return new Match(score >= threshold, score, p, new Size(template.getWidth(), template.getHeight()));
        } catch (Throwable ignored) {
            return new Match(false, 0, new Point(), new Size());
        } finally {
            src.release(); tpl.release(); graySrc.release(); grayTpl.release(); result.release();
        }
    }
}
