package com.mahzooz.monitor;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ScaleGestureDetector;
import android.widget.FrameLayout;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;

public class CaptureService extends Service {
    public static final String ACTION_RESULT = "com.mahzooz.monitor.RESULT";
    private MediaProjection projection;
    private ImageReader reader;
    private android.hardware.display.VirtualDisplay display;
    private Analyzer analyzer;
    private HandlerThread workerThread;
    private Handler worker;
    private Handler mainHandler;
    private long lastFrame = 0;
    private AnalysisAccelerators accelerators;
    private ScreenshotAndCvTools cvTools;
    private boolean running = false;
    private WindowManager overlayManager;
    private LinearLayout overlayView;
    private android.widget.FrameLayout overlayContainer;
    private WindowManager.LayoutParams overlayParams;
    private TextView liveText;
    private TextView exploreText;
    private TextView liveHeader;
    private TextView exploreHeader;
    private TextView roundText;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        createChannel();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"));
        }

        // A new monitoring session always replaces the previous one.
        // This prevents an old floating panel from surviving beside the new panel.
        if (running || overlayView != null || projection != null || reader != null) {
            cleanupCapture();
        }

        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = intent.getParcelableExtra("data");
        }

        if (resultCode != Activity.RESULT_OK || data == null) {
            broadcast("لم يتم منح صلاحية التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager pm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = pm.getMediaProjection(resultCode, data);
        if (projection == null) {
            broadcast("تعذر بدء التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = intent.getIntExtra("width", dm.widthPixels);
        int h = intent.getIntExtra("height", dm.heightPixels);
        int dpi = intent.getIntExtra("densityDpi", dm.densityDpi);

        mainHandler = new Handler(getMainLooper());
        workerThread = new HandlerThread("MahzoozCapture");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        analyzer = new Analyzer(this);
        AlgorithmTrace.init(this);
        accelerators = new AnalysisAccelerators(AnalysisAccelerators.Level.BALANCED);
        cvTools = new ScreenshotAndCvTools();

        reader = ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 3);

        // Android 14+ requires the MediaProjection callback to be registered
        // before creating the VirtualDisplay.
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                running = false;
                broadcast("تم إيقاف التقاط الشاشة.");
                stopSelf();
            }
        }, worker);

        display = projection.createVirtualDisplay(
                "MahzoozMonitor", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, worker);

        reader.setOnImageAvailableListener(r -> {
            running = true;
            long now = System.currentTimeMillis();
            Image image = null;
            Bitmap bitmap = null;
            try {
                image = r.acquireLatestImage();
                if (image == null) return;
                bitmap = ImageUtils.toBitmap(image);
                // The captured frame exists only in RAM for this analysis pass.
                // Never write it to Pictures/DCIM or any user-visible image file.
                long frameHash = Detector.phash(bitmap, new android.graphics.Rect(0,0,bitmap.getWidth(),bitmap.getHeight()));
                if (!accelerators.shouldAnalyze(now, frameHash)) return;
                lastFrame = now;
                AnalysisResult result = analyzer.analyze(bitmap);
                AlgorithmTrace.recordSignalBoundary(new SignalObservation(now, SignalObservation.Direction.GAME_TO_MONITOR, "SCREEN_CAPTURE", SignalReaders.visualState(bitmap, result.green, result.yellow), result.confidence));
                analyzer.save(result);
                broadcast(format(result));
                updateOverlay(result);
            } catch (Throwable e) {
                broadcast("خطأ أثناء تحليل اللقطة: " + e.getClass().getSimpleName());
            } finally {
                if (image != null) image.close();
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }, worker);

        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            updateOverlay(null);
        }
        broadcast("تم بدء التقاط الشاشة — في انتظار مؤشرات اللعبة...");
        return START_NOT_STICKY;
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, "capture")
                .setContentTitle("محظوظ")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void broadcast(String text) {
        Intent out = new Intent(ACTION_RESULT);
        out.setPackage(getPackageName());
        out.putExtra("text", text);
        sendBroadcast(out);
    }

    private String format(AnalysisResult r) {
        if (r == null) return "";
        return "تم الرصد: " + r.green.size() + " | " + r.yellow.size() + (r.ocrText.isEmpty() ? "" : " | OCR: " + r.ocrText);
    }

    private void updateOverlay(AnalysisResult r) {
        if (Build.VERSION.SDK_INT < 23 || !Settings.canDrawOverlays(this)) { removeOverlay(); return; }
        if (mainHandler != null && android.os.Looper.myLooper() != mainHandler.getLooper()) {
            mainHandler.post(() -> updateOverlay(r));
            return;
        }
        try {
            ensureOverlay();
            if (r == null) {
                liveText.setText("");
                exploreText.setText("");
                return;
            }
            TextView gameTitle = overlayView.findViewById(R.id.tvCurrentGameTitle);
            if (gameTitle != null) gameTitle.setText("اللعبة الحالية: " + analyzer.currentGameModeName());
            liveText.setText(buildLiveOverlay(r));
            exploreText.setText(buildExploreOverlay(r));
        } catch (Throwable ignored) {}
    }

    private void ensureOverlay() {
        if (overlayManager == null) overlayManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        overlayView = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);
        liveText = overlayView.findViewById(R.id.tvLiveText);
        exploreText = overlayView.findViewById(R.id.tvExploreText);
        TextView gameTitle = overlayView.findViewById(R.id.tvCurrentGameTitle);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        overlayParams = new WindowManager.LayoutParams(
                dp(440), dp(290), type, flags, PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;

        android.content.SharedPreferences sp = getSharedPreferences("overlay", MODE_PRIVATE);
        overlayParams.x = sp.getInt("x", 8);
        overlayParams.y = sp.getInt("y", 70);
        overlayParams.width = Math.max(dp(300), sp.getInt("w", dp(440)));
        overlayParams.height = Math.max(dp(190), sp.getInt("h", dp(290)));

        PinchResizeFrame frame = new PinchResizeFrame(this);
        overlayContainer = frame;
        frame.addView(overlayView, new FrameLayout.LayoutParams(-1, -1));
        overlayManager.addView(frame, overlayParams);

        View.OnTouchListener drag = new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY(); startX=overlayParams.x; startY=overlayParams.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (e.getPointerCount() == 1) {
                            overlayParams.x=startX+Math.round(e.getRawX()-downX);
                            overlayParams.y=startY+Math.round(e.getRawY()-downY);
                            try { overlayManager.updateViewLayout(frame, overlayParams); } catch(Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences("overlay", MODE_PRIVATE).edit()
                                .putInt("x",overlayParams.x).putInt("y",overlayParams.y)
                                .putInt("w",overlayParams.width).putInt("h",overlayParams.height).apply();
                        return true;
                }
                return false;
            }
        };
        gameTitle.setOnTouchListener(drag);
    }

    /**
     * Floating overlay container that keeps one-finger dragging on the section
     * headers and adds two-finger pinch zoom anywhere inside the overlay.
     */
    private class PinchResizeFrame extends FrameLayout {
        private final ScaleGestureDetector scaleDetector;

        PinchResizeFrame(android.content.Context context) {
            super(context);
            scaleDetector = new ScaleGestureDetector(context,
                    new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                        @Override public boolean onScale(ScaleGestureDetector detector) {
                            if (overlayParams == null || overlayManager == null) return true;

                            float factor = detector.getScaleFactor();
                            if (Float.isNaN(factor) || Float.isInfinite(factor)) return true;
                            if (factor < 0.5f) factor = 0.5f;
                            if (factor > 2.0f) factor = 2.0f;

                            DisplayMetrics dm = getResources().getDisplayMetrics();
                            int maxW = Math.max(dp(300), Math.round(dm.widthPixels * 0.96f));
                            int maxH = Math.max(dp(190), Math.round(dm.heightPixels * 0.70f));

                            int newW = Math.round(overlayParams.width * factor);
                            int newH = Math.round(overlayParams.height * factor);
                            overlayParams.width = Math.max(dp(300), Math.min(maxW, newW));
                            overlayParams.height = Math.max(dp(190), Math.min(maxH, newH));

                            try {
                                overlayManager.updateViewLayout(PinchResizeFrame.this, overlayParams);
                            } catch (Exception ignored) {}
                            return true;
                        }
                    });
        }

        @Override public boolean onInterceptTouchEvent(MotionEvent ev) {
            // Keep the detector's initial ACTION_DOWN while one finger is used.
            // As soon as a second finger appears, take over the gesture and resize
            // the complete floating window with a two-finger pinch.
            if (ev.getPointerCount() < 2) {
                scaleDetector.onTouchEvent(ev);
                return false;
            }
            return true;
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            if (event.getActionMasked() == MotionEvent.ACTION_UP
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                getSharedPreferences("overlay", MODE_PRIVATE).edit()
                        .putInt("x", overlayParams.x)
                        .putInt("y", overlayParams.y)
                        .putInt("w", overlayParams.width)
                        .putInt("h", overlayParams.height)
                        .apply();
            }
            return true;
        }
    }

    private LinearLayout makeSection(String title, boolean live) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(7), dp(5), dp(7), dp(7));

        GradientDrawable bg = new GradientDrawable();
        // Semi-transparent section backgrounds keep the game visible underneath.
        bg.setColor(live ? 0x8F171A20 : 0x8F202020);
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(1), live ? 0xC04CAF50 : 0xC0E0B83B);
        box.setBackground(bg);

        TextView header = new TextView(this);
        header.setText(title + "  ⋮⋮");
        header.setTextSize(14);
        header.setTextColor(0xFFFFFFFF);
        header.setTypeface(null, android.graphics.Typeface.BOLD);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, dp(2), 0, dp(5));
        box.addView(header, new LinearLayout.LayoutParams(-1, -2));

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);

        TextView body = new TextView(this);
        body.setTextSize(12.5f);
        body.setTextColor(0xFFFFFFFF);
        body.setGravity(Gravity.RIGHT | Gravity.TOP);
        body.setLineSpacing(dp(2), 1.08f);
        body.setPadding(dp(3), dp(2), dp(3), dp(5));
        scroll.addView(body, new android.widget.ScrollView.LayoutParams(-1, -2));
        box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        if (live) { liveHeader = header; liveText = body; }
        else { exploreHeader = header; exploreText = body; }
        return box;
    }

    private String buildLiveOverlay(AnalysisResult r) {
        StringBuilder s = new StringBuilder();
        if (r.screenState != null) {
            s.append("حالة الشاشة: ").append(r.screenState.scene)
             .append(" — ").append(Math.round(r.screenState.confidence * 100f)).append("%\n");
        }
        s.append(analyzer.systemScreenIndicators(r.ocrText));
        java.util.LinkedHashSet<String> labels = new java.util.LinkedHashSet<>();
        for (int i = 0; i < r.green.size() && i < r.tiles.size(); i++) {
            Detector.Tile t = r.tiles.get(i);
            if (t != null && t.label != null && !t.label.equals("غير معروف")) labels.add(t.label);
        }
        if (!labels.isEmpty()) {
            s.append("العناصر المرصودة\n");
            for (String label : labels) s.append("• ").append(label).append('\n');
        }
        int remaining = RoundCountdown.parseSeconds(r.ocrText);
        if (remaining >= 0) {
            s.append("العداد المرصود: ").append(remaining).append(" ث\n");
            if (remaining <= 2) s.append("آخر ثانيتين — عرض معلومات فقط\n");
        }
        if (!r.ocrText.isEmpty()) s.append("\nالنص المقروء OCR\n").append(r.ocrText).append('\n');
        if (!r.recommendation.isEmpty()) {
            s.append('\n').append(r.recommendation);
        }
        if (s.length() == 0) s.append("لا يوجد رصد مؤكد بعد");
        return s.toString().trim();
    }

    private String buildExploreOverlay(AnalysisResult r) {
        if (r.relations.isEmpty()) return "لا توجد علاقة مؤكدة بعد";
        StringBuilder s = new StringBuilder();
        int n = 0;
        for (String rel : r.relations) {
            if (rel == null || rel.isEmpty()) continue;
            if (n++ >= 12) break;
            s.append(rel).append('\n');
        }
        return s.toString().trim();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void removeOverlay() {
        if (overlayView != null && overlayManager != null) {
            try { overlayManager.removeView(overlayContainer != null ? overlayContainer : overlayView); } catch (Exception ignored) {}
        }
        overlayView = null; overlayContainer = null; overlayManager = null; overlayParams = null;
        liveText = null; exploreText = null; liveHeader = null; exploreHeader = null;
    }

    private void cleanupCapture() {
        running = false;
        removeOverlay();
        try { if (reader != null) { reader.close(); reader = null; } } catch (Throwable ignored) {}
        try { if (display != null) { display.release(); display = null; } } catch (Throwable ignored) {}
        try { if (projection != null) { projection.stop(); projection = null; } } catch (Throwable ignored) {}
        try { if (workerThread != null) { workerThread.quitSafely(); workerThread = null; worker = null; } } catch (Throwable ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "capture", "مراقبة الشاشة", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // The floating window must never outlive the app task.
        removeOverlay();
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        removeOverlay();
        try { if (analyzer != null) { analyzer.close(); analyzer.db().endPlaySession(System.currentTimeMillis()); } } catch (Throwable ignored) {}
        cleanupCapture();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
