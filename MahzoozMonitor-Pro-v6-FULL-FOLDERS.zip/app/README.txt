Android application module.
