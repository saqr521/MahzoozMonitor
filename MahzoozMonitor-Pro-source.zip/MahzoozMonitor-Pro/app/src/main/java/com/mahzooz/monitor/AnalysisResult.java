package com.mahzooz.monitor;

import java.util.*;

public class AnalysisResult {
    public final long time;
    public final List<Detector.Marker> green;
    public final List<Detector.Marker> yellow;
    public final float confidence;
    public AnalysisResult(long time, List<Detector.Marker> g, List<Detector.Marker> y, float c) {
        this.time=time; this.green=g; this.yellow=y; this.confidence=c;
    }
    @Override public String toString() {
        return "green=" + green.size() + ", yellow=" + yellow.size()
            + ", confidence=" + Math.round(confidence*100) + "%";
    }
}
