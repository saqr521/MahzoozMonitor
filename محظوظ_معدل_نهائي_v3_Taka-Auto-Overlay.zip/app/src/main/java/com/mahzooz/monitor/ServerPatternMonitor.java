package com.mahzooz.monitor;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Local observational telemetry only.
 *
 * server_pool_estimate is deliberately a normalized observation index, NOT an
 * estimate of the casino/server's real money balance and NOT a prediction.
 * It is based only on OCR-visible rounds/multipliers.
 */
public final class ServerPatternMonitor {
    public static final class Snapshot {
        public final double serverPoolEstimate;
        public final int smallRoundStreak;
        public final String traffic;
        public final String trafficText;
        public final String whaleText;
        public final String matrixText;
        public final String stopLossText;

        Snapshot(double pool, int streak, String traffic, String trafficText,
                 String whaleText, String matrixText, String stopLossText) {
            this.serverPoolEstimate = pool;
            this.smallRoundStreak = streak;
            this.traffic = traffic;
            this.trafficText = trafficText;
            this.whaleText = whaleText;
            this.matrixText = matrixText;
            this.stopLossText = stopLossText;
        }

        public String format() {
            StringBuilder b = new StringBuilder();
            b.append("واجهة المراقبة المركبة\n");
            b.append("الحالة: ").append(trafficText).append('\n');
            b.append("server_pool_estimate (مؤشر مرصود فقط): ")
                    .append(Math.round(serverPoolEstimate)).append("%\n");
            if (smallRoundStreak > 0)
                b.append("سلسلة المضاعفات الصغيرة المرصودة: ").append(smallRoundStreak).append('\n');
            if (!whaleText.isEmpty()) b.append(whaleText).append('\n');
            if (!matrixText.isEmpty()) b.append(matrixText).append('\n');
            if (!stopLossText.isEmpty()) b.append(stopLossText);
            return b.toString().trim();
        }
    }

    private static final Pattern MULT = Pattern.compile("(?i)(?:x|×)\\s*(\\d{1,3})");
    private static final Pattern PLAYER = Pattern.compile(
            "(?iu)(?:الفائز|winner|لاعب|player)\\s*[:：-]?\\s*([\\p{L}\\p{N}_@.\\-]{2,32})");
    private static final Pattern BIG = Pattern.compile("(?i)(?:x|×)\\s*(50|100|[2-9]\\d{2,})");

    private final ArrayDeque<Integer> recentMultipliers = new ArrayDeque<>();
    private final ArrayDeque<Long> recentTimes = new ArrayDeque<>();
    private final LinkedHashMap<String,Integer> playerWins = new LinkedHashMap<>();
    private int consecutiveLosses = 0;
    private int observedWins = 0;
    private int observedLosses = 0;
    private long lastBigWinAt = 0L;
    private String lastGift = "";

    public synchronized Snapshot observe(String ocrText, String giftLabel, long now) {
        String text = ocrText == null ? "" : ocrText;
        Matcher mm = MULT.matcher(text);
        int lastMult = -1;
        while (mm.find()) {
            try { lastMult = Integer.parseInt(mm.group(1)); } catch (Exception ignored) {}
        }
        if (lastMult > 0) {
            recentMultipliers.addLast(lastMult);
            recentTimes.addLast(now);
            while (recentMultipliers.size() > 30) recentMultipliers.removeFirst();
            while (recentTimes.size() > 30) recentTimes.removeFirst();
            if (lastMult >= 50) lastBigWinAt = now;
        }

        Matcher pm = PLAYER.matcher(text);
        if (pm.find() && lastMult >= 50) {
            String player = pm.group(1);
            playerWins.put(player, playerWins.getOrDefault(player, 0) + 1);
            while (playerWins.size() > 20) playerWins.remove(player);
        }

        String low = text.toLowerCase(Locale.ROOT);
        if (containsAny(low, "خسارة", "خسرت", "loss", "lost")) {
            observedLosses++;
            consecutiveLosses++;
        } else if (containsAny(low, "فوز", "ربح", "win", "won")) {
            observedWins++;
            consecutiveLosses = 0;
        }
        if (giftLabel != null && !giftLabel.trim().isEmpty()) lastGift = giftLabel.trim();

        int small = 0;
        for (Integer v : recentMultipliers) if (v != null && (v == 2 || v == 5)) small++;
        int streak = 0;
        Iterator<Integer> it = recentMultipliers.descendingIterator();
        while (it.hasNext()) {
            int v = it.next();
            if (v == 2 || v == 5) streak++; else break;
        }

        // Normalized observation score: 10..15 consecutive x2/x5 observations
        // increase the index. It does NOT model or infer server finances.
        double pool = Math.min(100d, small * 6.67d);
        String traffic = pool >= 85 ? "أصفر" : "أخضر";
        String trafficText = pool >= 85
                ? "مراقبة: تكرار مضاعفات صغيرة مرتفع"
                : "مراقبة: لا توجد إشارة قوية من البيانات المرصودة";

        String whale = buildWhaleText();
        String matrix = buildMatrixText(giftLabel, now);
        String stop = consecutiveLosses >= 3
                ? "تحذير حماية: تم رصد 3 خسائر متتالية في OCR؛ خذ استراحة ولا تحاول تعويض الخسارة."
                : "";

        return new Snapshot(pool, streak, traffic, trafficText, whale, matrix, stop);
    }

    private String buildWhaleText() {
        String best = ""; int n = 0;
        for (Map.Entry<String,Integer> e : playerWins.entrySet()) {
            if (e.getValue() > n) { best = e.getKey(); n = e.getValue(); }
        }
        if (best.isEmpty()) return "";
        return "حسابات فائزة مرصودة: " + best + " (" + n + " مرات). لا يتم نسخ رهانه أو إصدار أمر مراهنة.";
    }

    private String buildMatrixText(String gift, long now) {
        if (lastBigWinAt <= 0 || gift == null || gift.trim().isEmpty()) return "";
        long elapsed = Math.max(0, now - lastBigWinAt);
        long sec = elapsed / 1000L;
        return "مصفوفة رصد: الهدية=" + gift.trim() + " | الزمن منذ آخر ضربة كبيرة مرصودة=" + sec +
                "ث | ارتباط وصفي فقط، بلا احتمال للضربة التالية.";
    }

    private static boolean containsAny(String s, String... values) {
        for (String v : values) if (s.contains(v)) return true;
        return false;
    }
}
