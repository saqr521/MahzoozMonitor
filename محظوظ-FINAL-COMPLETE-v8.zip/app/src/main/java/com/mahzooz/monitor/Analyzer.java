package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.Bitmap;
import java.util.*;

public class Analyzer {
    private final TemplateRepository templates;
    private final HistoryDb db;
    private long lastFrameHash = 0;
    private String lastGreenSignature = "";
    private String lastYellowSignature = "";

    public Analyzer(Context c){ templates=new TemplateRepository(c); db=new HistoryDb(c); }

    public synchronized AnalysisResult analyze(Bitmap bmp){
        List<Detector.Marker> g=Detector.findMarkers(bmp,true);
        List<Detector.Marker> y=Detector.findMarkers(bmp,false);
        sortMarkers(g); sortMarkers(y);

        // Always run tile detection. Markers are badges; the tile below each badge
        // is the actual item name used for the learned relation map.
        // Every colored badge belongs to one inventory icon. Build the tile directly
        // from the badge position; this works for 4-column layouts and for rows that
        // move after a scroll instead of assuming a fixed six-column grid.
        List<Detector.Tile> greenItems=new ArrayList<>();
        for(Detector.Marker m:g) { Detector.Tile t=Detector.itemForMarker(bmp,m,templates); greenItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> yellowItems=new ArrayList<>();
        for(Detector.Marker m:y) { Detector.Tile t=Detector.itemForMarker(bmp,m,templates); yellowItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> tiles=new ArrayList<>();
        tiles.addAll(greenItems);
        for(Detector.Tile t:yellowItems){
            boolean dup=false;
            for(Detector.Tile e:tiles) if(!e.rect.isEmpty() && !t.rect.isEmpty() && centerDistance(e.rect,t.rect)<20){dup=true;break;}
            if(!dup) tiles.add(t);
        }

        String current=signature(greenItems);
        String currentYellow=signature(yellowItems);
        List<String> relations=buildRelations(greenItems,yellowItems,lastGreenSignature,lastYellowSignature,current,currentYellow);
        String recommendation=updateAndRecommend(lastGreenSignature,current);
        AlgorithmTrace.recordGameToMonitor(g, y, greenItems, yellowItems, relations);
        if(!recommendation.isEmpty()) AlgorithmTrace.recordMonitorOutput(recommendation);
        lastGreenSignature=current;
        lastYellowSignature=currentYellow;

        long screenHash=Detector.phash(bmp,new Rect(0,0,bmp.getWidth(),bmp.getHeight()));
        String change=lastFrameHash==0?"بدء الرصد":(Long.bitCount(screenHash^lastFrameHash)>10?"تغير ملحوظ في الشاشة":"");
        lastFrameHash=screenHash;

        float confidence=.35f;
        if(!g.isEmpty()||!y.isEmpty()) confidence+=.20f;
        if(!tiles.isEmpty()) confidence+=.15f;
        if(!relations.isEmpty()) confidence+=.15f;
        if(!recommendation.isEmpty()) confidence+=.05f;
        String coordinates = buildCoordinates(g, y, greenItems, yellowItems, bmp.getWidth(), bmp.getHeight());
        return new AnalysisResult(System.currentTimeMillis(),g,y,tiles,relations,recommendation,change,Math.min(1f,confidence),coordinates);
    }

    private static void sortMarkers(List<Detector.Marker> a){
        Collections.sort(a,(x,z)->{int d=Integer.compare(x.rect.top,z.rect.top);return d!=0?d:Integer.compare(x.rect.left,z.rect.left);});
    }

    private List<Detector.Tile> attachMarkersToTiles(List<Detector.Marker> markers,List<Detector.Tile> tiles,Bitmap bmp,TemplateRepository repo){
        ArrayList<Detector.Tile> out=new ArrayList<>();
        Set<Integer> used=new HashSet<>();
        for(Detector.Marker m:markers){
            double best=Double.MAX_VALUE; int bi=-1;
            double mx=(m.rect.left+m.rect.right)/2.0, my=(m.rect.top+m.rect.bottom)/2.0;
            for(int i=0;i<tiles.size();i++) if(!used.contains(i)){
                Rect r=tiles.get(i).rect;
                double tx=(r.left+r.right)/2.0, ty=(r.top+r.bottom)/2.0;
                // Badge normally sits near the upper-right of its tile.
                double dx=mx-tx, dy=my-ty;
                double d=Math.hypot(dx,dy);
                if(d<best && dy>-r.height()*0.75 && dy<r.height()*0.75) {best=d;bi=i;}
            }
            if(bi>=0 && best<Math.max(bmp.getWidth()/4.0,120)) {used.add(bi); out.add(tiles.get(bi));}
            else out.add(new Detector.Tile(new Rect(),0,"غير معروف",0));
        }
        return out;
    }

    private List<String> buildRelations(List<Detector.Tile> green,List<Detector.Tile> yellow,
                                         String previousGreen,String previousYellow,
                                         String currentGreen,String currentYellow){
        ArrayList<String> out=new ArrayList<>();
        Set<String> beforeG=labels(previousGreen), nowG=labels(currentGreen);
        Set<String> beforeY=labels(previousYellow), nowY=labels(currentYellow);
        Set<String> newG=new LinkedHashSet<>(nowG); newG.removeAll(beforeG);
        Set<String> consumedY=new LinkedHashSet<>(beforeY); consumedY.removeAll(nowY);

        // Learn a relation from a temporal change, not from screen proximity.
        // This is important because the yellow and green icons can be in different rows.
        if(!newG.isEmpty() && !consumedY.isEmpty()){
            for(String g:newG) for(String y:consumedY){
                db.observeRelation(g,y);
                int hits=db.relationHits(g,y), total=db.relationTotal(g);
                int pct=total>0?Math.round(100f*hits/total):0;
                out.add("🟩 "+g+" ← 🟨 "+y+" | نسبة الربط المرصودة: "+pct+"% ("+hits+"/"+total+")");
            }
        }

        // Also report the strongest previously learned relations for currently visible greens.
        for(String g:nowG){
            List<String> learned=db.relationsFor(g,3);
            for(String item:learned) if(!out.contains(item)) out.add(item);
        }
        return out;
    }

    private static Set<String> labels(String signature){
        LinkedHashSet<String> s=new LinkedHashSet<>();
        if(signature==null||signature.isEmpty()) return s;
        for(String x:signature.split(";")) if(!x.isEmpty()) s.add(x);
        return s;
    }

    private String signature(List<Detector.Tile> items){
        StringBuilder s=new StringBuilder();
        for(Detector.Tile t) if(!t.label.equals("غير معروف")) s.append(t.label).append(';');
        return s.toString();
    }

    private String updateAndRecommend(String previous,String current){
        if(previous==null||previous.isEmpty()||current==null||current.isEmpty()||previous.equals(current)) return "";
        Set<String> before=new LinkedHashSet<>(Arrays.asList(previous.split(";")));
        String next="";
        for(String item:current.split(";")){
            if(!item.isEmpty() && !before.contains(item)){ next=item; break; }
        }
        if(next.isEmpty()) return "";
        int total=db.observeTransition(previous,next);
        int best=db.bestTransitionCount(previous);
        if(best < 2) return "تم رصد انتقال جديد: "+next+" — يحتاج مشاهدة إضافية لتثبيت النسبة.";
        int pct=Math.round(100f*best/Math.max(1,total));
        return "الشريط التالي المرصود: "+next+" — "+pct+"% من سجل الانتقالات (ليست ضمانًا لنتيجة عشوائية)";
    }


    private String buildCoordinates(List<Detector.Marker> green,List<Detector.Marker> yellow,
                                    List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,
                                    int width,int height){
        StringBuilder s=new StringBuilder();
        if(!green.isEmpty()){
            s.append("🟩 إحداثيات الشرايط (x,y,w,h): ");
            for(int i=0;i<green.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=green.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!yellow.isEmpty()){
            s.append("🟨 إحداثيات الخزين (x,y,w,h): ");
            for(int i=0;i<yellow.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=yellow.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!greenItems.isEmpty()){
            s.append("📍 مراكز العناصر: ");
            for(int i=0;i<greenItems.size();i++){
                Detector.Tile t=greenItems.get(i); if(t.rect.isEmpty()) continue;
                if(s.charAt(s.length()-1)!=' ') s.append(" ؛ ");
                s.append("🟩 ").append(t.label).append("@").append((t.rect.left+t.rect.right)/2)
                 .append(',').append((t.rect.top+t.rect.bottom)/2);
            }
        }
        return s.toString();
    }

    private static double centerDistance(Rect a,Rect b){
        double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0;
        double bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;
        return Math.hypot(ax-bx,ay-by);
    }
    public void save(AnalysisResult r){db.add(r);} public TemplateRepository templates(){return templates;} public HistoryDb db(){return db;}
}
