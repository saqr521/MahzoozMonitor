package com.mahzooz.monitor;

import java.util.ArrayList;
import java.util.List;

/** Time-series helpers for screen-observation samples. */
public final class TimeSeriesAnalysis {
    public static final class Sample {
        public final long timestampMs;
        public final long elapsedNs;
        public final int green;
        public final int yellow;
        public final float visualConfidence;
        public Sample(long ts,long ns,int g,int y,float c){timestampMs=ts;elapsedNs=ns;green=g;yellow=y;visualConfidence=c;}
    }
    private TimeSeriesAnalysis() {}
    public static double meanIntervalMs(List<Sample> samples){
        if(samples==null||samples.size()<2)return 0;
        long sum=0; int n=0;
        for(int i=1;i<samples.size();i++){ long d=samples.get(i).timestampMs-samples.get(i-1).timestampMs; if(d>=0){sum+=d;n++;} }
        return n==0?0:(double)sum/n;
    }
    public static double trendPerMinute(List<Sample> samples){
        if(samples==null||samples.size()<2)return 0;
        double xMean=0,yMean=0; for(Sample s:samples){xMean+=s.timestampMs/60000.0;yMean+=s.green;} xMean/=samples.size(); yMean/=samples.size();
        double num=0,den=0; for(Sample s:samples){double x=s.timestampMs/60000.0-xMean;num+=x*(s.green-yMean);den+=x*x;}
        return den==0?0:num/den;
    }
    public static List<Double> greenSeries(List<Sample> samples){
        ArrayList<Double> out=new ArrayList<>(); if(samples!=null)for(Sample s:samples)out.add((double)s.green); return out;
    }
}
