package com.mahzooz.monitor;

import java.util.*;

/**
 * Verified, local knowledge extracted from the supplied Taka 1.0.94 APK.
 *
 * Important: these are client-side UI/resource identifiers, not hidden server
 * rules and not proof of future results. The catalog is used only to make the
 * screen router more precise when Taka is visible.
 */
public final class TakaGameKnowledge {
    public static final String PACKAGE = "com.taka.vhgyk";
    public static final String VERSION = "1.0.94";

    private static final Set<String> VERIFIED_WHEEL_TOKENS;
    private static final Set<String> VERIFIED_GAME_UI_TOKENS;
    private static final Set<String> VERIFIED_RESULT_TOKENS;

    static {
        VERIFIED_WHEEL_TOKENS = set(
                "lucky_wheel_close", "lucky_wheel_close_free", "lucky_wheel_end_game",
                "lucky_wheel_join", "lucky_wheel_join_coins", "lucky_wheel_layout",
                "lucky_wheel_layout_in", "lucky_wheel_ok", "lucky_wheel_out",
                "lucky_wheel_running", "lucky_wheel_start", "lucky_wheel_start_game",
                "lucky_wheel_update", "lucky_wheel_view", "lucky_wheel_wait",
                "lwchat_iv_room_lucky_wheel", "lwchat_lucky_wheel_1",
                "lwchat_lucky_wheel_2", "lwchat_lucky_wheel_float",
                "lwchat_lucky_wheel_layout", "ic_room_spin", "ic_room_spin_get",
                "lwchat_game_type_demo"
        );
        VERIFIED_GAME_UI_TOKENS = set(
                "room_type_game_item_select", "room_type_game_item_select_error",
                "room_type_game_item_unselect", "game_dialog_layout",
                "lwchat_create_choose_game_dialog", "lwchat_explore_game_item",
                "lwchat_activity_webview_layout_game", "lwchat_fragment_room_start_game",
                "lwchat_fragment_room_end_game", "lwchat_game_share_item",
                "lwchat_game_share_layout", "lwchat_room_game_pk_view",
                "lwchat_dialog_room_game_pk", "lwchat_dialog_room_game_pk_rank",
                "lwchat_dialog_room_game_pk_rule", "lwchat_item_game_pk_config",
                "lwchat_item_game_pk_rank", "lwchat_item_game_pk_time",
                "lwchat_item_party_top_game", "lwchat_exchange_game_coins",
                "lwchat_exchange_game_coins_item", "shape_home_tab_game",
                "shape_g_tag_game", "shape_act_item_bg_game_select"
        );
        VERIFIED_RESULT_TOKENS = set(
                "lwchat_calculate_result_item_layout", "lwchat_dialog_calculate_result_layout",
                "tv_result_item_name", "coins_result_item_name", "resultKey", "getResult"
        );
    }

    private TakaGameKnowledge() {}

    private static Set<String> set(String... values) {
        return Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(values)));
    }

    public static boolean hasVerifiedWheelEvidence(String text) {
        return containsToken(text, VERIFIED_WHEEL_TOKENS);
    }

    public static boolean hasVerifiedGameUiEvidence(String text) {
        return containsToken(text, VERIFIED_GAME_UI_TOKENS);
    }

    public static boolean hasVerifiedResultEvidence(String text) {
        return containsToken(text, VERIFIED_RESULT_TOKENS);
    }

    /** Returns the strongest verified Taka UI profile visible in OCR text. */
    public static String profileForText(String text) {
        if (hasVerifiedWheelEvidence(text)) return "عجلة محظوظ داخل Taka";
        if (hasVerifiedResultEvidence(text)) return "واجهة نتائج لعبة داخل Taka";
        if (hasVerifiedGameUiEvidence(text)) return "واجهة ألعاب Taka";
        return "غير محدد";
    }

    /** Compact diagnostic text for the overlay/log; no network access. */
    public static String evidenceSummary(String text) {
        ArrayList<String> parts = new ArrayList<>();
        if (hasVerifiedWheelEvidence(text)) parts.add("عجلة/Spin");
        if (hasVerifiedResultEvidence(text)) parts.add("نتائج");
        if (hasVerifiedGameUiEvidence(text)) parts.add("واجهة ألعاب");
        return parts.isEmpty() ? "لا توجد بصمة Taka مؤكدة" : String.join(" + ", parts);
    }

    private static boolean containsToken(String text, Set<String> tokens) {
        if (text == null || text.isEmpty()) return false;
        String t = text.toLowerCase(Locale.ROOT);
        for (String token : tokens) if (t.contains(token.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}
