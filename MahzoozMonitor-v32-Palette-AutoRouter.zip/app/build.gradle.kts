plugins {
    id("com.android.application")
}

android {
    namespace = "com.mahzooz.monitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mahzooz.monitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 30
        versionName = "8.0.2-auto-router"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

configurations.configureEach {
    resolutionStrategy.eachDependency {
        if (requested.group == "org.jetbrains.kotlin") {
            useVersion("1.8.22")
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.palette:palette:1.0.0")
    // OpenCV is used only for local, read-only computer-vision analysis.
    implementation("org.opencv:opencv:4.10.0")
    // On-device OCR for text/numbers visible in captured game frames.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
