plugins {
    id("com.android.application")
}

android {
    namespace = "com.mahzooz.monitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mahzooz.monitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 26
        versionName = "7.8.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

configurations.configureEach {
    resolutionStrategy.eachDependency {
        if (requested.group == "org.jetbrains.kotlin") {
            useVersion("1.8.22")
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // OpenCV is used only for local, read-only computer-vision analysis.
    implementation("org.opencv:opencv:4.10.0")
}
