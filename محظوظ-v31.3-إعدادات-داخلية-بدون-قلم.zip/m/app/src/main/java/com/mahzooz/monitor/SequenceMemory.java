package com.mahzooz.monitor;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Bounded sequence memory using Queue/List/collections/deque primitives.
 * It stores observations produced by our own read-only analyzer, not game internals.
 */
public final class SequenceMemory {
    public static final class NumericalValues {
        public final long timestampMs;
        public final float confidence;
        public final float opticalFlow;
        public final int greenCount;
        public final int yellowCount;
        NumericalValues(long ts, float c, float flow, int g, int y) {
            timestampMs=ts; confidence=c; opticalFlow=flow; greenCount=g; yellowCount=y;
        }
    }

    private final int maxSize;
    private final Deque<String> stateDeque = new ArrayDeque<>();
    private final List<String> stateList = new ArrayList<>();
    private final Queue<String> pendingQueue = new ConcurrentLinkedQueue<>();
    private final Deque<NumericalValues> numericDeque = new ArrayDeque<>();
    private final Map<String,Integer> frequencies = new LinkedHashMap<>();

    public SequenceMemory(int maxSize) { this.maxSize = Math.max(8, maxSize); }

    public synchronized void observeState(String signature) {
        if (signature == null) signature = "";
        stateDeque.addLast(signature);
        stateList.add(signature);
        pendingQueue.offer(signature);
        frequencies.put(signature, frequencies.containsKey(signature) ? frequencies.get(signature)+1 : 1);
        trim();
    }

    public synchronized void observeNumbers(long ts, float confidence, float flow, int green, int yellow) {
        numericDeque.addLast(new NumericalValues(ts, confidence, flow, green, yellow));
        while (numericDeque.size() > maxSize) numericDeque.removeFirst();
    }

    public synchronized List<String> recentStates(int count) {
        int n = Math.min(Math.max(0,count), stateDeque.size());
        List<String> out = new ArrayList<>(n);
        int skip = stateDeque.size()-n, i=0;
        for (String s : stateDeque) if (i++ >= skip) out.add(s);
        return out;
    }

    public synchronized String lastState() { return stateDeque.peekLast(); }
    public synchronized int frequency(String signature) { Integer n=frequencies.get(signature); return n==null?0:n; }
    public int pendingCount() { return pendingQueue.size(); }

    public synchronized double averageConfidence() {
        if (numericDeque.isEmpty()) return 0;
        double s=0; for (NumericalValues v:numericDeque) s+=v.confidence; return s/numericDeque.size();
    }
    public synchronized double averageOpticalFlow() {
        if (numericDeque.isEmpty()) return 0;
        double s=0; for (NumericalValues v:numericDeque) s+=v.opticalFlow; return s/numericDeque.size();
    }

    private void trim() {
        while (stateDeque.size()>maxSize) stateDeque.removeFirst();
        while (stateList.size()>maxSize) stateList.remove(0);
        while (pendingQueue.size()>maxSize) pendingQueue.poll();
    }

    public synchronized String summary() {
        return "sequence="+stateDeque.size()+" pending="+pendingQueue.size()+
                " avgConfidence="+String.format(java.util.Locale.US,"%.3f",averageConfidence())+
                " avgFlow="+String.format(java.util.Locale.US,"%.3f",averageOpticalFlow());
    }
}
