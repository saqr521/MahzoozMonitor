package com.mahzooz.monitor;

import java.util.*;

/**
 * Mines only observed n-gram chains. It can report 2-, 3-, and 5-step chains
 * that actually occurred; it does not claim that an unobserved future chain is
 * predictable.
 */
public final class DeepChainPatternEngine {
    public static final class Report {
        public final String text;
        Report(String text){this.text=text==null?"":text;}
    }

    public Report analyze(List<String> input){
        ArrayList<String> h=new ArrayList<>();
        if(input!=null)for(String s:input)if(s!=null&&!s.trim().isEmpty())h.add(s.trim());
        if(h.size()>30)h=new ArrayList<>(h.subList(h.size()-30,h.size()));
        StringBuilder out=new StringBuilder("Deep Chain Patterns المرصودة\n");
        if(h.isEmpty()) return new Report(out.append("لا توجد سلسلة كافية بعد.").toString());
        out.append("آخر ").append(h.size()).append(" حالات: ").append(join(h," ← ")).append('\n');
        appendNgram(out,h,2); appendNgram(out,h,3);
        if(h.size()>=5) out.append("آخر سلسلة خماسية مكتملة: ")
                .append(join(h.subList(h.size()-5,h.size())," ← ")).append('\n');
        out.append("المعروض تاريخ مرصود فقط؛ لا يتم تحويله إلى توقع مضمون للخطوة التالية.");
        return new Report(out.toString().trim());
    }

    private void appendNgram(StringBuilder out,List<String> h,int n){
        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
        for(int i=0;i+n<=h.size();i++){
            String k=join(h.subList(i,i+n)," → ");
            counts.put(k,counts.getOrDefault(k,0)+1);
        }
        String best="";int count=0;
        for(Map.Entry<String,Integer> e:counts.entrySet())if(e.getValue()>count){best=e.getKey();count=e.getValue();}
        if(count>0)out.append("أكثر سلسلة ").append(n).append("-خطوات مرصودة: ").append(best).append(" (" ).append(count).append(" مرات)\n");
    }
    private String join(List<String> x,String sep){StringBuilder b=new StringBuilder();for(int i=0;i<x.size();i++){if(i>0)b.append(sep);b.append(x.get(i));}return b.toString();}
}
