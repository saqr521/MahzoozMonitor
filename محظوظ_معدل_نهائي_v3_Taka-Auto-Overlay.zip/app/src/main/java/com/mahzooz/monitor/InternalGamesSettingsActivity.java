package com.mahzooz.monitor;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Runtime game discovery page.
 * No hard-coded game catalogue is presented as if those games were installed.
 */
public class InternalGamesSettingsActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(22),dp(18),dp(18));
        root.setBackgroundColor(Color.rgb(9,14,20));

        TextView title=new TextView(this);
        title.setText("اكتشاف الألعاب الداخلية");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.RIGHT);
        title.setTypeface(null,1);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(64)));

        TextView body=new TextView(this);
        body.setText(
            "لا توجد قائمة ألعاب ثابتة هنا.\n\n" +
            "أثناء تشغيل المراقبة سيقرأ البرنامج الشاشة الفعلية، " +
            "ويحدد ملف اللعبة فقط عندما توجد أدلة مرئية/مقروءة كافية.\n\n" +
            "اللعبة غير المؤكدة ستظهر كـ «غير محددة» بدل إنشاء لعبة أو أيقونة وهمية."
        );
        body.setTextColor(Color.LTGRAY);
        body.setTextSize(16);
        body.setGravity(Gravity.RIGHT | Gravity.TOP);
        body.setLineSpacing(dp(4),1.1f);
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1f));
        setContentView(root);
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
