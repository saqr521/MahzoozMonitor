# v23 — Settings + Persistent Game History

- Added a dedicated Settings screen opened from the small gear icon at the top of the main app screen.
- Added a visible **📚 سجل اللعب المحفوظ** section inside Settings.
- Game observations, learned relations, transitions, interaction references, analytics and observed hit plans remain in `mahzooz_history.db` across app restarts.
- Added an explicit **🗑️ مسح سجل اللعب بالكامل** action with confirmation. Nothing in the monitoring loop calls it, so history is not auto-deleted.
- Added a persisted-record counter in Settings.
- The manual delete clears stored learning/history tables only after the user confirms.
- No game input automation, game-data modification, process injection, traffic interception, TLS bypass, or root hooks were added.
