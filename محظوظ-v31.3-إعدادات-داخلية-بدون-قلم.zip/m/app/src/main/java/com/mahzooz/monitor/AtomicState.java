package com.mahzooz.monitor;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Lock-free counters for the analyzer's own state. This is the Android/Java
 * counterpart of std::atomic; it never touches another process's memory.
 */
public final class AtomicState {
    private final AtomicLong frames = new AtomicLong();
    private final AtomicLong lastTimestampMs = new AtomicLong();
    private final AtomicInteger activeWorkers = new AtomicInteger();

    public long recordFrame(long timestampMs) {
        lastTimestampMs.set(timestampMs);
        return frames.incrementAndGet();
    }
    public int workerEnter() { return activeWorkers.incrementAndGet(); }
    public int workerExit() { return activeWorkers.updateAndGet(v -> Math.max(0, v - 1)); }
    public long frameCount() { return frames.get(); }
    public long lastTimestampMs() { return lastTimestampMs.get(); }
    public int activeWorkers() { return activeWorkers.get(); }

    public String summary() {
        return "atomicFrames=" + frameCount() + " activeWorkers=" + activeWorkers() +
                " lastTs=" + lastTimestampMs();
    }
}
