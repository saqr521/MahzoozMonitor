plugins {
    id("com.android.application")
}

android {
    namespace = "com.mahzooz.monitor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mahzooz.monitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "6.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
