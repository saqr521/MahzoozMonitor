package com.mahzooz.monitor;

/**
 * Normalized record for telemetry the user explicitly exported from a system
 * they control.  This is intentionally not a packet/sniffing record.
 */
public final class ImportedTelemetryRecord {
    public final long timestampMs;
    public final String event;
    public final String value;

    public ImportedTelemetryRecord(long timestampMs, String event, String value) {
        this.timestampMs = timestampMs;
        this.event = event == null ? "" : event;
        this.value = value == null ? "" : value;
    }
}
