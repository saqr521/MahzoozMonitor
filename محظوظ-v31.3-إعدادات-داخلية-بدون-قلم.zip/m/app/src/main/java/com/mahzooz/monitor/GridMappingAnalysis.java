package com.mahzooz.monitor;

import android.graphics.Rect;
import java.util.*;

/** Read-only spatial mapping of detected tiles into rows/columns. */
public final class GridMappingAnalysis {
    public static final class Cell {
        public final int row, column;
        public final String label;
        public final Rect bounds;
        Cell(int r,int c,String l,Rect b){row=r;column=c;label=l;bounds=b;}
    }

    private GridMappingAnalysis() {}

    public static List<Cell> map(List<Detector.Tile> tiles) {
        ArrayList<Cell> out=new ArrayList<>();
        if(tiles==null||tiles.isEmpty()) return out;
        ArrayList<Detector.Tile> sorted=new ArrayList<>(tiles);
        Collections.sort(sorted,(a,b)->{
            int dy=Integer.compare(a.rect.centerY(),b.rect.centerY());
            return dy!=0?dy:Integer.compare(a.rect.centerX(),b.rect.centerX());
        });
        ArrayList<Integer> rowCenters=new ArrayList<>();
        int rowTolerance=24;
        for(Detector.Tile t:sorted){
            int cy=t.rect.centerY(), row=-1;
            for(int i=0;i<rowCenters.size();i++) if(Math.abs(cy-rowCenters.get(i))<=rowTolerance){row=i;break;}
            if(row<0){rowCenters.add(cy);row=rowCenters.size()-1;}
            ArrayList<Integer> cols=new ArrayList<>();
            for(Detector.Tile x:sorted) if(Math.abs(x.rect.centerY()-rowCenters.get(row))<=rowTolerance) cols.add(x.rect.centerX());
            Collections.sort(cols);
            int col=0; for(int i=0;i<cols.size();i++) if(cols.get(i)<t.rect.centerX()) col=i+1;
            out.add(new Cell(row,col,t.label,new Rect(t.rect)));
        }
        Collections.sort(out,(a,b)->{int d=Integer.compare(a.row,b.row);return d!=0?d:Integer.compare(a.column,b.column);});
        return out;
    }

    public static String summary(List<Cell> cells){
        if(cells==null||cells.isEmpty()) return "grid=empty";
        int rows=0,cols=0; for(Cell c:cells){rows=Math.max(rows,c.row+1);cols=Math.max(cols,c.column+1);}
        StringBuilder s=new StringBuilder("grid=").append(rows).append("x").append(cols).append(" | ");
        for(int i=0;i<cells.size();i++){if(i>0)s.append(" ; ");Cell c=cells.get(i);s.append("[").append(c.row).append(",").append(c.column).append("] ").append(c.label);}
        return s.toString();
    }
}
