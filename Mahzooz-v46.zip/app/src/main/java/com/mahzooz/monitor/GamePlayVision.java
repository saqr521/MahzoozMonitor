package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.*;

/**
 * Read-only live board reader. It reads ONLY the user-selected rectangle.
 * The current Taka Jackpot board visible in the supplied screenshots is a
 * 4-column x 3-row grid, so 4x3 is preferred; a 5x3 layout is used only when
 * the geometry gives a clearly better fit. Symbols not present in the bundled
 * Mahzooz gift catalog receive a stable learned visual ID (رمز 1, رمز 2...)
 * instead of a guessed name.
 */
public final class GamePlayVision {
    public static final class Suggestion {
        public final String label; public final int confidencePct; public final int hits; public final int total;
        Suggestion(String l,int c,int h,int t){label=l;confidencePct=Math.max(0,Math.min(100,c));hits=h;total=t;}
    }
    public static final class Result {
        public final boolean gridDetected, stable;
        public final String currentLabel;
        public final int recognitionPct;
        public final List<Suggestion> suggestions;
        public final int changedCells;
        public final String sequence;
        Result(boolean gd,boolean st,String cl,int rp,List<Suggestion> ss,int cc,String seq){
            gridDetected=gd;stable=st;currentLabel=cl;recognitionPct=rp;suggestions=ss;changedCells=cc;sequence=seq;
        }
    }

    private static final int ROWS=3;
    private static final int[] COLUMN_OPTIONS={4,5};
    private final SharedPreferences prefs;
    private final TemplateRepository catalog;
    private final ArrayList<Prototype> prototypes=new ArrayList<>();
    private String lastCandidate="";
    private int stableFrames=0;
    private String committed="";
    private String[] committedCells=null;
    private String lastTrigger="";
    private long lastCommitMs=0;
    private int currentCols=4;

    private static final class Prototype {
        String label; String feature; long hash; Prototype(String l,String f,long h){label=l;feature=f;hash=h;}
    }

    public GamePlayVision(Context c){
        Context app=c.getApplicationContext();
        prefs=app.getSharedPreferences("game_visual_symbols",Context.MODE_PRIVATE);
        catalog=new TemplateRepository(app);
        load();
    }

    public synchronized Result analyze(Bitmap b, HistoryDb db, long nowMs){
        if(b==null||b.isRecycled()||b.getWidth()<260||b.getHeight()<150)
            return empty(false);

        int cols=chooseColumns(b);
        if(cols<4) return empty(false);
        currentCols=cols;
        String[] cells=new String[ROWS*cols];
        int recognized=0;
        for(int row=0;row<ROWS;row++) for(int col=0;col<cols;col++){
            Rect r=cellRect(b,row,col,cols);
            String feature=feature(b,r);
            long hash=Detector.phash(b,r);
            // Do not manufacture a symbol for empty/background cells. A cell is
            // eligible only when it contains enough visual structure/color.
            float quality=cellQuality(b,r);
            String label=quality >= 0.16f ? labelFor(feature,hash) : "";
            cells[row*cols+col]=label;
            if(!label.isEmpty()) recognized++;
        }

        String sig=String.join(";",cells);
        if(sig.equals(lastCandidate)) stableFrames++; else {lastCandidate=sig;stableFrames=1;}

        int changed=0;
        String trigger="";
        if(stableFrames>=2 && !sig.equals(committed)){
            if(committedCells!=null && committedCells.length==cells.length){
                for(int i=0;i<cells.length;i++){
                    String old=committedCells[i], now=cells[i];
                    if(!now.isEmpty()&&!now.equals(old)){
                        changed++;
                        if(trigger.isEmpty()) trigger=now;
                        if(old!=null&&!old.isEmpty()) db.observeGameTransition(old,now);
                    }
                }
            } else {
                for(String x:cells) if(!x.isEmpty()){trigger=x;break;}
            }
            committed=sig;
            committedCells=cells.clone();
            lastCommitMs=nowMs;
            if(!trigger.isEmpty()) lastTrigger=trigger;
        }
        if(trigger.isEmpty()) trigger=lastTrigger;
        if(trigger.isEmpty()) trigger=firstUseful(cells);

        List<Suggestion> suggestions=aggregateSuggestions(cells,db);
        int rec=Math.round(100f*recognized/(float)cells.length);
        // A valid grid with stable learned visual IDs is a real recognition even
        // when the icon has no semantic name in the bundled catalog.
        String sequence=sequenceText(cells,cols);
        return new Result(true,stableFrames>=2,trigger,rec,suggestions,changed,sequence);
    }

    private Result empty(boolean grid){return new Result(grid,false,"",0,Collections.emptyList(),0,"");}

    /** Detect 4x3 vs 5x3 from icon-sized brightness/saturation peaks. */
    private int chooseColumns(Bitmap b){
        int best=4; double bestScore=-1;
        for(int cols:COLUMN_OPTIONS){
            double score=gridScore(b,cols);
            if(score>bestScore){bestScore=score;best=cols;}
        }
        // Never report a grid merely because the selected rectangle is large.
        // The caller uses gridDetected to decide whether a live result is valid.
        return bestScore>=0.24 ? best : 0;
    }

    private double gridScore(Bitmap b,int cols){
        int w=b.getWidth(),h=b.getHeight();
        int left=Math.round(w*.04f), right=Math.round(w*.96f);
        int top=Math.round(h*.04f), bottom=Math.round(h*.96f);
        double score=0; int count=0;
        float[] hsv=new float[3];
        for(int row=0;row<ROWS;row++) for(int col=0;col<cols;col++){
            Rect r=new Rect(left+((right-left)*col)/cols, top+((bottom-top)*row)/ROWS,
                    left+((right-left)*(col+1))/cols, top+((bottom-top)*(row+1))/ROWS);
            int padX=Math.max(4,(int)(r.width()*.18)), padY=Math.max(4,(int)(r.height()*.15));
            r.inset(padX,padY);
            double bright=0,sat=0;
            int samples=0;
            for(int y=r.top;y<r.bottom;y+=Math.max(3,r.height()/10)) for(int x=r.left;x<r.right;x+=Math.max(3,r.width()/10)){
                Color.colorToHSV(b.getPixel(Math.min(w-1,x),Math.min(h-1,y)),hsv);
                bright+=hsv[2]; sat+=hsv[1]; samples++;
            }
            if(samples>0){score += Math.min(1,(bright/samples)*.55+(sat/samples)*.65);count++;}
        }
        return count==0?0:score/count;
    }

    private Rect cellRect(Bitmap b,int row,int col,int cols){
        int w=b.getWidth(),h=b.getHeight();
        int left=Math.round(w*.035f), top=Math.round(h*.035f);
        int right=Math.round(w*.965f), bottom=Math.round(h*.965f);
        int cw=(right-left)/cols, ch=(bottom-top)/ROWS;
        int x=left+col*cw, y=top+row*ch;
        int padX=Math.max(4,Math.round(cw*.15f));
        int padY=Math.max(4,Math.round(ch*.13f));
        return new Rect(x+padX,y+padY,Math.min(right,x+cw-padX),Math.min(bottom,y+ch-padY));
    }

    /** Measures whether a cell contains icon-like visual information instead of
     * a flat/background patch. */
    private float cellQuality(Bitmap b, Rect r){
        if(r==null || r.width()<12 || r.height()<12) return 0f;
        float[] hsv=new float[3];
        double mean=0, variance=0, sat=0;
        int n=0;
        for(int y=r.top;y<r.bottom;y+=Math.max(3,r.height()/12))
            for(int x=r.left;x<r.right;x+=Math.max(3,r.width()/12)){
                int c=b.getPixel(Math.min(b.getWidth()-1,Math.max(0,x)),
                                 Math.min(b.getHeight()-1,Math.max(0,y)));
                double g=.299*Color.red(c)+.587*Color.green(c)+.114*Color.blue(c);
                Color.colorToHSV(c,hsv);
                mean+=g; sat+=hsv[1]; n++;
            }
        if(n==0)return 0f;
        mean/=n; sat/=n;
        for(int y=r.top;y<r.bottom;y+=Math.max(3,r.height()/12))
            for(int x=r.left;x<r.right;x+=Math.max(3,r.width()/12)){
                int c=b.getPixel(Math.min(b.getWidth()-1,Math.max(0,x)),
                                 Math.min(b.getHeight()-1,Math.max(0,y)));
                double g=.299*Color.red(c)+.587*Color.green(c)+.114*Color.blue(c);
                variance+=(g-mean)*(g-mean);
            }
        variance=Math.sqrt(variance/Math.max(1,n))/255.0;
        return (float)Math.min(1.0, variance*.75 + sat*.35);
    }

    /** Compact grayscale+HSV feature; resilient to small motion/scale changes. */
    private String feature(Bitmap b,Rect r){
        StringBuilder out=new StringBuilder(160);
        final int N=8; float[] hsv=new float[3];
        double mean=0; double[] gray=new double[N*N];
        for(int y=0;y<N;y++) for(int x=0;x<N;x++){
            int sx=r.left+(x*r.width())/N, sy=r.top+(y*r.height())/N;
            int c=b.getPixel(Math.max(0,Math.min(b.getWidth()-1,sx)),Math.max(0,Math.min(b.getHeight()-1,sy)));
            double v=.299*Color.red(c)+.587*Color.green(c)+.114*Color.blue(c);
            gray[y*N+x]=v; mean+=v;
        }
        mean/=gray.length;
        for(double v:gray) out.append(v>=mean?'1':'0');
        // 3x3 coarse color means help distinguish similarly shaped animal icons.
        for(int by=0;by<3;by++) for(int bx=0;bx<3;bx++){
            double ss=0,vv=0,hh=0;int n=0;
            int x0=r.left+(r.width()*bx)/3,x1=r.left+(r.width()*(bx+1))/3;
            int y0=r.top+(r.height()*by)/3,y1=r.top+(r.height()*(by+1))/3;
            for(int y=y0;y<y1;y+=Math.max(2,(y1-y0)/4)) for(int x=x0;x<x1;x+=Math.max(2,(x1-x0)/4)){
                Color.colorToHSV(b.getPixel(Math.min(b.getWidth()-1,x),Math.min(b.getHeight()-1,y)),hsv);
                hh+=hsv[0]/360f; ss+=hsv[1]; vv+=hsv[2]; n++;
            }
            if(n>0) out.append('|').append(Math.round(hh/n*15)).append(',').append(Math.round(ss/n*15)).append(',').append(Math.round(vv/n*15));
        }
        return out.toString();
    }

    private String labelFor(String feature,long hash){
        // First try the bundled semantic catalog. This is used only for icons
        // that actually match one of its supplied visual references.
        TemplateRepository.Match m=catalog.best(hash);
        if(m!=null && m.label!=null && !"غير معروف".equals(m.label) && m.similarity>=.80f) return m.label;

        Prototype best=null; double bestD=Double.MAX_VALUE;
        for(Prototype p:prototypes){
            double d=featureDistance(feature,p.feature);
            if(d<bestD){bestD=d;best=p;}
        }
        if(best!=null && bestD<=.20) return best.label;

        String label="رمز "+(prototypes.size()+1);
        prototypes.add(new Prototype(label,feature,hash));
        if(prototypes.size()>80) prototypes.remove(0);
        save();
        return label;
    }

    private double featureDistance(String a,String b){
        if(a==null||b==null||a.isEmpty()||b.isEmpty()) return 1;
        int n=Math.min(a.length(),b.length());
        if(n==0)return 1;
        int diff=0; for(int i=0;i<n;i++) if(a.charAt(i)!=b.charAt(i)) diff++;
        return diff/(double)n;
    }

    private List<Suggestion> aggregateSuggestions(String[] cells,HistoryDb db){
        // Aggregate evidence from every currently visible symbol, so the panel
        // produces a ranked list rather than only the first changed cell.
        HashMap<String,int[]> agg=new HashMap<>();
        for(String current:cells){
            if(current==null||current.isEmpty())continue;
            for(String row:db.rankedGameTransitions(current,5)){
                String[] p=row.split("\\|",-1); if(p.length<3)continue;
                try{
                    String[] ht=p[2].split("/",2); int hits=Integer.parseInt(ht[0]); int total=Integer.parseInt(ht[1]);
                    int[] a=agg.get(p[0]); if(a==null){a=new int[]{0,0};agg.put(p[0],a);} a[0]+=hits;a[1]+=total;
                }catch(Exception ignored){}
            }
        }
        ArrayList<Suggestion> out=new ArrayList<>();
        for(Map.Entry<String,int[]> e:agg.entrySet()){
            int hits=e.getValue()[0],total=e.getValue()[1];
            if(total<=0||hits<=0)continue;
            out.add(new Suggestion(e.getKey(),Math.round(100f*hits/total),hits,total));
        }
        out.sort((a,b)->{int d=Integer.compare(b.confidencePct,a.confidencePct);return d!=0?d:Integer.compare(b.hits,a.hits);});
        if(out.size()>5)return new ArrayList<>(out.subList(0,5));
        return out;
    }

    private String firstUseful(String[] a){for(String s:a)if(s!=null&&!s.isEmpty())return s;return "";}
    private String sequenceText(String[] cells,int cols){
        StringBuilder b=new StringBuilder();
        for(int r=0;r<ROWS;r++){
            if(r>0)b.append(" / ");
            for(int c=0;c<cols;c++){if(c>0)b.append(" → ");b.append(cells[r*cols+c].isEmpty()?"؟":cells[r*cols+c]);}
        }
        return b.toString();
    }

    private void load(){
        String raw=prefs.getString("prototypes_v2",""); if(raw.isEmpty())return;
        for(String line:raw.split("\\n")){
            String[] p=line.split("\\|",3); if(p.length<2)continue;
            try{long h=p.length>2?Long.parseUnsignedLong(p[2]):0;prototypes.add(new Prototype(p[0],p[1],h));}catch(Exception ignored){}
        }
    }
    private void save(){
        StringBuilder s=new StringBuilder();int n=0;
        for(Prototype p:prototypes){if(n++>=80)break;s.append(p.label).append('|').append(p.feature).append('|').append(Long.toUnsignedString(p.hash)).append('\n');}
        prefs.edit().putString("prototypes_v2",s.toString()).apply();
    }
}
