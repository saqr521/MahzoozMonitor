package com.mahzooz.monitor;

import java.util.*;

/**
 * Pre-play hit-count planner. It recommends only hit counts observed in prior
 * icon interaction sessions. It never invents x9/x49 or controls the game.
 */
public final class HitPlanEngine {
    public static final class Plan {
        public final String label; public final int hits; public final int observations; public final int confidencePct;
        Plan(String l,int h,int o,int c){label=l;hits=h;observations=o;confidencePct=c;}
        public String line(){return "🎯 "+label+" → اضرب ×"+hits+" | "+confidencePct+"% | "+observations+" مشاهدة";}
    }
    public Plan best(String label, HistoryDb db){
        if(label==null||label.isEmpty()||db==null) return null;
        String raw=db.bestHitPlan(label);
        if(raw.isEmpty()) return null;
        String[] p=raw.split("\\|");
        try { int hits=Integer.parseInt(p[0].substring(1)); int obs=Integer.parseInt(p[1].replaceAll("[^0-9]","")); int conf=Integer.parseInt(p[2].replaceAll("[^0-9]","")); return new Plan(label,hits,obs,conf); } catch(Exception e){ return null; }
    }
}
