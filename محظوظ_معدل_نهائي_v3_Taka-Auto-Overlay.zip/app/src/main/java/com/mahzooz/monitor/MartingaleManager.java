package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/**
 * Local Martingale calculator. It never places a bet or controls the game.
 * It only maintains the configured virtual/decision amount after an explicitly
 * detected round outcome.
 */
public final class MartingaleManager {
    private static final String PREF = "martingale";
    private static final int DEFAULT_BASE = 5;
    private static final int DEFAULT_MULTIPLIER = 2;
    private static final int DEFAULT_MAX = 1000;
    private final SharedPreferences sp;
    private long lastOutcomeHash = Long.MIN_VALUE;

    public MartingaleManager(Context c) { sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    public boolean enabled(){ return sp.getBoolean("enabled", true); }
    public int base(){ return Math.max(1, sp.getInt("base", DEFAULT_BASE)); }
    public int multiplier(){ return Math.max(2, sp.getInt("multiplier", DEFAULT_MULTIPLIER)); }
    public int max(){ return Math.max(base(), sp.getInt("max", DEFAULT_MAX)); }
    public int currentBet(){ return Math.max(base(), sp.getInt("current", base())); }
    public int step(){ return Math.max(0, sp.getInt("step", 0)); }

    public void setEnabled(boolean v){ sp.edit().putBoolean("enabled", v).apply(); }
    public void reset(){ sp.edit().putInt("current", base()).putInt("step",0).apply(); }

    public void recordWin(){
        if(!enabled()) return;
        sp.edit().putInt("current", base()).putInt("step",0).apply();
    }
    public void recordLoss(){
        if(!enabled()) return;
        long next=(long)currentBet()*multiplier();
        if(next>max()) { next=base(); }
        sp.edit().putInt("current", (int)next).putInt("step", step()+1).apply();
    }

    /** Detects explicit visible outcome words only; it does not guess from a screen change. */
    public void observeOcrOutcome(String ocr){
        if(!enabled() || ocr==null || ocr.trim().isEmpty()) return;
        String t=ocr.toLowerCase(Locale.US);
        boolean win = containsAny(t, "wins", "winner", "win", "فاز", "الفائز", "مكسب", "نجاح");
        boolean loss = containsAny(t, "loss", "lose", "lost", "خسر", "خسارة", "خساره");
        if(win==loss) return;
        long h=t.hashCode();
        if(h==lastOutcomeHash) return;
        lastOutcomeHash=h;
        if(win) recordWin(); else recordLoss();
    }
    private boolean containsAny(String t,String... xs){ for(String x:xs) if(t.contains(x)) return true; return false; }
}
