package com.mahzooz.monitor;

/** Memory-safe diagnostics for this app's own runtime only. */
public final class SelfMemoryStateMonitor {
    public String snapshot(){
        Runtime r=Runtime.getRuntime();
        return "SELF_MEMORY | used="+(r.totalMemory()-r.freeMemory())+" | total="+r.totalMemory()+" | max="+r.maxMemory();
    }
    public boolean readsGameProcessMemory(){return false;}
}
