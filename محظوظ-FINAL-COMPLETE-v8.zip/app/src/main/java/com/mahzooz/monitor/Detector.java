package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class Detector {
    public static class Marker { public Rect rect; public float score; public String type; public Marker(Rect r,float s,String t){rect=r;score=s;type=t;} }
    public static class Tile { public Rect rect; public long hash; public String label; public float similarity; public Tile(Rect r,long h,String l,float s){rect=r;hash=h;label=l;similarity=s;} }

    private Detector() {}

    public static List<Marker> findMarkers(Bitmap src, boolean green) {
        int w = src.getWidth(), h = src.getHeight();
        boolean[][] seen = new boolean[h][w];
        ArrayList<Marker> out = new ArrayList<>();
        float[] hsv = new float[3];

        // The small green/yellow badge is the reliable anchor for an inventory tile.
        // Scan the whole lower inventory panel, including rows that become visible
        // after a scroll. Small connected components are used so the large artwork
        // in the game header is not mistaken for a badge.
        int startY = Math.max(0, (int)(h * 0.45f));
        for (int y = startY; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (seen[y][x]) continue;
                Color.colorToHSV(src.getPixel(x, y), hsv);
                if (!matches(hsv, green)) continue;

                int minX=x, maxX=x, minY=y, maxY=y, count=0;
                ArrayDeque<int[]> q = new ArrayDeque<>();
                q.add(new int[]{x,y});
                seen[y][x] = true;
                while (!q.isEmpty()) {
                    int[] pt=q.removeFirst(); int px=pt[0], py=pt[1]; count++;
                    minX=Math.min(minX,px); maxX=Math.max(maxX,px);
                    minY=Math.min(minY,py); maxY=Math.max(maxY,py);
                    if (count > 2500) break;
                    int[][] ns={{px+1,py},{px-1,py},{px,py+1},{px,py-1}};
                    for (int[] n:ns) {
                        int nx=n[0], ny=n[1];
                        if(nx<0||ny<startY||nx>=w||ny>=h||seen[ny][nx]) continue;
                        Color.colorToHSV(src.getPixel(nx,ny),hsv);
                        if(matches(hsv,green)){ seen[ny][nx]=true; q.add(n); }
                    }
                }
                int bw=maxX-minX+1, bh=maxY-minY+1;
                // Badge on the supplied game screens is a small, nearly square chip.
                if(count >= 8 && count <= 220 && bw >= 3 && bh >= 3 &&
                        bw <= 24 && bh <= 24 && ((double)bw/bh) >= .55 && ((double)bw/bh) <= 1.8) {
                    float density=(float)count/(bw*bh);
                    if(density > .08f)
                        out.add(new Marker(new Rect(minX,minY,maxX+1,maxY+1),Math.min(1f,density*1.5f),green?"GREEN":"YELLOW"));
                }
            }
        }
        // In this game the inventory uses four columns. A badge sits close to the
        // upper-right edge of its column; this removes yellow/green pixels belonging
        // to the icon artwork itself.
        final float cell = w / 4f;
        ArrayList<Marker> aligned = new ArrayList<>();
        for (Marker m : out) {
            float cx=(m.rect.left+m.rect.right)/2f;
            float rem=cx % cell;
            if (rem >= cell*0.78f || rem <= cell*0.04f) aligned.add(m);
        }
        dedupe(aligned);
        return aligned;
    }

    private static boolean matches(float[] hsv, boolean green){
        float hue=hsv[0], sat=hsv[1], val=hsv[2];
        if(sat<0.45f || val<0.45f) return false;
        // Green badge and yellow badge ranges observed in the supplied gameplay frames.
        if(green) return hue>=80 && hue<=165;
        return hue>=35 && hue<=65;
    }

    private static void dedupe(List<Marker> list){
        Collections.sort(list,(a,b)->{
            int d=Integer.compare(a.rect.top,b.rect.top);
            return d!=0?d:Integer.compare(a.rect.left,b.rect.left);
        });
        ArrayList<Marker> keep=new ArrayList<>();
        for(Marker m:list){
            boolean dup=false;
            for(Marker k:keep){
                if(Rect.intersects(m.rect,k.rect) || centerDistance(m.rect,k.rect)<7){dup=true;break;}
            }
            if(!dup) keep.add(m);
        }
        list.clear(); list.addAll(keep);
    }

    private static double centerDistance(Rect a,Rect b){double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0,bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;return Math.hypot(ax-bx,ay-by);}

    /** Finds a likely grid of square/near-square tiles in the lower portion of the screen. */
    public static List<Tile> findTiles(Bitmap src, TemplateRepository repo){
        int w=src.getWidth(),h=src.getHeight();
        ArrayList<Tile> out=new ArrayList<>();
        int start=(int)(h*0.52f), cell=Math.max(48,w/6), gap=Math.max(3,cell/12);
        for(int y=start;y<h-cell/3;y+=cell){
            for(int x=0;x+cell<=w;x+=cell){
                Rect r=new Rect(x+gap,y+gap,x+cell-gap,y+cell-gap);
                if(r.width()<32||r.height()<32) continue;
                long hash=phash(src,r);
                TemplateRepository.Match m=repo.best(hash);
                out.add(new Tile(r,hash,m.label,m.similarity));
            }
        }
        return out;
    }


    /** Matches the icon directly below a green/yellow marker. The game places its
     * classification badge at the upper-right of each gift tile. */
    public static Tile itemForMarker(Bitmap src, Marker marker, TemplateRepository repo) {
        // In the game video the small badge is at the upper-right of the icon.
        // Crop the icon area to the left/below it, while avoiding the price text.
        int cx=(marker.rect.left+marker.rect.right)/2;
        int cy=(marker.rect.top+marker.rect.bottom)/2;
        int cell=Math.max(48,src.getWidth()/4);
        int col=Math.max(0,Math.min(3,cx/cell));
        int centerX=col*cell+cell/2;
        int centerY=cy+Math.max(18,cell/5);
        int size=Math.max(64,Math.min(96,cell));
        int left=Math.max(0,centerX-size/2);
        int top=Math.max(0,centerY-size/2);
        int right=Math.min(src.getWidth(),left+size);
        int bottom=Math.min(src.getHeight(),top+size);
        if(right-left<48 || bottom-top<48) return new Tile(new Rect(),0,"غير معروف",0);
        Rect r=new Rect(left,top,right,bottom);
        long hash=phash(src,r);
        TemplateRepository.Match m=repo.best(hash);
        return new Tile(r,hash,m.label,m.similarity);
    }

    public static long phash(Bitmap src, Rect r){
        final int N=8; double[] gray=new double[N*N];
        for(int yy=0;yy<N;yy++) for(int xx=0;xx<N;xx++){
            int sx=r.left+(xx*r.width())/N, sy=r.top+(yy*r.height())/N;
            int c=src.getPixel(Math.max(0,Math.min(src.getWidth()-1,sx)),Math.max(0,Math.min(src.getHeight()-1,sy)));
            gray[yy*N+xx]=0.299*Color.red(c)+0.587*Color.green(c)+0.114*Color.blue(c);
        }
        double sum=0; for(double v:gray)sum+=v; double avg=sum/gray.length; long hash=0;
        for(int i=0;i<gray.length;i++) if(gray[i]>=avg) hash|=(1L<<i);
        return hash;
    }
}
