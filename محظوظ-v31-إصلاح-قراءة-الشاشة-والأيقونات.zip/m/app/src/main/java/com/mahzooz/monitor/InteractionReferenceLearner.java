package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.*;

/**
 * Read-only learner for the user's one-icon-at-a-time test videos and live play.
 * It recognizes the visible selection highlight, then records the screen state
 * before/after the room transition. It never sends a tap or any other input.
 */
public final class InteractionReferenceLearner {
    public static final class Observation {
        public final String selectedLabel;
        public final long selectedHash;
        public final String beforeSignature;
        public final String afterSignature;
        public final int row;
        public final int column;
        public final float confidence;
        Observation(String l,long h,String b,String a,int r,int c,float f){
            selectedLabel=l;selectedHash=h;beforeSignature=b;afterSignature=a;
            row=r;column=c;confidence=f;
        }
    }

    private String lastInventorySignature="";
    private String pendingLabel="";
    private long pendingHash;
    private String pendingBefore="";
    private int pendingRow=-1,pendingColumn=-1;
    private boolean roomSeen;
    private long lastSelectionAt;
    private final ArrayDeque<Observation> recent=new ArrayDeque<>();

    public synchronized Observation observe(Bitmap bitmap, List<Detector.Tile> tiles,
                                             boolean inventoryVisible, long nowMs) {
        if (!inventoryVisible || bitmap==null || tiles==null || tiles.isEmpty()) {
            if (!inventoryVisible && !pendingLabel.isEmpty()) roomSeen=true;
            return null;
        }

        String current=signature(tiles);
        Detector.Tile selected=detectSelection(bitmap,tiles);
        if (selected!=null && !"غير معروف".equals(selected.label)) {
            GridMappingAnalysis.Cell cell=cellFor(tiles,selected);
            // Do not re-arm the same selection on every 160 ms frame.
            if (!selected.label.equals(pendingLabel) || nowMs-lastSelectionAt>1400) {
                pendingLabel=selected.label;
                pendingHash=selected.hash;
                pendingBefore=current;
                pendingRow=cell==null?-1:cell.row;
                pendingColumn=cell==null?-1:cell.column;
                lastSelectionAt=nowMs;
            }
        }

        Observation completed=null;
        if (roomSeen && !pendingLabel.isEmpty()) {
            // Returning to the inventory closes the interaction test window.
            completed=new Observation(pendingLabel,pendingHash,pendingBefore,current,
                    pendingRow,pendingColumn,.90f);
            remember(completed);
            pendingLabel=""; pendingHash=0; pendingBefore=""; pendingRow=pendingColumn=-1;
            roomSeen=false;
        }
        lastInventorySignature=current;
        return completed;
    }

    /**
     * Selected cards in the supplied video use a distinct card background
     * (approximately RGB 46/43/64 versus the panel's 36/33/54). We use relative
     * contrast against all visible cards, not a fixed color, so theme changes do
     * not create a hard dependency.
     */
    private static Detector.Tile detectSelection(Bitmap b,List<Detector.Tile> tiles){
        if(tiles.size()<2) return null;
        double[] means=new double[tiles.size()];
        for(int i=0;i<tiles.size();i++) means[i]=cardBackgroundMean(b,tiles.get(i).rect);
        double baseline=median(means);
        Detector.Tile best=null; double bestDelta=0;
        for(int i=0;i<tiles.size();i++){
            double delta=Math.abs(means[i]-baseline);
            if(delta>bestDelta && delta>=4.5){bestDelta=delta;best=tiles.get(i);}
        }
        return best;
    }

    private static double cardBackgroundMean(Bitmap b,Rect icon){
        int cx=icon.centerX(),cy=icon.centerY();
        int[][] pts={{-78,-78},{78,-78},{-78,78},{78,78},{-82,-45},{82,-45},{-82,45},{82,45}};
        double sum=0; int n=0;
        for(int[] p:pts){int x=Math.max(0,Math.min(b.getWidth()-1,cx+p[0]));int y=Math.max(0,Math.min(b.getHeight()-1,cy+p[1]));
            int c=b.getPixel(x,y);sum+=(Color.red(c)+Color.green(c)+Color.blue(c))/3.0;n++;}
        return n==0?0:sum/n;
    }
    private static double median(double[] a){double[] x=a.clone();Arrays.sort(x);return x[x.length/2];}

    private static GridMappingAnalysis.Cell cellFor(List<Detector.Tile> tiles,Detector.Tile selected){
        List<GridMappingAnalysis.Cell> cells=GridMappingAnalysis.map(tiles);
        for(GridMappingAnalysis.Cell c:cells)
            if(Math.abs(c.bounds.centerX()-selected.rect.centerX())<8 && Math.abs(c.bounds.centerY()-selected.rect.centerY())<8) return c;
        return null;
    }
    private void remember(Observation o){recent.addLast(o);while(recent.size()>64)recent.removeFirst();}
    public synchronized List<Observation> recent(){return new ArrayList<>(recent);}
    public synchronized String status(){return "اختبارات الأيقونات="+recent.size()+" | المحددة="+(pendingLabel.isEmpty()?"لا يوجد":pendingLabel);}
    private static String signature(List<Detector.Tile> tiles){
        ArrayList<String> a=new ArrayList<>();
        for(Detector.Tile t:tiles) if(t!=null&&t.label!=null&&!t.label.isEmpty()&&!"غير معروف".equals(t.label)) a.add(t.label);
        Collections.sort(a);StringBuilder s=new StringBuilder();String last="";
        for(String x:a)if(!x.equals(last)){s.append(x).append(';');last=x;}return s.toString();
    }
}
