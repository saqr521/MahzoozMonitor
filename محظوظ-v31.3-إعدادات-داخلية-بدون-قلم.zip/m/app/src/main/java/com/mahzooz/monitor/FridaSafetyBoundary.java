package com.mahzooz.monitor;

/** Explicit safety boundary: no Frida attachment/injection into another app. */
public final class FridaSafetyBoundary {
    public boolean supportedForGameProcessHooking(){return false;}
    public boolean supportsOwnAppDiagnosticsOnly(){return true;}
}
