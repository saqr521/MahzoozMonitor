package com.mahzooz.monitor;

import android.graphics.Bitmap;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.video.Video;

/**
 * Local OpenCV adapter. It analyzes the captured bitmap only; it never opens a
 * socket, another process, or a game's private memory.
 */
public final class OpenCvVisionEngine {
    private boolean initialized;
    private Mat previousGray;

    public OpenCvVisionEngine() {
        try { initialized = OpenCVLoader.initLocal(); }
        catch (Throwable ignored) { initialized = false; }
    }

    public boolean isAvailable() { return initialized; }

    /** Returns average optical-flow magnitude between consecutive screenshots. */
    public synchronized float opticalFlowMagnitude(Bitmap bitmap) {
        if (!initialized || bitmap == null || bitmap.isRecycled()) return 0f;
        Mat rgba = new Mat();
        Mat gray = new Mat();
        Mat small = new Mat();
        try {
            Utils.bitmapToMat(bitmap, rgba);
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
            Imgproc.resize(gray, small, new Size(320, 0), 0, 0, Imgproc.INTER_AREA);

            if (previousGray == null) {
                previousGray = small.clone();
                return 0f;
            }

            Mat flow = new Mat();
            try {
                Video.calcOpticalFlowFarneback(previousGray, small, flow,
                        0.5, 3, 15, 3, 5, 1.2, 0);
                double total = 0.0;
                int count = flow.rows() * flow.cols();
                float[] xy = new float[2];
                for (int y = 0; y < flow.rows(); y++) {
                    for (int x = 0; x < flow.cols(); x++) {
                        flow.get(y, x, xy);
                        total += Math.sqrt(xy[0] * xy[0] + xy[1] * xy[1]);
                    }
                }
                previousGray.release();
                previousGray = small.clone();
                return count == 0 ? 0f : (float)(total / count);
            } finally { flow.release(); }
        } catch (Throwable ignored) {
            return 0f;
        } finally {
            rgba.release(); gray.release(); small.release();
        }
    }

    public synchronized void reset() {
        if (previousGray != null) { previousGray.release(); previousGray = null; }
    }
}
