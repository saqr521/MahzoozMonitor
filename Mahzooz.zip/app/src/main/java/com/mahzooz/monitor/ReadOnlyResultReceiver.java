package com.mahzooz.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Explicit, signature-protected bridge for app-owned result delivery. */
public final class ReadOnlyResultReceiver extends BroadcastReceiver {
    public static final String ACTION = "com.mahzooz.monitor.action.RESULT_DATA";
    public static final String EXTRA_PAYLOAD = "payload";
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION.equals(intent.getAction())) return;
        String payload = intent.getStringExtra(EXTRA_PAYLOAD);
        if (payload == null || payload.trim().isEmpty()) return;
        Intent service = new Intent(context, CaptureService.class);
        service.putExtra("readonly_result_payload", payload);
        try { context.startService(service); } catch (Throwable ignored) { }
    }
}
