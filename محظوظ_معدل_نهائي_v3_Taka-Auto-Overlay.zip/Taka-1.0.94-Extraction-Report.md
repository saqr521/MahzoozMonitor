# Taka 1.0.94 — extraction notes used by محظوظ

The supplied `Taka.zip` contains two APKs: the main `Taka-1.0.94.apk` and the ARM64 configuration/split APK.

## Game-related evidence actually present

- `gameId`, `getResult`, and `resultKey` appear in the main APK string data.
- The APK contains a dedicated game UI layer: `game_dialog_layout`, `lwchat_create_choose_game_dialog`, `lwchat_explore_game_item`, start/end-game layouts, game-share layouts, game-PK layouts, and game-coin exchange layouts.
- The APK contains a concrete Lucky Wheel feature: `lucky_wheel_start_game`, `lucky_wheel_running`, `lucky_wheel_end_game`, `lucky_wheel_join`, `lucky_wheel_join_coins`, `lucky_wheel_wait`, `lucky_wheel_view`, `lwchat_iv_room_lucky_wheel`, `lwchat_lucky_wheel_1`, `lwchat_lucky_wheel_2`, and `ic_room_spin`.
- Result-related UI resources include `lwchat_calculate_result_item_layout`, `lwchat_dialog_calculate_result_layout`, `tv_result_item_name`, and `coins_result_item_name`.
- The ARM64 split is dominated by native/live-room libraries. It does not expose additional Java game rules that can safely be treated as a public client-side prediction algorithm.

## What was deliberately NOT imported

- Chat, calls, microphone/camera features, advertising, payment internals, and live-room transport code are not used as game prediction inputs.
- No private API credentials, TLS bypass, memory hooks, process injection, or network interception was added.
- Resource names are fingerprints for recognition only; they are not treated as proof of hidden outcomes.

## How محظوظ uses this

The project now has a verified Taka reference catalog plus a local game-signal layer. The live monitor still relies on screen/OCR/vision observations and persistent local history. It can rank the strongest *observed* game signal and flag deterioration, but it does not claim that a 95% signal is a guaranteed win probability.
