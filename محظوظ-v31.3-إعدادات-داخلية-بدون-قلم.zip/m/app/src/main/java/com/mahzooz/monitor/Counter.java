package com.mahzooz.monitor;

/** Small thread-safe counter used by the local analytics layer. */
public final class Counter {
    private long value;
    public synchronized long increment(){ return ++value; }
    public synchronized long add(long delta){ value += delta; return value; }
    public synchronized long get(){ return value; }
    public synchronized void reset(){ value = 0; }
}
