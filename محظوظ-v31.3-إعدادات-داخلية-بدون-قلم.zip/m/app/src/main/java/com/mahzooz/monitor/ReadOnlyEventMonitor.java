package com.mahzooz.monitor;

import java.util.*;

/**
 * Read-only event layer. It derives events only from visible/accessibility/exported
 * observations already available to the monitor. It never sends input, changes the
 * game, reads private process memory, or intercepts/decrypts TLS traffic.
 */
public final class ReadOnlyEventMonitor {
    public enum Type { OPEN, CLOSE, STORAGE_APPEARED, STORAGE_DISAPPEARED, SCREEN_OPEN, SCREEN_LOCKED, SCREEN_UNKNOWN }
    public static final class Event {
        public final long timestampMs;
        public final Type type;
        public final String name;
        public final float confidence;
        Event(long ts, Type t, String n, float c) { timestampMs=ts; type=t; name=n==null?"":n; confidence=c; }
        @Override public String toString() { return type+" | "+name+" | "+timestampMs+" | "+Math.round(confidence*100)+"%"; }
    }

    private final HistoryDb db;
    private Set<String> previousGreen = new LinkedHashSet<>();
    private Set<String> previousYellow = new LinkedHashSet<>();
    private ScreenStateDetector.LockState previousScreen = ScreenStateDetector.LockState.UNKNOWN;

    public ReadOnlyEventMonitor(HistoryDb database) { db=database; }

    public synchronized List<Event> observe(List<Detector.Tile> green, List<Detector.Tile> yellow,
                                             ScreenStateDetector.State screen, long timestampMs) {
        Set<String> g=labels(green), y=labels(yellow);
        ArrayList<Event> out=new ArrayList<>();
        // First observation establishes the baseline; do not fabricate OPEN/CLOSE transitions.
        if (!previousGreen.isEmpty() || !previousYellow.isEmpty()) {
            for(String x: difference(g, previousGreen)) out.add(add(timestampMs,Type.OPEN,x,confidence(screen)));
            for(String x: difference(previousGreen, g)) out.add(add(timestampMs,Type.CLOSE,x,confidence(screen)));
            for(String x: difference(y, previousYellow)) out.add(add(timestampMs,Type.STORAGE_APPEARED,x,confidence(screen)));
            for(String x: difference(previousYellow, y)) out.add(add(timestampMs,Type.STORAGE_DISAPPEARED,x,confidence(screen)));
        }
        if (screen != null && screen.lockState != previousScreen) {
            Type t = screen.lockState == ScreenStateDetector.LockState.OPEN ? Type.SCREEN_OPEN :
                    screen.lockState == ScreenStateDetector.LockState.LOCKED ? Type.SCREEN_LOCKED : Type.SCREEN_UNKNOWN;
            out.add(add(timestampMs,t,screen.scene,screen.confidence));
            previousScreen=screen.lockState;
        }
        previousGreen=g; previousYellow=y;
        return out;
    }

    private Event add(long ts, Type type, String name, float c) {
        Event e=new Event(ts,type,name,c);
        if(db!=null) db.recordReadOnlyEvent(ts,type.name(),name,c);
        AlgorithmTrace.recordReadOnlyEvent(e);
        return e;
    }
    private static float confidence(ScreenStateDetector.State s){return s==null?0.35f:s.confidence;}
    private static Set<String> labels(List<Detector.Tile> a){
        Set<String> out=new LinkedHashSet<>();
        if(a!=null) for(Detector.Tile t:a) if(t!=null && t.label!=null && !t.label.isEmpty() && !"غير معروف".equals(t.label)) out.add(t.label);
        return out;
    }
    private static Set<String> difference(Set<String> a, Set<String> b){Set<String> r=new LinkedHashSet<>(a);r.removeAll(b);return r;}
}
