package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.concurrent.TimeUnit;

/** Local, read-only OCR. No screenshots are written to storage. */
public final class OcrEngine {
    private final TextRecognizer recognizer;
    private final OcrFilter filter = new OcrFilter(1200L);
    private final StrikeDataFilter strikeFilter = new StrikeDataFilter(7000L);
    private volatile String lastAcceptedText = "";

    public OcrEngine(Context context) {
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    /**
     * Runs at most once per 1.2s and only exposes a changed normalized result.
     * Empty/failed OCR never becomes an observation.
     */
    public String readIfDue(Bitmap bitmap, long now) {
        if (bitmap == null || bitmap.isRecycled() || !filter.allow(now)) return "";
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            Text text = Tasks.await(recognizer.process(image), 900L, TimeUnit.MILLISECONDS);
            String value = OcrSanitizer.clean(OcrFilter.normalize(text == null ? "" : text.getText()));
            if (filter.accept(value, now)) {
                // The OCR filter removes identical text. The strike filter goes
                // one level deeper and removes the same gift + multiplier while
                // the game is still displaying the same result/animation.
                String strikeGift = value;
                int multiplier = StrikeDataFilter.extractMultiplier(value);
                if (strikeFilter.isNewUniqueStrike(strikeGift, multiplier)) {
                    lastAcceptedText = value;
                    return value;
                }
            }
        } catch (Throwable ignored) {
            // OCR is supplemental; a timeout/failure must never stop visual analysis.
        }
        return "";
    }

    public String lastAcceptedText() { return lastAcceptedText; }

    public void close() {
        try { recognizer.close(); } catch (Throwable ignored) {}
    }
}
