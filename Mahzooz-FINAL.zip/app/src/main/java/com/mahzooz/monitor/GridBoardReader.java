package com.mahzooz.monitor;

import android.graphics.Bitmap;
import android.graphics.Rect;
import java.util.*;

/**
 * Finds the visible Mahzooz item cards without relying on the green/yellow
 * corner badge. It tries the known card layouts against the user-selected
 * region and, when the full screen is supplied, scans the lower part of the
 * screen for a matching board rectangle.
 */
public final class GridBoardReader {
    public static final class Cell {
        public final int row, column;
        public final String label;
        public final float confidence;
        public final Rect bounds;
        Cell(int r,int c,String l,float f,Rect b){row=r;column=c;label=l;confidence=f;bounds=b;}
    }

    public static final class Result {
        public final boolean detected;
        public final int rows, columns;
        public final float confidence;
        public final Rect board;
        public final List<Cell> cells;
        Result(boolean d,int r,int c,float f,Rect b,List<Cell> x){
            detected=d;rows=r;columns=c;confidence=f;board=b;cells=x;
        }
        public List<String> labels(){
            ArrayList<String> out=new ArrayList<>();
            for(Cell c:cells) out.add(c.label==null?"":c.label);
            return out;
        }
        public String signature(){
            return String.join(";",labels());
        }
    }

    private static final int[][] LAYOUTS={{4,3},{5,3},{4,4},{6,5},{3,3},{5,4}};
    private final TemplateRepository templates;

    public GridBoardReader(TemplateRepository t){templates=t;}

    public Result read(Bitmap src){
        if(src==null||src.isRecycled()||src.getWidth()<180||src.getHeight()<150)
            return empty();

        ArrayList<Rect> candidates=new ArrayList<>();
        int w=src.getWidth(),h=src.getHeight();

        // First try the whole supplied region. This is the expected path when
        // the user draws the rectangle around the inventory.
        candidates.add(new Rect(0,0,w,h));

        // If the user did not select a region, the board is normally below the
        // room/game header. Scan several large lower-screen rectangles.
        for(int[] layout:LAYOUTS){
            float ratio=(float)layout[0]/layout[1];
            int bw=Math.min(w,(int)(h*ratio));
            int bh=Math.min(h,(int)(w/ratio));
            if(bw<180||bh<120) continue;
            int yMin=(int)(h*.38f);
            int yMax=Math.max(yMin+1,h-bh/3);
            int[] xs={0,Math.max(0,(w-bw)/2),Math.max(0,w-bw)};
            int[] ys={yMin,Math.max(yMin,(h-bh)/2),Math.max(yMin,yMax-bh/2)};
            for(int x:xs) for(int y:ys){
                if(x+bw<=w&&y+bh<=h) candidates.add(new Rect(x,y,x+bw,y+bh));
            }
        }

        Result best=empty();
        for(Rect r:candidates){
            for(int[] layout:LAYOUTS){
                Result x=readCandidate(src,r,layout[1],layout[0]);
                if(score(x)>score(best)) best=x;
            }
        }
        return best;
    }

    private Result readCandidate(Bitmap src,Rect board,int rows,int cols){
        int cw=board.width()/cols, ch=board.height()/rows;
        if(cw<38||ch<45) return empty();

        ArrayList<Cell> cells=new ArrayList<>();
        float sum=0; int known=0;
        for(int row=0;row<rows;row++){
            for(int col=0;col<cols;col++){
                int l=board.left+col*cw, t=board.top+row*ch;
                int rr=board.left+(col+1)*cw, bb=board.top+(row+1)*ch;
                // Ignore a small frame around each card.
                int mx=Math.max(3,Math.round(cw*.055f));
                int my=Math.max(3,Math.round(ch*.055f));
                Rect crop=new Rect(l+mx,t+my,Math.max(l+mx+1,rr-mx),Math.max(t+my+1,bb-my));
                Bitmap tile=null;
                try{
                    tile=Bitmap.createBitmap(src,crop.left,crop.top,crop.width(),crop.height());
                    TemplateRepository.Match m=templates.best(tile);
                    String label=m.label;
                    if("غير معروف".equals(label)) label="";
                    cells.add(new Cell(row,col,label,m.similarity,new Rect(crop)));
                    if(!label.isEmpty()){known++;sum+=m.similarity;}
                }catch(Throwable ignored){
                    cells.add(new Cell(row,col,"",0,new Rect(crop)));
                }finally{
                    if(tile!=null&&!tile.isRecycled()) tile.recycle();
                }
            }
        }

        int total=rows*cols;
        float avg=known==0?0:sum/known;
        // A board must contain several recognizable cards. This prevents random
        // dark areas of the screen from being reported as a Mahzooz grid.
        boolean detected=known>=Math.max(4,(int)Math.ceil(total*.28f)) && avg>=.56f;
        if(!detected) return new Result(false,rows,cols,avg,new Rect(board),cells);
        return new Result(true,rows,cols,avg,new Rect(board),cells);
    }

    private float score(Result r){
        if(r==null||!r.detected)return 0;
        int known=0;
        for(Cell c:r.cells)if(c.label!=null&&!c.label.isEmpty())known++;
        return r.confidence + known*.01f;
    }

    private Result empty(){
        return new Result(false,0,0,0,new Rect(),Collections.emptyList());
    }
}
