package com.mahzooz.monitor;

import java.util.*;

/**
 * Evidence-only learner. It models repeated screen-observed state transitions;
 * it never reads or modifies the game's private files/process and never invents a result.
 */
public final class SystemLearner {
    private final HistoryDb db;
    private String lastState="";
    private String currentItem="";
    private final LinkedHashSet<String> active=new LinkedHashSet<>();

    public SystemLearner(HistoryDb db){this.db=db;}

    public synchronized Snapshot update(List<Detector.Tile> visibleGreen, String observedRecommendation){
        LinkedHashSet<String> now=new LinkedHashSet<>();
        if(visibleGreen!=null) for(Detector.Tile t:visibleGreen)
            if(t!=null && t.label!=null && !t.label.isEmpty() && !"غير معروف".equals(t.label)) now.add(t.label);
        String state=join(now);

        if(!state.isEmpty() && !state.equals(lastState)){
            // Analyzer.updateAndRecommend() is the single transition recorder.
            // Keeping this learner read-only prevents double-counting every event.
            lastState=state;
        }
        active.clear(); active.addAll(now);
        if(observedRecommendation!=null && !observedRecommendation.isEmpty()) currentItem=extractItem(observedRecommendation);

        return new Snapshot(new ArrayList<>(active), rank(now), currentItem);
    }

    private List<Rank> rank(Set<String> visible){
        ArrayList<Rank> out=new ArrayList<>();
        String state=join(visible);
        if(state.isEmpty()) return out;
        for(String row:db.rankedTransitions(state,Math.max(visible.size(),8))){
            String[] p=row.split("\\|",-1);
            if(p.length<3) continue;
            String item=p[0];
            if(!visible.contains(item)) continue;
            String[] ht=p[2].split("/",2);
            if(ht.length<2) continue;
            try {
                out.add(new Rank(item,Integer.parseInt(p[1]),Integer.parseInt(ht[0]),Integer.parseInt(ht[1])));
            } catch(NumberFormatException ignored) {}
        }
        // Anything without evidence is deliberately omitted: no guessed ranking.
        return out;
    }

    private static String firstNew(String before,String after){
        Set<String> b=new HashSet<>(Arrays.asList(before.split(";")));
        for(String x:after.split(";")) if(!x.isEmpty()&&!b.contains(x)) return x;
        return "";
    }
    private static String join(Set<String> s){StringBuilder b=new StringBuilder();for(String x:s){if(b.length()>0)b.append(';');b.append(x);}return b.toString();}
    private static String extractItem(String s){
        int i=s.indexOf(":"); if(i>=0 && i+1<s.length()) return s.substring(i+1).trim();
        return s.trim();
    }

    public static final class Rank{public final String item;public final int pct,hits,total;Rank(String i,int p,int h,int t){item=i;pct=p;hits=h;total=t;}}
    public static final class Snapshot{public final List<String> active;public final List<Rank> ranked;public final String currentItem;Snapshot(List<String>a,List<Rank>r,String c){active=a;ranked=r;currentItem=c;}}
}
