# v17 — OpenCV Template Matching + Sequence Memory

- Added local OpenCV `matchTemplate` support for screenshot/template comparison.
- Added bounded Queue/List/Collections/Deque sequence memory for visible analyzer states.
- Added numerical-value history for confidence, optical-flow magnitude, and marker counts.
- Added frequency tracking and recent-sequence statistics.
- Integrated sequence metrics into AlgorithmTrace.
- All processing remains local/read-only and does not access game process memory or intercept its traffic.
