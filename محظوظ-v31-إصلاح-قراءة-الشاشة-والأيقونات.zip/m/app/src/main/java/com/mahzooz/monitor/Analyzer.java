package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.Bitmap;
import java.util.*;

public class Analyzer {
    private final TemplateRepository templates;
    private final HistoryDb db;
    private final SystemLearner learner;
    private final AnalyticsEngine analytics;
    private long lastFrameHash = 0;
    private String lastGreenSignature = "";
    private String lastYellowSignature = "";
    private final ReadOnlyEventMonitor readOnlyEventMonitor;
    private final WebSocketReadOnlyMonitor webSocketMonitor;
    private final EventCorrelationEngine correlationEngine;
    private final SignalRedundancyRouter signalRouter;
    private final OwnedTrafficMetadataMonitor trafficMetadataMonitor;
    private final SelfMemoryStateMonitor selfMemoryMonitor;
    private final FridaSafetyBoundary fridaBoundary;
    private final ScreenshotAndCvTools cvTools;
    private final ParallelProcessingEngine parallelEngine;
    private final HardwareAccelerationManager hardwareAcceleration;
    private final MultiprocessingBoundary multiprocessingBoundary;
    private final SequenceMemory sequenceMemory;
    private final MultiConditionRuleEngine ruleEngine;
    private final SequentialAprioriAlgorithm apriori;
    private final AtomicState atomicState;
    private final InteractionReferenceLearner interactionLearner;
    private final PrePlayDecisionEngine prePlayDecisionEngine;
    private final HitPlanEngine hitPlanEngine;

    public Analyzer(Context c){ templates=new TemplateRepository(c); db=new HistoryDb(c); learner=new SystemLearner(db); analytics=new AnalyticsEngine(); readOnlyEventMonitor=new ReadOnlyEventMonitor(db); webSocketMonitor=new WebSocketReadOnlyMonitor(db); correlationEngine=new EventCorrelationEngine(db); signalRouter=new SignalRedundancyRouter(); trafficMetadataMonitor=new OwnedTrafficMetadataMonitor(db); selfMemoryMonitor=new SelfMemoryStateMonitor(); fridaBoundary=new FridaSafetyBoundary(); cvTools=new ScreenshotAndCvTools(); parallelEngine=new ParallelProcessingEngine(); hardwareAcceleration=new HardwareAccelerationManager(cvTools.openCvAvailable()); multiprocessingBoundary=new MultiprocessingBoundary(); sequenceMemory=new SequenceMemory(120); ruleEngine=new MultiConditionRuleEngine(); apriori=new SequentialAprioriAlgorithm(); atomicState=new AtomicState(); interactionLearner=new InteractionReferenceLearner(); prePlayDecisionEngine=new PrePlayDecisionEngine(); hitPlanEngine=new HitPlanEngine(); }

    public synchronized AnalysisResult analyze(Bitmap bmp){
        final long analysisStartNs = HighResolutionTimer.nowNanos();
        final long timestampMs = System.currentTimeMillis();
        atomicState.recordFrame(timestampMs);
        List<Detector.Marker> g=Detector.findMarkers(bmp,true);
        List<Detector.Marker> y=Detector.findMarkers(bmp,false);
        sortMarkers(g); sortMarkers(y);

        // Always run tile detection. Markers are badges; the tile below each badge
        // is the actual item name used for the learned relation map.
        // Every colored badge belongs to one inventory icon. Build the tile directly
        // from the badge position; this works for 4-column layouts and for rows that
        // move after a scroll instead of assuming a fixed six-column grid.
        List<Detector.Tile> greenItems=new ArrayList<>();
        for(Detector.Marker m:g) { Detector.Tile t=Detector.itemForMarker(bmp,m,templates); greenItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> yellowItems=new ArrayList<>();
        for(Detector.Marker m:y) { Detector.Tile t=Detector.itemForMarker(bmp,m,templates); yellowItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> tiles=new ArrayList<>();
        tiles.addAll(greenItems);
        for(Detector.Tile t:yellowItems){
            boolean dup=false;
            for(Detector.Tile e:tiles) if(!e.rect.isEmpty() && !t.rect.isEmpty() && centerDistance(e.rect,t.rect)<20){dup=true;break;}
            if(!dup) tiles.add(t);
        }

        String previousGreenSignature = lastGreenSignature;
        String previousYellowSignature = lastYellowSignature;
        String current=signature(greenItems);
        sequenceMemory.observeState(current);
        String currentYellow=signature(yellowItems);
        ScreenStateDetector.State screenState = ScreenStateDetector.inspect(bmp,g,y);
        boolean inventoryVisible=!tiles.isEmpty() && (!g.isEmpty() || !y.isEmpty());
        InteractionReferenceLearner.Observation interaction=interactionLearner.observe(bmp,tiles,inventoryVisible,timestampMs);
        if(interaction!=null){
            db.recordInteractionReference(timestampMs,interaction.selectedLabel,interaction.beforeSignature,interaction.afterSignature,interaction.row,interaction.column,interaction.confidence);
            // One completed manual interaction is one real observed hit in the persistent chronological play log.
            // This is history only: the monitor never sends input to the game.
            db.recordPlayHit(interaction.selectedLabel, interaction.confidence, timestampMs);
            // Keep the separate evidence layer for exact observed hit plans; a single test is x1.
            db.observeHitPlan(interaction.selectedLabel,1,"icon-test",interaction.confidence);
            AlgorithmTrace.recordInteractionReference(interaction);
        }
        List<String> relations=buildRelations(greenItems,yellowItems,previousGreenSignature,previousYellowSignature,current,currentYellow,interaction);
        String recommendation=updateAndRecommend(previousGreenSignature,current,interaction);
        String prePlayPlan=buildPrePlayPlan(greenItems,yellowItems,current);
        if(!prePlayPlan.isEmpty()) recommendation=prePlayPlan + (recommendation.isEmpty()?"":"\n"+recommendation);
        SystemLearner.Snapshot model=learner.update(greenItems, recommendation);
        String nextObserved = firstNewLabel(previousGreenSignature, current);
        AlgorithmTrace.recordGameToMonitor(g, y, greenItems, yellowItems, relations);
        if(!recommendation.isEmpty()) AlgorithmTrace.recordMonitorOutput(recommendation);
        lastGreenSignature=current;
        lastYellowSignature=currentYellow;

        float[] channelMeans = parallelEngine.pixelChannelMeans(bmp);
        AlgorithmTrace.recordVisionMetric("Atomic/Bitmask", atomicState.summary() + " | flags=" +
                BitmaskLookupTables.describe(BitmaskLookupTables.mask(!g.isEmpty(), !y.isEmpty(), false, !tiles.isEmpty(), !relations.isEmpty())));
        AlgorithmTrace.recordVisionMetric("Parallel/Vectorized",
                parallelEngine.backendSummary() + " | RGBmean=" + channelMeans[0] + "," + channelMeans[1] + "," + channelMeans[2]);
        AlgorithmTrace.recordVisionMetric("Hardware", hardwareAcceleration.summary());
        AlgorithmTrace.recordVisionMetric("Multiprocessing", multiprocessingBoundary.status() + " | gameProcessHook=" + multiprocessingBoundary.attachesToGameProcess());

        long screenHash=Detector.phash(bmp,new Rect(0,0,bmp.getWidth(),bmp.getHeight()));
        String change=lastFrameHash==0?"بدء الرصد":(Long.bitCount(screenHash^lastFrameHash)>10?"تغير ملحوظ في الشاشة":"");
        lastFrameHash=screenHash;

        float confidence=.35f;
        if(!g.isEmpty()||!y.isEmpty()) confidence+=.20f;
        if(!tiles.isEmpty()) confidence+=.15f;
        if(!relations.isEmpty()) confidence+=.15f;
        if(!recommendation.isEmpty()) confidence+=.05f;
        confidence=Math.min(1f,confidence);
        String coordinates = buildCoordinates(g, y, greenItems, yellowItems, bmp.getWidth(), bmp.getHeight());
        float opticalFlow = cvTools.opticalFlow(bmp);
        sequenceMemory.observeNumbers(timestampMs, confidence, opticalFlow, greenItems.size(), yellowItems.size());
        if (opticalFlow > 0.35f) confidence = Math.min(1f, confidence + 0.05f);
        AlgorithmTrace.recordVisionMetric("OpenCV", "opticalFlow=" + opticalFlow + " available=" + cvTools.openCvAvailable());
        AlgorithmTrace.recordVisionMetric("matchTemplate", "available=" + cvTools.openCvAvailable() + " | thresholded local template matching ready");
        AlgorithmTrace.recordVisionMetric("SequenceMemory", sequenceMemory.summary());
        AlgorithmTrace.recordVisionMetric("IconInteractionTraining", interactionLearner.status() + " | DB=" + db.interactionReferenceCount());
        List<GridMappingAnalysis.Cell> gridCells=GridMappingAnalysis.map(tiles);
        AlgorithmTrace.recordVisionMetric("GridMapping", GridMappingAnalysis.summary(gridCells));
        List<MultiConditionRuleEngine.Match> ruleMatches=ruleEngine.evaluate(greenItems,yellowItems,confidence,opticalFlow);
        if(!ruleMatches.isEmpty()) {
            StringBuilder rb=new StringBuilder();
            for(MultiConditionRuleEngine.Match m:ruleMatches){if(rb.length()>0) rb.append(" | "); rb.append(m.rule).append(": ").append(m.explanation);}
            AlgorithmTrace.recordVisionMetric("MultiConditionRules", rb.toString());
        }
        List<SequentialAprioriAlgorithm.Pattern> patterns=apriori.mine(sequenceMemory.recentStates(120),3,2,5);
        AlgorithmTrace.recordVisionMetric("SequentialApriori", SequentialAprioriAlgorithm.format(patterns));
        AlgorithmTrace.recordScreenState(screenState);
        List<ReadOnlyEventMonitor.Event> readOnlyEvents = readOnlyEventMonitor.observe(greenItems, yellowItems, screenState, timestampMs);
        correlationEngine.correlate(timestampMs, screenState.scene + "/" + screenState.lockState, readOnlyEvents);
        AnalysisResult result = new AnalysisResult(timestampMs,g,y,tiles,relations,recommendation,change,confidence,coordinates,screenState);
        long elapsedNs = HighResolutionTimer.elapsedNanos(analysisStartNs);
        analytics.record(result,timestampMs,elapsedNs,previousGreenSignature,nextObserved);
        db.addAnalyticsSample(timestampMs,elapsedNs,g.size(),y.size(),confidence);
        return result;
    }

    private static void sortMarkers(List<Detector.Marker> a){
        Collections.sort(a,(x,z)->{int d=Integer.compare(x.rect.top,z.rect.top);return d!=0?d:Integer.compare(x.rect.left,z.rect.left);});
    }

    private List<Detector.Tile> attachMarkersToTiles(List<Detector.Marker> markers,List<Detector.Tile> tiles,Bitmap bmp,TemplateRepository repo){
        ArrayList<Detector.Tile> out=new ArrayList<>();
        Set<Integer> used=new HashSet<>();
        for(Detector.Marker m:markers){
            double best=Double.MAX_VALUE; int bi=-1;
            double mx=(m.rect.left+m.rect.right)/2.0, my=(m.rect.top+m.rect.bottom)/2.0;
            for(int i=0;i<tiles.size();i++) if(!used.contains(i)){
                Rect r=tiles.get(i).rect;
                double tx=(r.left+r.right)/2.0, ty=(r.top+r.bottom)/2.0;
                // Badge normally sits near the upper-right of its tile.
                double dx=mx-tx, dy=my-ty;
                double d=Math.hypot(dx,dy);
                if(d<best && dy>-r.height()*0.75 && dy<r.height()*0.75) {best=d;bi=i;}
            }
            if(bi>=0 && best<Math.max(bmp.getWidth()/4.0,120)) {used.add(bi); out.add(tiles.get(bi));}
            else out.add(new Detector.Tile(new Rect(),0,"غير معروف",0));
        }
        return out;
    }

    private List<String> buildRelations(List<Detector.Tile> green,List<Detector.Tile> yellow,
                                         String previousGreen,String previousYellow,
                                         String currentGreen,String currentYellow,
                                         InteractionReferenceLearner.Observation interaction){
        ArrayList<String> out=new ArrayList<>();
        Set<String> beforeG=labels(previousGreen), nowG=labels(currentGreen);
        Set<String> beforeY=labels(previousYellow), nowY=labels(currentYellow);
        Set<String> newG=new LinkedHashSet<>(nowG); newG.removeAll(beforeG);
        Set<String> consumedY=new LinkedHashSet<>(beforeY); consumedY.removeAll(nowY);

        // Learn a relation from a temporal change, not from screen proximity.
        // This is important because the yellow and green icons can be in different rows.
        // Only learn automatically when exactly one green item appeared and exactly
        // one yellow item disappeared in the same observation window. If several
        // things changed at once, pairing them would create false relations.
        if(interaction!=null && newG.size()==1 && consumedY.size()==1){
            String g=newG.iterator().next();
            String y=consumedY.iterator().next();
            db.observeRelation(g,y);
            int hits=db.relationHits(g,y), total=db.relationTotal(g);
            int pct=total>0?Math.round(100f*hits/total):0;
            out.add("🟩 "+g+" ← 🟨 "+y+" | نسبة الربط المرصودة: "+pct+"% ("+hits+"/"+total+")");
        }

        // Also report the strongest previously learned relations for currently visible greens.
        for(String g:nowG){
            List<String> learned=db.relationsFor(g,3);
            for(String item:learned) if(!out.contains(item)) out.add(item);
        }
        return out;
    }

    private static Set<String> labels(String signature){
        LinkedHashSet<String> s=new LinkedHashSet<>();
        if(signature==null||signature.isEmpty()) return s;
        for(String x:signature.split(";")) if(!x.isEmpty()) s.add(x);
        return s;
    }

    private String signature(List<Detector.Tile> items){
        ArrayList<String> labels=new ArrayList<>();
        for (Detector.Tile t : items) if (t!=null && t.label!=null && !t.label.equals("غير معروف")) labels.add(t.label);
        Collections.sort(labels);
        StringBuilder s=new StringBuilder();
        String last="";
        for(String label:labels){
            if(!label.equals(last)){ s.append(label).append(';'); last=label; }
        }
        return s.toString();
    }

    private String updateAndRecommend(String previous,String current,InteractionReferenceLearner.Observation interaction){
        // A transition is counted only at the close of a real icon-interaction window.
        // Ordinary animation, scrolling, or page refreshes therefore cannot inflate the model.
        if(interaction==null || previous==null||previous.isEmpty()||current==null||current.isEmpty()||previous.equals(current)) return "";
        Set<String> before=new LinkedHashSet<>(Arrays.asList(previous.split(";")));
        String next="";
        for(String item:current.split(";")) if(!item.isEmpty()&&!before.contains(item)){ next=item; break; }
        if(next.isEmpty()) return "";
        int total=db.observeTransition(previous,next);
        int hits=db.transitionHits(previous,next);
        if(hits < 3) return "انتقال مرصود: "+next+" — نحتاج مشاهدات إضافية قبل تثبيت النسبة.";
        int pct=Math.round(100f*hits/Math.max(1,total));
        return "الشريط التالي المرصود: "+next+" — "+pct+"% ("+hits+"/"+total+")";
    }


    private String buildPrePlayPlan(List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,String currentGreenState){
        ArrayList<Detector.Tile> candidates=new ArrayList<>();
        candidates.addAll(greenItems);
        candidates.addAll(yellowItems);
        List<PrePlayDecisionEngine.Decision> ranked=prePlayDecisionEngine.rank(candidates,currentGreenState,db);
        if(ranked.isEmpty()) return "";
        StringBuilder s=new StringBuilder("🎯 اللعب الحالي — قرار مسبق قبل اللعب:\n");
        int n=Math.min(5,ranked.size());
        for(int i=0;i<n;i++){
            PrePlayDecisionEngine.Decision d=ranked.get(i);
            s.append(d.line(i+1));
            HitPlanEngine.Plan hp=hitPlanEngine.best(d.label,db);
            if(hp!=null) s.append(" | ").append("خطة الضرب: ×").append(hp.hits);
            else s.append(" | خطة الضرب: لا توجد مشاهدة كافية");
            s.append('\n');
        }
        s.append("⚠ النسبة قوة دليل مرصود وليست ضمانًا للمكسب.");
        return s.toString().trim();
    }

    private String buildCoordinates(List<Detector.Marker> green,List<Detector.Marker> yellow,
                                    List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,
                                    int width,int height){
        StringBuilder s=new StringBuilder();
        if(!green.isEmpty()){
            s.append("🟩 إحداثيات الشرايط (x,y,w,h): ");
            for(int i=0;i<green.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=green.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!yellow.isEmpty()){
            s.append("🟨 إحداثيات الخزين (x,y,w,h): ");
            for(int i=0;i<yellow.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=yellow.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!greenItems.isEmpty()){
            s.append("📍 مراكز العناصر: ");
            for(int i=0;i<greenItems.size();i++){
                Detector.Tile t=greenItems.get(i); if(t.rect.isEmpty()) continue;
                if(s.charAt(s.length()-1)!=' ') s.append(" ؛ ");
                s.append("🟩 ").append(t.label).append("@").append((t.rect.left+t.rect.right)/2)
                 .append(',').append((t.rect.top+t.rect.bottom)/2);
            }
        }
        return s.toString();
    }

    private static double centerDistance(Rect a,Rect b){
        double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0;
        double bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;
        return Math.hypot(ax-bx,ay-by);
    }
    private static String firstNewLabel(String previous,String current){
        Set<String> before=labels(previous);
        for(String x:labels(current)) if(!before.contains(x)) return x;
        return "";
    }
    public void save(AnalysisResult r){db.add(r);} public TemplateRepository templates(){return templates;} public HistoryDb db(){return db;} public AnalyticsEngine analytics(){return analytics;}
    public WebSocketReadOnlyMonitor webSocketMonitor(){return webSocketMonitor;}
    public OwnedTrafficMetadataMonitor trafficMetadataMonitor(){return trafficMetadataMonitor;}
    public SelfMemoryStateMonitor selfMemoryMonitor(){return selfMemoryMonitor;}
    public SignalRedundancyRouter signalRouter(){return signalRouter;}
    public FridaSafetyBoundary fridaBoundary(){return fridaBoundary;}
    public ParallelProcessingEngine parallelEngine(){return parallelEngine;}
    public HardwareAccelerationManager hardwareAcceleration(){return hardwareAcceleration;}
    public MultiprocessingBoundary multiprocessingBoundary(){return multiprocessingBoundary;}
    public InteractionReferenceLearner interactionLearner(){return interactionLearner;}
    public PrePlayDecisionEngine prePlayDecisionEngine(){return prePlayDecisionEngine;}
}
