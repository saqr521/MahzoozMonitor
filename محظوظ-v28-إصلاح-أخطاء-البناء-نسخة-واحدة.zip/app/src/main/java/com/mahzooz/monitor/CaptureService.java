package com.mahzooz.monitor;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;

public class CaptureService extends Service {
    public static final String ACTION_RESULT = "com.mahzooz.monitor.RESULT";
    private MediaProjection projection;
    private ImageReader reader;
    private android.hardware.display.VirtualDisplay display;
    private Analyzer analyzer;
    private HandlerThread workerThread;
    private Handler worker;
    private Handler mainHandler;
    private long lastFrame = 0;
    private AnalysisAccelerators accelerators;
    private ScreenshotAndCvTools cvTools;
    private boolean running = false;
    private WindowManager overlayManager;
    private LinearLayout overlayView;
    private android.widget.FrameLayout overlayContainer;
    private WindowManager.LayoutParams overlayParams;
    private TextView liveText;
    private TextView exploreText;
    private TextView liveHeader;
    private TextView exploreHeader;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        createChannel();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"));
        }

        if (running) return START_STICKY;

        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = intent.getParcelableExtra("data");
        }

        if (resultCode != Activity.RESULT_OK || data == null) {
            broadcast("لم يتم منح صلاحية التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager pm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = pm.getMediaProjection(resultCode, data);
        if (projection == null) {
            broadcast("تعذر بدء التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = intent.getIntExtra("width", dm.widthPixels);
        int h = intent.getIntExtra("height", dm.heightPixels);
        int dpi = intent.getIntExtra("densityDpi", dm.densityDpi);

        mainHandler = new Handler(getMainLooper());
        workerThread = new HandlerThread("MahzoozCapture");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        analyzer = new Analyzer(this);
        AlgorithmTrace.init(this);
        accelerators = new AnalysisAccelerators(AnalysisAccelerators.Level.BALANCED);
        cvTools = new ScreenshotAndCvTools();

        reader = ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 3);

        // Android 14+ requires the MediaProjection callback to be registered
        // before creating the VirtualDisplay.
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                running = false;
                broadcast("تم إيقاف التقاط الشاشة.");
                stopSelf();
            }
        }, worker);

        display = projection.createVirtualDisplay(
                "MahzoozMonitor", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, worker);

        reader.setOnImageAvailableListener(r -> {
            running = true;
            long now = System.currentTimeMillis();
            Image image = null;
            Bitmap bitmap = null;
            try {
                image = r.acquireLatestImage();
                if (image == null) return;
                bitmap = ImageUtils.toBitmap(image);
                long frameHash = Detector.phash(bitmap, new android.graphics.Rect(0,0,bitmap.getWidth(),bitmap.getHeight()));
                if (!accelerators.shouldAnalyze(now, frameHash)) return;
                lastFrame = now;
                AnalysisResult result = analyzer.analyze(bitmap);
                AlgorithmTrace.recordSignalBoundary(new SignalObservation(now, SignalObservation.Direction.GAME_TO_MONITOR, "SCREEN_CAPTURE", SignalReaders.visualState(bitmap, result.green, result.yellow), result.confidence));
                analyzer.save(result);
                // Keep an opt-in-style local evidence trail: at most one PNG every 5 seconds.
                // The image comes only from the MediaProjection frame already granted by Android.
                cvTools.maybeSaveScreenshot(getApplicationContext(), bitmap, now);
                broadcast(format(result));
                updateOverlay(result);
            } catch (Throwable e) {
                broadcast("خطأ أثناء تحليل اللقطة: " + e.getClass().getSimpleName());
            } finally {
                if (image != null) image.close();
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }, worker);

        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            updateOverlay(null);
        }
        broadcast("تم بدء التقاط الشاشة — في انتظار عناصر 🟩 و🟨...");
        return START_STICKY;
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, "capture")
                .setContentTitle("محظوظ")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void broadcast(String text) {
        Intent out = new Intent(ACTION_RESULT);
        out.setPackage(getPackageName());
        out.putExtra("text", text);
        sendBroadcast(out);
    }

    private String format(AnalysisResult r) {
        StringBuilder s = new StringBuilder();
        s.append("🟩 الأشرطة: ").append(r.green.size())
                .append("   🟨 الخزين: ").append(r.yellow.size()).append("\n");
        s.append("حالة الشاشة: ").append(r.screenState.scene).append(" | ")
                .append(r.screenState.lockState).append(" | ")
                .append(Math.round(r.screenState.confidence*100)).append("%\n");
        if (!r.relations.isEmpty()) {
            s.append("الربط والنسب:\n");
            for (String rel : r.relations) s.append("• ").append(rel).append("\n");
        }
        if (!r.recommendation.isEmpty()) s.append(r.recommendation).append("\n");
        if (!r.tiles.isEmpty()) {
            s.append("العناصر: ");
            int n = 0;
            for (Detector.Tile t : r.tiles) {
                if (n++ >= 10) break;
                if (n > 1) s.append("، ");
                s.append(t.label);
            }
            s.append("\n");
        }
        if (!r.observedChange.isEmpty()) s.append(r.observedChange).append("\n");
        if (!r.coordinateSummary.isEmpty()) s.append(r.coordinateSummary).append("\n");
        s.append("الثقة البصرية: ").append(Math.round(r.confidence * 100)).append('%').append('\n');
        java.util.List<String> ir = analyzer.db().recentInteractionReferences(5);
        if (!ir.isEmpty()) { s.append("تدريب ضغط الأيقونات (قراءة فقط):\n"); for (String x : ir) s.append("• ").append(x).append("\n"); }
        java.util.List<String> ev = analyzer.db().recentReadOnlyEvents(8);
        if (!ev.isEmpty()) { s.append("أحداث القراءة فقط:\n"); for (String e : ev) s.append("• ").append(e).append("\n"); }
        java.util.List<String> ws = analyzer.db().recentWebSocketEvents(6);
        if (!ws.isEmpty()) { s.append("WebSocket (قراءة فقط):\n"); for (String e : ws) s.append("• ").append(e).append("\n"); }
        s.append("التسريع: ").append(analyzer.hardwareAcceleration().summary()).append("\n");
        s.append("Parallel: ").append(analyzer.parallelEngine().backendSummary()).append("\n");
        s.append("حدود Frida/Traffic/Memory: FridaHook=").append(analyzer.fridaBoundary().supportedForGameProcessHooking()?"ON":"OFF")
                .append(" | PacketCapture=").append(analyzer.trafficMetadataMonitor().capturesPackets()?"ON":"OFF")
                .append(" | GameMemory=").append(analyzer.fridaBoundary().supportedForGameProcessHooking()?"ON":"OFF").append('\n');
        if(analyzer!=null) s.append(analyzer.analytics().summary()).append('\n');
        s.append(AlgorithmTrace.snapshot());
        return s.toString();
    }

    private void updateOverlay(AnalysisResult r) {
        if (Build.VERSION.SDK_INT < 23 || !Settings.canDrawOverlays(this)) return;
        if (mainHandler != null && android.os.Looper.myLooper() != mainHandler.getLooper()) {
            mainHandler.post(() -> updateOverlay(r));
            return;
        }
        try {
            ensureOverlay();
            if (r == null) {
                liveText.setText("جاري بدء التحليل…");
                exploreText.setText("في انتظار أول قراءة للعناصر 🟩 و🟨");
                return;
            }
            liveText.setText(buildLiveOverlay(r) + "\n" + r.screenState.scene);
            exploreText.setText(buildExploreOverlay(r));
        } catch (Throwable ignored) {}
    }

    private void ensureOverlay() {
        if (overlayManager == null) overlayManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        // Wide, translucent, movable and resizable live HUD.
        overlayView = new LinearLayout(this);
        overlayView.setOrientation(LinearLayout.HORIZONTAL);
        overlayView.setPadding(dp(6), dp(6), dp(6), dp(6));
        overlayView.setElevation(12f);

        GradientDrawable outer = new GradientDrawable();
        outer.setColor(0xB8171720); // dark gray, intentionally translucent
        outer.setCornerRadius(dp(14));
        outer.setStroke(dp(1), 0xA0FFFFFF);
        overlayView.setBackground(outer);

        // LEFT: currently open strips and only relations that were actually observed.
        LinearLayout strips = makeSection("الشرايط والخزين", false);
        // RIGHT: live play guidance. Numbers are shown only for the live recommendation.
        LinearLayout live = makeSection("اللعب", true);

        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -1, 1f);
        half.setMargins(dp(3), 0, dp(3), 0);
        overlayView.addView(strips, half);
        overlayView.addView(live, half);

        // Small resize grip in the bottom-right corner.
        TextView resize = new TextView(this);
        resize.setText("⌟");
        resize.setTextSize(20);
        resize.setTextColor(0xEFFFFFFF);
        resize.setGravity(Gravity.CENTER);
        GradientDrawable gripBg = new GradientDrawable();
        gripBg.setColor(0x554CAF50);
        gripBg.setCornerRadius(dp(8));
        resize.setBackground(gripBg);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        overlayParams = new WindowManager.LayoutParams(
                dp(440), dp(290), type, flags, PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;

        android.content.SharedPreferences sp = getSharedPreferences("overlay", MODE_PRIVATE);
        overlayParams.x = sp.getInt("x", 8);
        overlayParams.y = sp.getInt("y", 70);

        // Resize grip is overlaid using FrameLayout so it doesn't consume a column.
        android.widget.FrameLayout frame = new android.widget.FrameLayout(this);
        overlayContainer = frame;
        frame.addView(overlayView, new android.widget.FrameLayout.LayoutParams(-1, -1));
        android.widget.FrameLayout.LayoutParams gripLp =
                new android.widget.FrameLayout.LayoutParams(dp(30), dp(30), Gravity.BOTTOM | Gravity.END);
        gripLp.setMargins(0, 0, dp(3), dp(3));
        frame.addView(resize, gripLp);

        overlayManager.addView(frame, overlayParams);

        View.OnTouchListener drag = new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = overlayParams.x; startY = overlayParams.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        overlayParams.x = startX + Math.round(e.getRawX() - downX);
                        overlayParams.y = startY + Math.round(e.getRawY() - downY);
                        try { overlayManager.updateViewLayout(frame, overlayParams); } catch (Exception ignored2) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences("overlay", MODE_PRIVATE).edit()
                                .putInt("x", overlayParams.x).putInt("y", overlayParams.y)
                                .putInt("w", overlayParams.width).putInt("h", overlayParams.height).apply();
                        return true;
                }
                return false;
            }
        };

        View.OnTouchListener resizeTouch = new View.OnTouchListener() {
            float downX, downY;
            int startW, startH;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startW = overlayParams.width; startH = overlayParams.height;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        overlayParams.width = Math.max(dp(300), startW + Math.round(e.getRawX() - downX));
                        overlayParams.height = Math.max(dp(190), startH + Math.round(e.getRawY() - downY));
                        try { overlayManager.updateViewLayout(frame, overlayParams); } catch (Exception ignored2) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences("overlay", MODE_PRIVATE).edit()
                                .putInt("x", overlayParams.x).putInt("y", overlayParams.y)
                                .putInt("w", overlayParams.width).putInt("h", overlayParams.height).apply();
                        return true;
                }
                return false;
            }
        };

        // Drag from either section header. Resize only from the corner grip.
        liveHeader.setOnTouchListener(drag);
        exploreHeader.setOnTouchListener(drag);
        resize.setOnTouchListener(resizeTouch);

        // Restore saved size after the first launch.
        overlayParams.width = Math.max(dp(300), sp.getInt("w", dp(440)));
        overlayParams.height = Math.max(dp(190), sp.getInt("h", dp(290)));
        try { overlayManager.updateViewLayout(frame, overlayParams); } catch (Exception ignored2) {}
    }

    private LinearLayout makeSection(String title, boolean live) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(7), dp(5), dp(7), dp(7));

        GradientDrawable bg = new GradientDrawable();
        // Semi-transparent section backgrounds keep the game visible underneath.
        bg.setColor(live ? 0x8F171A20 : 0x8F202020);
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(1), live ? 0xC04CAF50 : 0xC0E0B83B);
        box.setBackground(bg);

        TextView header = new TextView(this);
        header.setText(title + "  ⋮⋮");
        header.setTextSize(14);
        header.setTextColor(0xFFFFFFFF);
        header.setTypeface(null, android.graphics.Typeface.BOLD);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, dp(2), 0, dp(5));
        box.addView(header, new LinearLayout.LayoutParams(-1, -2));

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);

        TextView body = new TextView(this);
        body.setTextSize(12.5f);
        body.setTextColor(0xFFFFFFFF);
        body.setGravity(Gravity.RIGHT | Gravity.TOP);
        body.setLineSpacing(dp(2), 1.08f);
        body.setPadding(dp(3), dp(2), dp(3), dp(5));
        scroll.addView(body, new android.widget.ScrollView.LayoutParams(-1, -2));
        box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        if (live) { liveHeader = header; liveText = body; }
        else { exploreHeader = header; exploreText = body; }
        return box;
    }

    private String buildLiveOverlay(AnalysisResult r) {
        StringBuilder s = new StringBuilder();

        // The percentage is the observed confidence of the current analysis.
        s.append("الثقة: ").append(Math.round(r.confidence * 100)).append("%\n");

        // The recommendation is computed before play from stored evidence.
        if (!r.recommendation.isEmpty()) {
            s.append("▶ ").append(r.recommendation).append("\n");
        } else {
            s.append("▶ لا يوجد اختيار محسوم بعد\n");
        }

        s.append("\n🔢 الضرب المقترح: يظهر فقط إذا كان العدد قد تم رصده فعليًا (مثل ×9 أو ×49).\n");

        if (!r.observedChange.isEmpty()) s.append("تغيير: ").append(r.observedChange).append("\n");

        // Continuity is shown only as historical evidence, never as a guaranteed outcome.
        String continuity = analyzer != null ? analyzer.db().continuitySummary(3) : "";
        if (!continuity.isEmpty()) s.append("دليل سابق: ").append(continuity).append("\n");

        if (r.recommendation.isEmpty()) {
            s.append("\nلا يوجد قرار مسبق محسوم بالأدلة الحالية.");
        } else {
            s.append("\nالقرار أعلاه محسوب قبل اللعب من الأدلة المحفوظة.");
        }
        return s.toString().trim();
    }

    private String buildExploreOverlay(AnalysisResult r) {
        StringBuilder s = new StringBuilder();
        if (r.relations.isEmpty()) {
            s.append("لا توجد علاقات مؤكدة بعد.\n");
            s.append("سيظهر هنا فقط ما تم رصده فعليًا من اللعبة.");
            return s.toString();
        }

        // Each line keeps the observed green -> yellow relationship together.
        // No guessed storage item or required-hit count is generated.
        int n = 0;
        for (String rel : r.relations) {
            if (n++ >= 12) break;
            s.append(rel).append("\n");
        }
        return s.toString().trim();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void removeOverlay() {
        if (overlayView != null && overlayManager != null) {
            try { overlayManager.removeView(overlayContainer != null ? overlayContainer : overlayView); } catch (Exception ignored) {}
        }
        overlayView = null; overlayContainer = null; overlayManager = null; overlayParams = null;
        liveText = null; exploreText = null; liveHeader = null; exploreHeader = null;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "capture", "مراقبة الشاشة", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public void onDestroy() {
        try { if (analyzer != null) analyzer.db().endPlaySession(System.currentTimeMillis()); } catch (Throwable ignored) {}
        running = false;
        if (reader != null) { reader.close(); reader = null; }
        if (display != null) { display.release(); display = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (workerThread != null) { workerThread.quitSafely(); workerThread = null; }
        removeOverlay();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
