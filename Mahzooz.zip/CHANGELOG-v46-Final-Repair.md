# Mahzooz v46.1 — Live reader repair

- Removed the unrelated fixed-board visual reader and its unrelated symbol assets.
- Restored the Mahzooz marker-first reader: green = شريط and yellow = خزين.
- The user-selected read rectangle is now the authoritative region for visual marker detection.
- Marker detection is no longer discarded just because OCR or Accessibility cannot identify the host screen.
- The existing Mahzooz 30-item visual catalog remains available for item-label matching.
- The live overlay now reports whether Mahzooz items are actually being detected instead of reporting an unrelated game board.
- No synthetic item names or invented confidence values are generated.
- Final APK artifact: `Mahzooz-debug.apk`.
