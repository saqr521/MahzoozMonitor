# v41 — Observed Pipeline Repair

This revision preserves the existing project and changes only the analysis wiring/build metadata:

1. Gift-marker recognition no longer depends only on OCR text. A stable gift-grid geometry is accepted as visual evidence, so temporary OCR failure does not blank the Mahzooz analysis.
2. Taka foreground package identity + gift-grid evidence can keep the gift markers active.
3. The floating Mahzooz panel now shows the currently ranked, evidence-backed visible items even when relation rows are still sparse.
4. The live panel exposes OCR engine status so a missing Arabic/English Tesseract model is visible instead of silently looking like a dead analyzer.
5. GitHub Actions remains responsible for fetching `ara.traineddata` and `eng.traineddata` into `app/src/main/assets/tessdata` before building the APK.
6. Version/build artifact labels were advanced to v41.

No existing source/resource file was deleted by this revision. The legacy `assets/icon_templates/` directory remains absent, as it was already absent in the supplied v39 archive; the existing `mahzooz_templates.jpg` sprite and Taka/Martingale resources remain present.

The analysis output is observational/statistical. It ranks items from evidence recorded by the monitor; it does not guarantee a winning next result or place bets automatically.


## v41.1 — Manual Selection Wired

- Added a real “اختيار اللعبة” control to the floating overlay.
- The selected game/area is persisted and can be cycled through observed profiles.
- Automatic detection remains independent and continues to report the actually visible screen.
- The detailed overlay now follows the manual selection when one is set, so a transient detection change does not switch the user's selected area.
- Existing Taka, history, Martingale, OCR, detection, and analysis files/resources are preserved.
- No automatic clicking, wagering, or stake execution was added.
