package com.mahzooz.monitor;

/** Removes emoji/punctuation noise while preserving Arabic, Latin and digits. */
public final class OcrSanitizer {
    private OcrSanitizer() {}

    public static String clean(String rawText) {
        if (rawText == null) return "";
        return rawText
                .replaceAll("[\\p{So}\\p{Cs}]", " ")
                .replaceAll("[^\\p{L}\\p{N}\\s.,:%xX×kKmM_-]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }
}
