package com.mahzooz.monitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/** Launcher/library for user-selected installed apps. Monitoring remains external via Android screen capture. */
public class ProgramCenterActivity extends Activity {
    private LinearLayout list;
    private ProgramLibrary library;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        library = new ProgramLibrary(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(18));

        TextView title = tv("مركز البرامج", 25, true);
        root.addView(title);
        TextView info = tv("أضف البرامج المثبتة أو افتح صفحة البرنامج في Google Play. محظوظ يراقب الشاشة ويحللها بإذن منك.", 14, false);
        info.setPadding(0, dp(8), 0, dp(12));
        root.addView(info);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button installed = new Button(this);
        installed.setText("إضافة من الهاتف");
        installed.setOnClickListener(v -> showInstalledApps());
        buttons.addView(installed, new LinearLayout.LayoutParams(0, -2, 1f));

        Button taka = new Button(this);
        taka.setText("Taka - Google Play");
        taka.setOnClickListener(v -> openPlaySearch("taka"));
        buttons.addView(taka, new LinearLayout.LayoutParams(0, -2, 1f));

        Button zena = new Button(this);
        zena.setText("Zena - Google Play");
        zena.setOnClickListener(v -> openPlaySearch("zena"));
        buttons.addView(zena, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(buttons);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        refresh();
    }

    private void refresh() {
        list.removeAllViews();
        Set<String> packages = library.getPackages();
        if (packages.isEmpty()) {
            TextView empty = tv("لا توجد برامج مضافة. اضغط «إضافة من الهاتف».", 16, false);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = new ArrayList<>();
        for (String pkg : packages) {
            try { apps.add(pm.getApplicationInfo(pkg, 0)); } catch (Exception ignored) {}
        }
        Collections.sort(apps, Comparator.comparing(a -> a.loadLabel(pm).toString(), String.CASE_INSENSITIVE_ORDER));
        for (ApplicationInfo app : apps) addAppRow(app, pm);
    }

    private void addAppRow(ApplicationInfo app, PackageManager pm) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(10), dp(8), dp(10));

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(app.loadIcon(pm));
        row.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView name = tv(app.loadLabel(pm).toString(), 18, true);
        TextView pkg = tv(app.packageName, 11, false);
        labels.addView(name);
        labels.addView(pkg);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));

        Button open = new Button(this);
        open.setText("فتح");
        open.setOnClickListener(v -> {
            Intent launch = pm.getLaunchIntentForPackage(app.packageName);
            if (launch != null) {
                startActivity(launch);
                // CaptureService/overlay can continue independently after user grants capture permission.
            } else Toast.makeText(this, "لا يمكن تشغيل هذا البرنامج", Toast.LENGTH_SHORT).show();
        });
        row.addView(open);

        Button remove = new Button(this);
        remove.setText("حذف");
        remove.setOnClickListener(v -> { library.remove(app.packageName); refresh(); });
        row.addView(remove);
        list.addView(row);
    }

    private void showInstalledApps() {
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ApplicationInfo> apps = new ArrayList<>();
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(launcher, 0)) {
            if (ri.activityInfo != null && !getPackageName().equals(ri.activityInfo.packageName)) {
                try { apps.add(pm.getApplicationInfo(ri.activityInfo.packageName, 0)); } catch (Exception ignored) {}
            }
        }
        Collections.sort(apps, Comparator.comparing(a -> a.loadLabel(pm).toString(), String.CASE_INSENSITIVE_ORDER));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(10));
        ScrollView scroll = new ScrollView(this);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);

        for (ApplicationInfo app : apps) {
            CheckBox cb = new CheckBox(this);
            cb.setText(app.loadLabel(pm).toString());
            cb.setTag(app.packageName);
            cb.setTextSize(16);
            cb.setCompoundDrawablesWithIntrinsicBounds(app.loadIcon(pm), null, null, null);
            cb.setCompoundDrawablePadding(dp(10));
            cb.setOnCheckedChangeListener((button, checked) -> {
                if (checked) library.add((String) button.getTag());
            });
            inner.addView(cb);
        }
        scroll.addView(inner);
        box.addView(scroll, new LinearLayout.LayoutParams(-1, dp(430)));

        new AlertDialog.Builder(this)
                .setTitle("اختر البرامج")
                .setView(box)
                .setPositiveButton("تم", (d,w) -> refresh())
                .setNegativeButton("إلغاء", null)
                .show();
    }

    /**
     * Opens the official Google Play app when available. The user installs the
     * selected app normally through Google Play; after installation it can be
     * added to this library and launched from here.
     */
    private void openPlaySearch(String query) {
        Uri webUri = Uri.parse("https://play.google.com/store/search?q="
                + Uri.encode(query) + "&c=apps");
        try {
            Intent market = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://search?q=" + Uri.encode(query)));
            market.setPackage("com.android.vending");
            startActivity(market);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, webUri));
            } catch (Exception ignored) {
                Toast.makeText(this, "تعذر فتح Google Play", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (list != null) refresh();
    }

    private TextView tv(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
