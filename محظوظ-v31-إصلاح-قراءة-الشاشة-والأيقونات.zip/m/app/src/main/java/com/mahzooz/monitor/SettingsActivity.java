package com.mahzooz.monitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

/**
 * All operational controls intentionally live here.
 * The main screen stays clean and contains only the settings entry point.
 */
public class SettingsActivity extends Activity {
    private static final int REQ_CAPTURE = 42;
    private HistoryDb db;
    private TextView status;
    private TextView count;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new HistoryDb(this);
        build();
        registerReceiver(receiver, new IntentFilter(CaptureService.ACTION_RESULT),
                Build.VERSION.SDK_INT >= 33 ? Context.RECEIVER_NOT_EXPORTED : 0);
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(8, 17, 29));

        TextView title = new TextView(this);
        title.setText("⚙️ إعدادات محظوظ");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("من هنا فقط يتم التحكم في الصلاحيات والمراقبة والتعلّم والسجل");
        subtitle.setTextSize(14);
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 18);
        root.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        addSectionTitle(content, "الصلاحيات");
        Button permissions = button("تجهيز الصلاحيات");
        permissions.setOnClickListener(v -> preparePermissions());
        content.addView(permissions, buttonParams());

        Button overlay = button("صلاحية الظهور فوق التطبيقات");
        overlay.setOnClickListener(v -> openOverlaySettings());
        content.addView(overlay, buttonParams());

        Button accessibility = button("صلاحية إمكانية الوصول");
        accessibility.setOnClickListener(v -> openAccessibilitySettings());
        content.addView(accessibility, buttonParams());

        addSectionTitle(content, "المراقبة");
        status = new TextView(this);
        status.setText("جاهز");
        status.setTextColor(Color.rgb(80, 230, 140));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(8, 12, 8, 12);
        content.addView(status);

        Button start = button("ابدأ المراقبة والتحليل");
        start.setOnClickListener(v -> startCapture());
        content.addView(start, buttonParams());

        Button stop = button("إيقاف المراقبة");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            status.setText("تم إيقاف المراقبة وإزالة اللوحة");
        });
        content.addView(stop, buttonParams());

        addSectionTitle(content, "التعلّم والاستكشاف");
        Button calibrate = button("تعليم اسم عنصر (بط / جولد / بطيخ...)");
        calibrate.setOnClickListener(v -> calibrate());
        content.addView(calibrate, buttonParams());

        Button hidden = button("مسح الإيقونات المخفية (سحب)");
        hidden.setOnClickListener(v -> revealHidden());
        content.addView(hidden, buttonParams());

        addSectionTitle(content, "السجل والبيانات");
        count = new TextView(this);
        count.setTextColor(Color.rgb(80, 230, 140));
        count.setTextSize(15);
        count.setGravity(Gravity.CENTER);
        count.setPadding(0, 10, 0, 10);
        content.addView(count);

        Button history = button("السجل والإحصائيات");
        history.setOnClickListener(v -> showPlayLog());
        content.addView(history, buttonParams());

        Button allHistory = button("المشاهدات والعلاقات العامة");
        allHistory.setOnClickListener(v -> showGeneralHistory());
        content.addView(allHistory, buttonParams());

        Button delete = button("🗑️ مسح كل البيانات يدويًا");
        delete.setOnClickListener(v -> confirmDeleteAll());
        content.addView(delete, buttonParams());

        Button close = button("رجوع");
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams cp = buttonParams();
        cp.topMargin = 18;
        content.addView(close, cp);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        refreshCount();
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        return new LinearLayout.LayoutParams(-1, 60);
    }

    private void addSectionTitle(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(8, 18, 8, 8);
        parent.addView(t);
    }

    private void startCapture() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            status.setText("فعّل صلاحية الظهور فوق التطبيقات أولًا.");
            openOverlaySettings();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            status.setText("وافق على الإشعارات ثم اضغط البدء مرة أخرى.");
            return;
        }
        MediaProjectionManager m =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    private void preparePermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            status.setText("فعّل الظهور فوق التطبيقات ثم ارجع.");
            openOverlaySettings();
            return;
        }
        if (!isAccessibilityEnabled()) {
            status.setText("فعّل خدمة محظوظ من إمكانية الوصول ثم ارجع.");
            openAccessibilitySettings();
            return;
        }
        status.setText("الصلاحيات المتاحة جاهزة. التقاط الشاشة يحتاج موافقة أندرويد عند البدء.");
    }

    private void openOverlaySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void openAccessibilitySettings() {
        try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "تعذر فتح إعدادات إمكانية الوصول", Toast.LENGTH_SHORT).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            status.setText(grantResults.length > 0 &&
                    grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
                    ? "تم السماح بالإشعارات. اضغط ابدأ المراقبة."
                    : "إشعارات المراقبة مرفوضة؛ يمكنك السماح بها من إعدادات أندرويد.");
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ_CAPTURE) return;
        if (result != RESULT_OK || data == null) {
            status.setText("تم إلغاء صلاحية التقاط الشاشة.");
            return;
        }
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        Intent i = new Intent(this, CaptureService.class);
        i.putExtra("resultCode", result);
        i.putExtra("data", data);
        i.putExtra("width", dm.widthPixels);
        i.putExtra("height", dm.heightPixels);
        i.putExtra("densityDpi", dm.densityDpi);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("جاري تشغيل التحليل…");
    }

    private void calibrate() {
        final EditText e = new EditText(this);
        e.setHint("اسم العنصر");
        new AlertDialog.Builder(this)
                .setTitle("تعليم عنصر")
                .setMessage("الاسم وحده لا ينشئ قالبًا بصريًا. التعرف الدقيق يحتاج لقطة واضحة من شاشة اللعبة.")
                .setView(e)
                .setPositiveButton("حفظ الاسم", (d, w) ->
                        Toast.makeText(this, "تم إدخال: " + e.getText(), Toast.LENGTH_SHORT).show())
                .setNegativeButton("إلغاء", null).show();
    }

    private void revealHidden() {
        if (!isAccessibilityEnabled()) {
            status.setText("فعّل خدمة محظوظ أولًا.");
            openAccessibilitySettings();
            return;
        }
        Intent swipe = new Intent(ScrollAccessibilityService.ACTION_REVEAL_HIDDEN);
        swipe.setPackage(getPackageName());
        sendBroadcast(swipe);
        status.setText("تم طلب سحب الشاشة لقراءة الصفوف الجديدة.");
    }

    private boolean isAccessibilityEnabled() {
        android.view.accessibility.AccessibilityManager am =
                (android.view.accessibility.AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        for (android.accessibilityservice.AccessibilityServiceInfo info :
                am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
            if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null &&
                    getPackageName().equals(info.getResolveInfo().serviceInfo.packageName)) return true;
        }
        return false;
    }

    private void refreshCount() {
        count.setText("الضربات المحفوظة: " + db.playLogCount() + " | إجمالي السجلات: " + db.storedRecordCount());
    }

    private void showPlayLog() {
        List<String> rows = db.playLog(500);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(8,8,8,8);
        if (rows.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("لا توجد ضربات محفوظة بعد.");
            empty.setTextSize(16); empty.setTextColor(Color.WHITE); empty.setPadding(16,24,16,24);
            list.addView(empty);
        } else {
            for (String line : rows) {
                long id = parseId(line);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
                TextView text = new TextView(this);
                text.setText("• " + line.replace(" | ID=" + id, ""));
                text.setTextSize(15); text.setTextColor(Color.WHITE); text.setPadding(8,8,8,8);
                row.addView(text, new LinearLayout.LayoutParams(0,-2,1));
                Button del = new Button(this); del.setText("🗑️");
                del.setOnClickListener(v -> confirmDeleteHit(id));
                row.addView(del, new LinearLayout.LayoutParams(60,60));
                list.addView(row);
            }
        }
        ScrollView scroll = new ScrollView(this); scroll.addView(list);
        new AlertDialog.Builder(this).setTitle("🥊 سجل اللعب — كل ضربة مستقلة")
                .setView(scroll).setPositiveButton("إغلاق",null).show();
    }

    private long parseId(String line) {
        try { int p=line.lastIndexOf("ID="); return Long.parseLong(line.substring(p+3).trim()); }
        catch(Exception e){ return -1; }
    }

    private void confirmDeleteHit(long id) {
        if(id<1)return;
        new AlertDialog.Builder(this).setTitle("حذف هذه الضربة؟")
                .setMessage("سيتم حذف هذه الضربة فقط. باقي الضربات ستظل محفوظة.")
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("حذف",(d,w)->{db.deletePlayHit(id);refreshCount();showPlayLog();}).show();
    }

    private void showGeneralHistory() {
        List<String> x=db.recent(100), rel=db.learnedRelations(100), seq=db.learnedTransitions(100);
        StringBuilder msg=new StringBuilder("=== المشاهدات ===\n");
        msg.append(x.isEmpty()?"لا توجد مشاهدات بعد.\n":android.text.TextUtils.join("\n",x));
        msg.append("\n\n=== الخزين المرتبط بالشرايط ===\n");
        msg.append(rel.isEmpty()?"لا توجد علاقات مكتشفة بعد.\n":android.text.TextUtils.join("\n",rel));
        msg.append("\n\n=== تسلسل الشرايط ===\n");
        msg.append(seq.isEmpty()?"لا يوجد تسلسل مثبت بعد.\n":android.text.TextUtils.join("\n",seq));
        new AlertDialog.Builder(this).setTitle("📊 البيانات العامة").setMessage(msg.toString())
                .setPositiveButton("إغلاق",null).show();
    }

    private void confirmDeleteAll() {
        new AlertDialog.Builder(this).setTitle("مسح كل البيانات؟")
                .setMessage("سيتم حذف كل المشاهدات والعلاقات والتسلسلات وخطط الضرب وسجل الضربات.")
                .setNegativeButton("إلغاء",null)
                .setPositiveButton("مسح بالكامل",(d,w)->{db.clearAllHistory();refreshCount();}).show();
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (status != null) status.setText(i.getStringExtra("text"));
            refreshCount();
        }
    };

    @Override protected void onResume() { super.onResume(); if(db!=null && count!=null) refreshCount(); }

    @Override protected void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
