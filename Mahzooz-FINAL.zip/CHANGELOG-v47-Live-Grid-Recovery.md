# v47 — Live Grid Recovery

- Added direct card/grid recognition as a recovery path when green/yellow corner markers are missed.
- Added 4x3, 5x3, 4x4, 6x5, 3x3 and 5x4 layout candidates.
- When a user-selected region is supplied, the reader tries the complete selected region before screen scanning.
- Reference cards are loaded from the bundled 30-item Mahzooz sheet and compared as card images, not only tiny badge crops.
- Live panel now gives an explicit first-run training instruction instead of remaining at “waiting” with no next step.
- The reader remains observational: it does not fabricate unseen outcomes or send taps to the game.
- APK versionCode: 47.
