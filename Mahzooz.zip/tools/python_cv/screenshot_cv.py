"""Desktop validation companion for the Android live-fusion pipeline.

MSS/PyAutoGUI capture -> OpenCV -> OCR -> visual/template checks -> Markov
observation history. It never clicks, types or controls the target app.
"""
from __future__ import annotations
import argparse
import time
from collections import defaultdict
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
import mss


def capture_bgr():
    with mss.mss() as sct:
        mon = sct.monitors[1]
        return np.array(sct.grab(mon))[:, :, :3]


def optical_flow(previous, current):
    prev = cv2.resize(cv2.cvtColor(previous, cv2.COLOR_BGR2GRAY), (320, 0))
    curr = cv2.resize(cv2.cvtColor(current, cv2.COLOR_BGR2GRAY), (320, 0))
    flow = cv2.calcOpticalFlowFarneback(prev, curr, None, 0.5, 3, 15, 3, 5, 1.2, 0)
    mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
    return float(np.mean(mag))


def ocr(frame, engine):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    if engine == "tesseract":
        import pytesseract
        return pytesseract.image_to_string(Image.fromarray(rgb), lang="ara+eng", config="--psm 11")
    if engine == "easyocr":
        import easyocr
        reader = easyocr.Reader(["ar", "en"], gpu=False, verbose=False)
        return "\n".join(reader.readtext(rgb, detail=0, paragraph=True))
    return ""


def game_state(text: str) -> str:
    t = (text or "").lower()
    if any(x in t for x in ("الحقيبة", "إرسال", "الكل في الغرفة", "svip", "أكثر شعبية")):
        return "TAKA_GIFT_ROOM"
    if any(x in t for x in ("sphinx magic", "bet", "stake", "win", "spin", "الرهان", "فوز")):
        return "TAKA_INTERNAL_GAME"
    return "UNKNOWN"


class Markov:
    def __init__(self):
        self.counts = defaultdict(lambda: defaultdict(int))

    def observe(self, previous, current):
        if previous and current and previous != current:
            self.counts[previous][current] += 1

    def rank(self, previous, limit=5):
        row = self.counts.get(previous, {})
        total = sum(row.values())
        return [(k, v, (100.0 * v / total) if total else 0.0)
                for k, v in sorted(row.items(), key=lambda kv: kv[1], reverse=True)[:limit]]


def template_match(frame, template_path):
    """Optional non-authoritative visual check against the supplied item sprite sheet."""
    if not template_path or not Path(template_path).is_file():
        return []
    sheet = cv2.imread(str(template_path), cv2.IMREAD_COLOR)
    if sheet is None:
        return []
    # Keep this diagnostic cheap: compare the whole frame against the 30 sprite cells
    # only after reducing both to compact grayscale signatures.
    small = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (96, 96))
    results = []
    for i in range(30):
        x, y = (i % 6) * 100, (i // 6) * 120
        tpl = sheet[y:y+120, x:x+100]
        tpl = cv2.resize(cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY), (96, 96))
        score = float(cv2.matchTemplate(small, tpl, cv2.TM_CCOEFF_NORMED).max())
        results.append((i + 1, score))
    return sorted(results, key=lambda x: x[1], reverse=True)[:3]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seconds", type=float, default=3)
    ap.add_argument("--ocr", choices=["none", "tesseract", "easyocr"], default="none")
    ap.add_argument("--save", action="store_true", help="explicitly save one diagnostic frame")
    ap.add_argument("--templates", default="", help="path to mahzooz_templates.jpg")
    args = ap.parse_args()

    first = capture_bgr()
    time.sleep(max(0.05, args.seconds))
    second = capture_bgr()
    print(f"screen={second.shape[1]}x{second.shape[0]}")
    print(f"opencv optical_flow={optical_flow(first, second):.4f}")

    text = ""
    if args.ocr != "none":
        text = ocr(second, args.ocr).strip()
        print("OCR:")
        print(text)

    state = game_state(text)
    print(f"fused_state={state}")

    markov = Markov()
    markov.observe("PREVIOUS", state)
    print(f"markov={markov.rank('PREVIOUS')}")

    if args.templates:
        print(f"template_top3={template_match(second, args.templates)}")

    if args.save:
        out = Path("screenshots")
        out.mkdir(exist_ok=True)
        path = out / f"mahzooz_{time.strftime('%Y%m%d_%H%M%S')}.png"
        cv2.imwrite(str(path), second)
        print(f"saved={path}")


if __name__ == "__main__":
    main()
