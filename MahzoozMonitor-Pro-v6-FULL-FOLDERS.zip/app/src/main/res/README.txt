Android resources.
