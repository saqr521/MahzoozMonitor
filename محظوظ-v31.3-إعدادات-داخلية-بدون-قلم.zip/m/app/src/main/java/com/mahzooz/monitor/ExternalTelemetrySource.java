package com.mahzooz.monitor;

/**
 * Safe boundary for optional telemetry imported from user-owned/exported data.
 * It deliberately does not intercept packets, bypass TLS, hook another process,
 * or require root.
 */
public interface ExternalTelemetrySource {
    void onObservation(long timestampMs,long elapsedNs,int green,int yellow,float confidence,String note);
}
