# v12 / 6.3.0

## Added
- Counter
- HighResolutionTimer
- TimestampAnalysis
- TimeSeriesAnalysis
- StatisticalAnalysis
- MarkovChainsModel
- RtpTrackingAlgorithm (observational outcome tracker only)
- NumericalAnalysis (NumPy/SciPy-style local primitives in Java)
- Persistent analytics_samples table
- Protobuf telemetry schema for user-owned/exported observations
- ExternalTelemetrySource safe boundary

## Accuracy fixes
- Green/yellow marker detection no longer assumes four columns or fixed horizontal ordering.
- Marker color remains the primary classifier.
- Existing evidence-only transition learning is preserved.

## Not included
- Scapy/mitmproxy interception of the game network
- SSL proxying/bypass of another app
- Magisk/LSPosed hooks into another app/process

Those mechanisms are outside the screen-observation design and can intercept private traffic or alter another app's runtime. The project instead accepts screen observations and explicitly exported/user-owned telemetry.


## v13 additions
- Kept the complete v12 source unchanged and added only safe integration boundaries.
- Added normalized imported telemetry records and an adapter for user-exported Scapy/mitmproxy data.
- Added explicit non-support boundaries for SSL proxying/bypass and Magisk/LSPosed process hooks.

## v13.1 SAFE telemetry + instant screen state
- Fixed temporal transition accounting so analytics receives the real previous green signature.
- Added three independent read-only signal readers: screen capture, optional accessibility semantics, and user-exported telemetry.
- Added visible-screen open/locked/unknown state detection immediately from the first captured frame.
- Added three processing accelerators: adaptive cadence, duplicate-frame skipping, and ROI-aware tuning hooks.
- Preserved existing green/yellow detection, relation learning, overlay, history, accessibility scrolling, and safe telemetry boundaries.
- No packet interception, TLS bypass, private-memory access, process injection, or automatic game input was added.
