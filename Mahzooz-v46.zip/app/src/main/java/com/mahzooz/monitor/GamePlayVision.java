package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import java.io.InputStream;
import java.util.*;

/**
 * Read-only visual reader for the Taka 5x2 board shown in the supplied v46
 * screenshots. It reads ONLY the user-selected rectangle. The four board
 * templates are the actual bundled Taka symbol images; no synthetic/fake
 * symbol features and no Mahzooz gift catalog are used for this board.
 */
public final class GamePlayVision {
    public static final class Suggestion {
        public final String label;
        public final int confidencePct;
        public final int hits;
        public final int total;
        Suggestion(String l, int c, int h, int t) {
            label = l;
            confidencePct = Math.max(0, Math.min(100, c));
            hits = h;
            total = t;
        }
    }

    public static final class Result {
        public final boolean gridDetected, stable;
        public final String currentLabel;
        public final int recognitionPct;
        public final List<Suggestion> suggestions;
        public final int changedCells;
        public final String sequence;
        Result(boolean gd, boolean st, String cl, int rp, List<Suggestion> ss, int cc, String seq) {
            gridDetected = gd;
            stable = st;
            currentLabel = cl;
            recognitionPct = rp;
            suggestions = ss;
            changedCells = cc;
            sequence = seq;
        }
    }

    private static final int ROWS = 2;
    private static final int COLS = 5;
    private static final float MATCH_THRESHOLD = 0.58f;

    private final SharedPreferences prefs;
    private final ArrayList<BoardTemplate> templates = new ArrayList<>();
    private String lastCandidate = "";
    private int stableFrames = 0;
    private String committed = "";
    private String[] committedCells = null;
    private String lastTrigger = "";

    private static final class BoardTemplate {
        final String label;
        final Bitmap bitmap;
        BoardTemplate(String l, Bitmap b) { label = l; bitmap = b; }
    }

    public GamePlayVision(Context c) {
        Context app = c.getApplicationContext();
        // New namespace intentionally prevents any old numeric/guessed symbols
        // from previous builds from being loaded into v46.
        prefs = app.getSharedPreferences("game_visual_symbols_v46", Context.MODE_PRIVATE);
        loadActualTakaTemplates(app);
        // Do not load the old prototype database. v46 must never resurrect
        // arbitrary values such as "رمز 81".
        prefs.edit().remove("prototypes_v2").apply();
    }

    private void loadActualTakaTemplates(Context c) {
        loadTemplate(c, "دب", "taka_symbols/bear.png");
        loadTemplate(c, "أرنب", "taka_symbols/rabbit.png");
        loadTemplate(c, "باندا", "taka_symbols/panda.png");
        loadTemplate(c, "كلب", "taka_symbols/dog.png");
    }

    private void loadTemplate(Context c, String label, String path) {
        try (InputStream in = c.getAssets().open(path)) {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b != null && !b.isRecycled()) templates.add(new BoardTemplate(label, b));
        } catch (Throwable ignored) {}
    }

    public synchronized Result analyze(Bitmap b, HistoryDb db, long nowMs) {
        if (b == null || b.isRecycled() || b.getWidth() < 300 || b.getHeight() < 160 || templates.isEmpty()) {
            return empty(false);
        }

        // v46 target board is fixed at 5 columns x 2 rows. The user chooses the
        // rectangle; we do not guess 4x3/4x2 and accidentally read unrelated UI.
        String[] cells = new String[ROWS * COLS];
        int recognized = 0;
        float confidenceSum = 0f;

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                Rect r = cellRect(b, row, col);
                MatchResult m = classifyCell(b, r);
                cells[row * COLS + col] = m.label;
                if (!m.label.isEmpty()) {
                    recognized++;
                    confidenceSum += m.score;
                }
            }
        }

        String sig = String.join(";", cells);
        if (sig.equals(lastCandidate)) stableFrames++;
        else {
            lastCandidate = sig;
            stableFrames = 1;
        }

        int changed = 0;
        String trigger = "";
        if (stableFrames >= 2 && !sig.equals(committed)) {
            if (committedCells != null && committedCells.length == cells.length) {
                for (int i = 0; i < cells.length; i++) {
                    String old = committedCells[i] == null ? "" : committedCells[i];
                    String now = cells[i] == null ? "" : cells[i];
                    if (!now.isEmpty() && !now.equals(old)) {
                        changed++;
                        if (trigger.isEmpty()) trigger = now;
                        if (!old.isEmpty()) {
                            try { db.observeGameTransition(old, now); } catch (Throwable ignored) {}
                        }
                    }
                }
            } else {
                for (String x : cells) {
                    if (x != null && !x.isEmpty()) { trigger = x; break; }
                }
            }
            committed = sig;
            committedCells = cells.clone();
            if (!trigger.isEmpty()) lastTrigger = trigger;
        }

        if (trigger.isEmpty()) trigger = lastTrigger;
        if (trigger.isEmpty()) trigger = firstUseful(cells);

        List<Suggestion> suggestions = aggregateSuggestions(cells, db);
        int rec = recognized == 0 ? 0 : Math.round(100f * confidenceSum / recognized);
        return new Result(true, stableFrames >= 2, trigger, rec, suggestions, changed,
                sequenceText(cells));
    }

    private Result empty(boolean grid) {
        return new Result(grid, false, "", 0, Collections.emptyList(), 0, "");
    }

    private Rect cellRect(Bitmap b, int row, int col) {
        int w = b.getWidth(), h = b.getHeight();
        // Small edge margin keeps the rounded game frame/border out of the cells.
        int left = Math.round(w * .02f);
        int right = Math.round(w * .98f);
        int top = Math.round(h * .03f);
        int bottom = Math.round(h * .97f);
        int cw = Math.max(1, (right - left) / COLS);
        int ch = Math.max(1, (bottom - top) / ROWS);
        int x = left + col * cw;
        int y = top + row * ch;
        int padX = Math.max(3, Math.round(cw * .08f));
        int padY = Math.max(3, Math.round(ch * .08f));
        return new Rect(
                x + padX,
                y + padY,
                Math.min(right, x + cw - padX),
                Math.min(bottom, y + ch - padY));
    }

    private static final class MatchResult {
        String label = "";
        float score = 0f;
    }

    private MatchResult classifyCell(Bitmap board, Rect rect) {
        MatchResult out = new MatchResult();
        if (rect.width() < 90 || rect.height() < 105) return out;

        // First pass: exact-size local template matching. The supplied assets are
        // extracted Taka symbol images, so matching against them is preferable to
        // OCR or arbitrary learned numeric IDs.
        BoardTemplate best = null;
        float bestScore = 0f;
        for (BoardTemplate t : templates) {
            try {
                Bitmap cell = Bitmap.createBitmap(board, rect.left, rect.top, rect.width(), rect.height());
                TemplateMatcher.Match m = TemplateMatcher.match(cell, t.bitmap, 0.0);
                cell.recycle();
                float score = (float)m.score;
                if (score > bestScore) {
                    bestScore = score;
                    best = t;
                }
            } catch (Throwable ignored) {}
        }

        // A second pass trims the cell to the central icon area. This helps when
        // the selected rectangle contains a little more of the game background.
        if (best == null || bestScore < MATCH_THRESHOLD) {
            Rect inner = centeredIconRect(rect);
            for (BoardTemplate t : templates) {
                try {
                    Bitmap cell = Bitmap.createBitmap(board, inner.left, inner.top, inner.width(), inner.height());
                    TemplateMatcher.Match m = TemplateMatcher.match(cell, t.bitmap, 0.0);
                    cell.recycle();
                    float score = (float)m.score;
                    if (score > bestScore) {
                        bestScore = score;
                        best = t;
                    }
                } catch (Throwable ignored) {}
            }
        }

        // Do not force a label from a weak match. Unknown remains unknown rather
        // than becoming a fake "رمز 81" or an unrelated Mahzooz gift.
        if (best != null && bestScore >= MATCH_THRESHOLD) {
            out.label = best.label;
            out.score = Math.max(0f, Math.min(1f, bestScore));
        }
        return out;
    }

    private Rect centeredIconRect(Rect r) {
        int w = r.width(), h = r.height();
        // Template aspect ratio is 86x100. Keep the center and use a slightly
        // generous crop so the icon remains visible at common phone densities.
        float target = 86f / 100f;
        int cw = w, ch = h;
        float aspect = w / (float)h;
        if (aspect > target) cw = Math.max(90, Math.round(h * target));
        else ch = Math.max(105, Math.round(w / target));
        int left = r.left + Math.max(0, (w - cw) / 2);
        int top = r.top + Math.max(0, (h - ch) / 2);
        int right = Math.min(r.right, left + cw);
        int bottom = Math.min(r.bottom, top + ch);
        return new Rect(left, top, right, bottom);
    }

    private List<Suggestion> aggregateSuggestions(String[] cells, HistoryDb db) {
        HashMap<String, int[]> agg = new HashMap<>();
        for (String current : cells) {
            if (current == null || current.isEmpty()) continue;
            try {
                for (String row : db.rankedGameTransitions(current, 5)) {
                    String[] p = row.split("\\|", -1);
                    if (p.length < 3 || !isKnownBoardLabel(p[0])) continue;
                    String[] ht = p[2].split("/", 2);
                    if (ht.length < 2) continue;
                    int hits = Integer.parseInt(ht[0]);
                    int total = Integer.parseInt(ht[1]);
                    if (hits <= 0 || total <= 0) continue;
                    int[] a = agg.get(p[0]);
                    if (a == null) { a = new int[]{0, 0}; agg.put(p[0], a); }
                    a[0] += hits;
                    a[1] += total;
                }
            } catch (Throwable ignored) {}
        }
        ArrayList<Suggestion> out = new ArrayList<>();
        for (Map.Entry<String, int[]> e : agg.entrySet()) {
            int hits = e.getValue()[0], total = e.getValue()[1];
            if (hits <= 0 || total <= 0) continue;
            out.add(new Suggestion(e.getKey(), Math.round(100f * hits / total), hits, total));
        }
        out.sort((a, b) -> {
            int d = Integer.compare(b.confidencePct, a.confidencePct);
            return d != 0 ? d : Integer.compare(b.hits, a.hits);
        });
        return out.size() > 5 ? new ArrayList<>(out.subList(0, 5)) : out;
    }

    private boolean isKnownBoardLabel(String s) {
        return "دب".equals(s) || "أرنب".equals(s) || "باندا".equals(s) || "كلب".equals(s);
    }

    private String firstUseful(String[] a) {
        for (String s : a) if (s != null && !s.isEmpty()) return s;
        return "";
    }

    private String sequenceText(String[] cells) {
        StringBuilder b = new StringBuilder();
        for (int r = 0; r < ROWS; r++) {
            if (r > 0) b.append(" / ");
            for (int c = 0; c < COLS; c++) {
                if (c > 0) b.append(" → ");
                String s = cells[r * COLS + c];
                b.append(s == null || s.isEmpty() ? "غير مقروء" : s);
            }
        }
        return b.toString();
    }
}
