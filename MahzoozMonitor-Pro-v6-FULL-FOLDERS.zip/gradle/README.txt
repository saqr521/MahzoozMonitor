Gradle support/configuration.
