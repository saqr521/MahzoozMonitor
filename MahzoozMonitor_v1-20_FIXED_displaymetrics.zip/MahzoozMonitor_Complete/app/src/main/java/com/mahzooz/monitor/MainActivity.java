package com.mahzooz.monitor;

import android.app.*;import android.content.*;import android.graphics.Color;import android.media.projection.MediaProjectionManager;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.View;import android.widget.*;import java.util.Locale;

public class MainActivity extends Activity {
 private static final int CAPTURE=41; private EditText cost,ret; private TextView stats; private SharedPreferences p;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);p=getSharedPreferences("history",0);cost=findViewById(R.id.cost);ret=findViewById(R.id.returnValue);stats=findViewById(R.id.stats);refresh();
  findViewById(R.id.start).setOnClickListener(v->startCapture());
  findViewById(R.id.stop).setOnClickListener(v->stopService(new Intent(this,CaptureService.class)));
  findViewById(R.id.save).setOnClickListener(v->saveResult()); }
 private void startCapture(){ if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;} MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); startActivityForResult(m.createScreenCaptureIntent(),CAPTURE); }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==CAPTURE&&c==RESULT_OK&&d!=null){Intent s=new Intent(this,CaptureService.class);s.putExtra("resultCode",c);s.putExtra("data",d);if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);}}
 private void saveResult(){try{double c=Double.parseDouble(cost.getText().toString()),r=Double.parseDouble(ret.getText().toString());double n=p.getInt("n",0)+1,sumC=Double.longBitsToDouble(p.getLong("sumC",Double.doubleToLongBits(0)))+c,sumR=Double.longBitsToDouble(p.getLong("sumR",Double.doubleToLongBits(0)))+r;p.edit().putInt("n",(int)n).putLong("sumC",Double.doubleToLongBits(sumC)).putLong("sumR",Double.doubleToLongBits(sumR)).apply();cost.setText("");ret.setText("");refresh();}catch(Exception e){Toast.makeText(this,"اكتب أرقام التكلفة والعائد",Toast.LENGTH_SHORT).show();}}
 private void refresh(){int n=p.getInt("n",0);double c=Double.longBitsToDouble(p.getLong("sumC",Double.doubleToLongBits(0))),r=Double.longBitsToDouble(p.getLong("sumR",Double.doubleToLongBits(0)));double net=r-c;double ratio=c==0?0:r/c*100;String s=String.format(Locale.US,"الجولات المسجلة: %d\nإجمالي التكلفة: %.0f\nإجمالي العائد: %.0f\nصافي تاريخي: %.0f\nنسبة العائد إلى التكلفة: %.1f%%\n\n%s",n,c,r,net,ratio, n<5?"🟡 بيانات قليلة":(net>0?"🟢 المؤشر التاريخي موجب":"🔴 المؤشر التاريخي سالب"));stats.setText(s);}
}
