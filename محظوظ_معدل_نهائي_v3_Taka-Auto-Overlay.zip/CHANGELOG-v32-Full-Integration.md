# محظوظ v32 — Full requested integration

تم دمج طبقات الإضافات المطلوبة فوق قاعدة v31.9 بدلاً من استبدال المكونات السابقة.

## Included
- Universal Game Router: OCR + green/yellow marker evidence + lightweight visual fingerprint + two-frame stabilization.
- Lucky Gifts, card, dragon/tiger, baccarat, poker/Texas, dice/Sic Bo/Ludo, wheel/roulette, crash/multiplier, table, instant/arcade and sports profiles.
- Deep Chain Patterns: observed 2-step/3-step chains and the last observed 5-step chain.
- Dynamic risk stepper: virtual recovery progression and virtual Anti-Martingale progression driven only by explicitly OCR-observed win/loss words.
- Zero-Second Timing Monitor: visible countdown parsing and near-zero display state; informational only.
- server_pool_estimate observational index already present and retained; it is explicitly not a server-money estimate.
- Existing MartingaleManager and VirtualBettingMode retained for compatibility; they remain local/read-only and do not submit wagers.
- Existing OCR filter, OpenCV/template matching, green/yellow relationship learning, persistent history, flat hit log, sequence memory, Apriori, grid/rules, atomic/bitmask, performance layers and overlay resizing/dragging retained.

## Boundary
No automated taps, wager submission, process injection, private game memory access, traffic interception, TLS bypass, or claims of guaranteed future outcomes are added.
