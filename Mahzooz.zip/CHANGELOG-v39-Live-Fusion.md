# v39 — Live Fusion

- Fused Android MediaProjection screen stream with OpenCV optical flow and template matching.
- Added Arabic+English Tesseract OCR fallback alongside ML Kit OCR.
- CI fetches offline `ara.traineddata` and `eng.traineddata`; runtime OCR stays local and does not save screenshots.
- Taka routing no longer depends exclusively on the accessibility foreground-package event; it uses multiple visual/text cues as a fallback.
- Wired Markov transition ranking and existing history prediction into the observed-analysis pipeline.
- Desktop companion now uses MSS by default and offers Tesseract/EasyOCR diagnostics; PyAutoGUI is not used for game control.
- Version 8.9.0 / build 39.
