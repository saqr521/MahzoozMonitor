package com.mahzooz.monitor;

import android.graphics.Bitmap;
import androidx.palette.graphics.Palette;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

/**
 * Universal, read-only game fingerprint router.
 *
 * The router combines:
 *  - OCR keywords (Arabic + English and common transliterations)
 *  - green/yellow marker evidence used by the Mahzooz gift UI
 *  - lightweight visual/layout fingerprints from the captured frame
 *  - temporal hysteresis so one noisy frame cannot switch the analysis mode
 *
 * It only selects an analysis profile. It never clicks, places a wager,
 * changes a stake, or controls the target application.
 */
public final class GameRouter {

    public enum GameMode {
        LUCKY_GIFTS,
        CARD_GAMES,
        DRAGON_TIGER,
        BACCARAT,
        POKER,
        DICE_GAMES,
        DICE_GAME,          // compatibility alias
        WHEEL_ROULETTE,
        ROULETTE,
        CRASH_GAMES,
        CRASH_GAME,
        TABLE_GAMES,
        ARCADE_INSTANT,
        SPORTS_GAMES,
        UNKNOWN
    }

    public static final class Fingerprint {
        public final GameMode mode;
        public final int confidence;
        public final String evidence;
        public final boolean stable;

        Fingerprint(GameMode mode, int confidence, String evidence, boolean stable) {
            this.mode = mode;
            this.confidence = confidence;
            this.evidence = evidence;
            this.stable = stable;
        }
    }

    private static final int MIN_SWITCH_CONFIDENCE = 42;
    private static final int MIN_STABLE_FRAMES = 2;
    private static final int HISTORY_SIZE = 5;

    private GameMode currentMode = GameMode.UNKNOWN;
    private long lastChangeAt = 0L;
    private int candidateStreak = 0;
    private GameMode candidate = GameMode.UNKNOWN;
    private int lastConfidence = 0;
    private String lastEvidence = "";
    private final Deque<GameMode> recentModes = new ArrayDeque<>();

    /**
     * Backward-compatible entry point used by older builds.
     */
    public synchronized GameMode detect(String fullScreenText, String croppedText,
                                         int greenCount, int yellowCount) {
        return detectInternal(fullScreenText, croppedText, greenCount, yellowCount,
                0, 0, 0f, 0f, 0f, 0xFF000000).mode;
    }

    /**
     * Preferred entry point. Visual values are deliberately lightweight so
     * routing remains fast on a phone.
     */
    public synchronized GameMode detect(Bitmap frame, String fullScreenText,
                                         String croppedText, int greenCount,
                                         int yellowCount) {
        Visual v = visualFingerprint(frame);
        int dominantColor = 0xFF000000;
        try {
            Palette palette = Palette.from(frame).generate();
            dominantColor = palette.getDominantColor(dominantColor);
        } catch (Throwable ignored) { }
        return detectInternal(fullScreenText, croppedText, greenCount, yellowCount,
                v.width, v.height, v.edgeDensity, v.roundness, v.saturation, dominantColor).mode;
    }

    public synchronized Fingerprint fingerprint(Bitmap frame, String fullScreenText,
                                                  String croppedText, int greenCount,
                                                  int yellowCount) {
        Visual v = visualFingerprint(frame);
        int dominantColor = 0xFF000000;
        try {
            Palette palette = Palette.from(frame).generate();
            dominantColor = palette.getDominantColor(dominantColor);
        } catch (Throwable ignored) { }
        return detectInternal(fullScreenText, croppedText, greenCount, yellowCount,
                v.width, v.height, v.edgeDensity, v.roundness, v.saturation, dominantColor);
    }

    private Fingerprint detectInternal(String fullScreenText, String croppedText,
                                       int greenCount, int yellowCount,
                                       int width, int height,
                                       float edgeDensity, float roundness,
                                       float saturation, int dominantColor) {
        String text = ((fullScreenText == null ? "" : fullScreenText) + " " +
                (croppedText == null ? "" : croppedText)).toLowerCase(Locale.ROOT);

        Scores scores = new Scores();
        scoreText(text, scores);
        if (TakaGameKnowledge.hasVerifiedWheelEvidence(text)) {
            scores.add(GameMode.WHEEL_ROULETTE, 86, "بصمة Taka مؤكدة: Lucky Wheel");
        } else if (TakaGameKnowledge.hasVerifiedResultEvidence(text)) {
            scores.add(GameMode.TABLE_GAMES, 24, "واجهة نتائج Taka");
        } else if (TakaGameKnowledge.hasVerifiedGameUiEvidence(text)) {
            scores.add(GameMode.TABLE_GAMES, 18, "واجهة ألعاب Taka");
        }
        scoreVisual(scores, width, height, edgeDensity, roundness, saturation);
        scorePalette(scores, dominantColor);

        // Strong Mahzooz gift fingerprint: the green/yellow inventory markers
        // are more reliable than a generic word such as "gift".
        if (greenCount > 0 && yellowCount > 0) {
            scores.add(GameMode.LUCKY_GIFTS, 34, "علامات أخضر+أصفر");
        } else if (greenCount > 0) {
            scores.add(GameMode.LUCKY_GIFTS, 12, "علامة أخضر");
        } else if (yellowCount > 0) {
            scores.add(GameMode.LUCKY_GIFTS, 10, "علامة أصفر");
        }

        GameMode detected = scores.bestMode();
        int confidence = scores.bestScore();
        String evidence = scores.bestEvidence();

        // Do not force a random game mode from weak visual noise.
        if (confidence < MIN_SWITCH_CONFIDENCE) detected = GameMode.UNKNOWN;

        if (detected == candidate) {
            candidateStreak++;
        } else {
            candidate = detected;
            candidateStreak = 1;
        }

        // Keep the current profile while a single weak frame is inconclusive.
        if (candidateStreak >= MIN_STABLE_FRAMES &&
                candidate != currentMode &&
                (candidate == GameMode.UNKNOWN || confidence >= MIN_SWITCH_CONFIDENCE)) {
            currentMode = candidate;
            lastChangeAt = System.currentTimeMillis();
            recentModes.addLast(currentMode);
            while (recentModes.size() > HISTORY_SIZE) recentModes.removeFirst();
        }

        lastConfidence = confidence;
        lastEvidence = evidence == null ? "" : evidence;
        return new Fingerprint(currentMode, lastConfidence, lastEvidence,
                candidateStreak >= MIN_STABLE_FRAMES);
    }

    private void scoreText(String t, Scores s) {
        // Lucky gifts / chest / gift rooms
        if (containsAny(t, "lucky gift", "lucky gifts", "lucky", "gift",
                "chest", "treasure", "محظوظ", "المحظوظ", "هدايا الحظ",
                "هدايا المحظوظ", "هدية", "هدايا", "صندوق", "جوائز")) {
            s.add(GameMode.LUCKY_GIFTS, 55, "نص هدايا/محظوظ");
        }

        // Dragon / Tiger and related card-table variants
        if (containsAny(t, "dragon tiger", "dragon", "tiger",
                "تنين", "التنين", "نمر", "النمر")) {
            s.add(GameMode.DRAGON_TIGER, 72, "نص تنين/نمر");
            s.add(GameMode.CARD_GAMES, 28, "واجهة ورق");
        }

        if (containsAny(t, "baccarat", "บาคาร่า", "baccara")) {
            s.add(GameMode.BACCARAT, 76, "نص باكارات");
            s.add(GameMode.CARD_GAMES, 28, "واجهة ورق");
        }

        if (containsAny(t, "poker", "texas holdem", "texas hold'em",
                "بوكر", "تكساس", "holdem")) {
            s.add(GameMode.POKER, 76, "نص بوكر/تكساس");
            s.add(GameMode.CARD_GAMES, 30, "واجهة ورق");
        }

        if (containsAny(t, "card", "cards", "blackjack", "21", "ورق", "كروت",
                "بطاقات", "بلاك جاك")) {
            s.add(GameMode.CARD_GAMES, 54, "نص لعبة ورق");
        }

        // Dice / Sic Bo / Ludo
        if (containsAny(t, "dice", "sicbo", "sic bo", "ludo",
                "نرد", "سيكبو", "sicبو", "لودو", "حجر الحظ", "حجر")) {
            s.add(GameMode.DICE_GAMES, 70, "نص نرد/سيكبو/لودو");
        }

        // Wheel / roulette / spin
        if (containsAny(t, "wheel", "roulette", "spin", "lucky wheel",
                "روليت", "العجلة", "عجلة الحظ", "دوران", "تدوير", "لف")) {
            s.add(GameMode.WHEEL_ROULETTE, 70, "نص عجلة/روليت");
            if (containsAny(t, "roulette", "روليت")) {
                s.add(GameMode.ROULETTE, 80, "نص روليت");
            }
        }

        // Crash / multiplier / rocket
        if (containsAny(t, "crash", "crash game", "rocket", "multiplier",
                "cash out", "cashout", "fly", "aviator",
                "صاروخ", "طيارة", "الطيارة", "مضاعف", "إقلاع", "انسحاب")) {
            s.add(GameMode.CRASH_GAMES, 68, "نص كراش/مضاعف");
        }

        // Generic table/casino vocabulary
        if (containsAny(t, "casino", "table", "dealer", "bet", "stake",
                "طاولة", "كازينو", "موزع", "رهان")) {
            s.add(GameMode.TABLE_GAMES, 34, "نص طاولة/كازينو");
        }

        // Generic instant/arcade vocabulary
        if (containsAny(t, "instant", "arcade", "jackpot", "tap to play",
                "فوري", "أركيد", "جائزة كبرى", "اضغط للعب")) {
            s.add(GameMode.ARCADE_INSTANT, 48, "نص لعبة فورية");
        }

        if (containsAny(t, "football", "soccer", "basketball", "tennis",
                "كرة القدم", "كرة السلة", "تنس", "sports")) {
            s.add(GameMode.SPORTS_GAMES, 64, "نص رياضة");
        }
    }

    private void scoreVisual(Scores s, int width, int height,
                             float edgeDensity, float roundness,
                             float saturation) {
        if (width <= 0 || height <= 0) return;

        float ratio = height == 0 ? 0f : (float) width / height;

        // Round/centrally concentrated interfaces are common in wheel/roulette
        // screens. This is only a weak tie-breaker; OCR remains dominant.
        if (roundness > 0.56f && ratio > 0.80f && ratio < 1.35f) {
            s.add(GameMode.WHEEL_ROULETTE, 18, "بصمة دائرية");
        }

        // Dense button/table layouts are weak evidence for table/card games.
        if (edgeDensity > 0.16f && saturation > 0.20f) {
            s.add(GameMode.TABLE_GAMES, 8, "كثافة واجهة");
            s.add(GameMode.CARD_GAMES, 6, "كثافة عناصر");
        }
    }


    /** Palette is only a secondary fingerprint; OCR/marker evidence remains primary. */
    private void scorePalette(Scores s, int color) {
        int r = android.graphics.Color.red(color);
        int g = android.graphics.Color.green(color);
        int b = android.graphics.Color.blue(color);
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float sat = max == 0 ? 0f : (max - min) / max;

        // Green-heavy table: weak roulette/table evidence.
        if (g > r * 1.15f && g > b * 1.10f && sat > 0.18f) {
            s.add(GameMode.WHEEL_ROULETTE, 12, "Palette أخضر للطاولة");
            s.add(GameMode.TABLE_GAMES, 6, "Palette أخضر");
        }
        // Blue/red split is a weak card-table fingerprint.
        if ((b > r * 1.20f && b > g * 1.05f) || (r > b * 1.20f && r > g * 1.05f)) {
            s.add(GameMode.CARD_GAMES, 5, "Palette طاولة ملونة");
        }
    }

    private static final class Scores {
        private final int[] score = new int[GameMode.values().length];
        private final String[] evidence = new String[GameMode.values().length];

        void add(GameMode m, int points, String why) {
            int i = m.ordinal();
            score[i] += points;
            if (evidence[i] == null || evidence[i].isEmpty()) evidence[i] = why;
            else evidence[i] += "، " + why;
        }

        GameMode bestMode() {
            int best = 0;
            int bestScore = 0;
            for (int i = 0; i < score.length; i++) {
                if (score[i] > bestScore) {
                    bestScore = score[i];
                    best = i;
                }
            }
            return GameMode.values()[best];
        }

        int bestScore() {
            int best = 0;
            for (int v : score) if (v > best) best = v;
            return best;
        }

        String bestEvidence() {
            GameMode m = bestMode();
            return evidence[m.ordinal()] == null ? "" : evidence[m.ordinal()];
        }
    }

    private static final class Visual {
        int width;
        int height;
        float edgeDensity;
        float roundness;
        float saturation;
    }

    /**
     * Small sampled fingerprint. No screenshots are written to storage.
     */
    private Visual visualFingerprint(Bitmap b) {
        Visual v = new Visual();
        if (b == null || b.isRecycled()) return v;
        v.width = b.getWidth();
        v.height = b.getHeight();

        int stepX = Math.max(1, v.width / 48);
        int stepY = Math.max(1, v.height / 48);
        int samples = 0;
        int edgeLike = 0;
        float satSum = 0f;
        float centerDark = 0f;
        float ringDark = 0f;
        int centerN = 0;
        int ringN = 0;

        int previousLum = -1;
        for (int y = 0; y < v.height; y += stepY) {
            for (int x = 0; x < v.width; x += stepX) {
                int c = b.getPixel(x, y);
                int r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
                int max = Math.max(r, Math.max(g, bl));
                int min = Math.min(r, Math.min(g, bl));
                int lum = (r * 30 + g * 59 + bl * 11) / 100;
                satSum += max == 0 ? 0f : (max - min) / (float) max;
                if (previousLum >= 0 && Math.abs(lum - previousLum) > 55) edgeLike++;
                previousLum = lum;
                samples++;

                float dx = (x - v.width * 0.5f) / Math.max(1f, v.width * 0.5f);
                float dy = (y - v.height * 0.5f) / Math.max(1f, v.height * 0.5f);
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d < 0.38f) {
                    centerN++;
                    centerDark += lum < 100 ? 1f : 0f;
                } else if (d > 0.62f && d < 0.92f) {
                    ringN++;
                    ringDark += lum < 100 ? 1f : 0f;
                }
            }
        }
        if (samples > 0) {
            v.edgeDensity = edgeLike / (float) samples;
            v.saturation = satSum / samples;
        }
        if (centerN > 0 && ringN > 0) {
            float c = centerDark / centerN;
            float r = ringDark / ringN;
            v.roundness = 1f - Math.abs(c - r);
        }
        return v;
    }

    private boolean containsAny(String text, String... values) {
        for (String v : values) if (text.contains(v)) return true;
        return false;
    }

    /** Accept a strong visual/text title detected by the fused OCR pipeline. */
    public synchronized void promote(GameMode mode, int confidence, String evidence) {
        if (mode == null || mode == GameMode.UNKNOWN) return;
        int c = Math.max(0, Math.min(100, confidence));
        if (c < 55) return;
        currentMode = mode;
        candidate = mode;
        candidateStreak = MIN_STABLE_FRAMES;
        lastConfidence = Math.max(lastConfidence, c);
        lastEvidence = evidence == null ? "" : evidence;
        lastChangeAt = System.currentTimeMillis();
        recentModes.addLast(mode);
        while (recentModes.size() > HISTORY_SIZE) recentModes.removeFirst();
    }

    public synchronized GameMode currentMode() { return currentMode; }
    public synchronized long lastChangeAt() { return lastChangeAt; }
    public synchronized int confidence() { return lastConfidence; }
    public synchronized String evidence() { return lastEvidence; }

    public String displayName() {
        switch (currentMode()) {
            case LUCKY_GIFTS: return "هدايا المحظوظ";
            case DRAGON_TIGER: return "التنين والنمر";
            case BACCARAT: return "باكارات";
            case POKER: return "بوكر / تكساس";
            case CARD_GAMES: return "ألعاب الورق";
            case DICE_GAMES:
            case DICE_GAME: return "النرد / سيكبو / لودو";
            case ROULETTE:
            case WHEEL_ROULETTE: return "العجلة / الروليت";
            case CRASH_GAMES:
            case CRASH_GAME: return "ألعاب كراش / مضاعف";
            case TABLE_GAMES: return "ألعاب الطاولة";
            case ARCADE_INSTANT: return "ألعاب فورية / أركيد";
            case SPORTS_GAMES: return "ألعاب رياضية";
            default: return "غير محددة";
        }
    }

    public String statusLine() {
        String base = "وضع اللعبة التلقائي: " + displayName();
        if (confidence() > 0) base += " | ثقة التعرف: " + confidence() + "%";
        if (!evidence().isEmpty()) base += " | بصمة: " + evidence();
        return base;
    }
}
