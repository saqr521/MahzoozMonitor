package com.mahzooz.monitor;

/** NumPy-style vectorized primitives implemented with Android/Java primitive arrays. */
public final class VectorizedMath {
    private VectorizedMath() {}

    public static float mean(float[] a) {
        if (a == null || a.length == 0) return 0f;
        double sum = 0.0;
        for (float v : a) sum += v;
        return (float)(sum / a.length);
    }

    public static float meanAbsDelta(float[] a, float[] b) {
        if (a == null || b == null) return 0f;
        int n = Math.min(a.length, b.length);
        if (n == 0) return 0f;
        double sum = 0.0;
        for (int i = 0; i < n; i++) sum += Math.abs(a[i] - b[i]);
        return (float)(sum / n);
    }

    public static void addInPlace(float[] dst, float[] src) {
        if (dst == null || src == null) return;
        int n = Math.min(dst.length, src.length);
        for (int i = 0; i < n; i++) dst[i] += src[i];
    }

    public static float dot(float[] a, float[] b) {
        if (a == null || b == null) return 0f;
        int n = Math.min(a.length, b.length);
        double sum = 0.0;
        for (int i = 0; i < n; i++) sum += (double)a[i] * b[i];
        return (float)sum;
    }
}
