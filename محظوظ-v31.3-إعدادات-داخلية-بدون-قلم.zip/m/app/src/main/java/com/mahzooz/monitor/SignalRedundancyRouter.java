package com.mahzooz.monitor;

import java.util.*;

/** Chooses the strongest available read-only signal without accessing private process memory. */
public final class SignalRedundancyRouter {
    public SignalObservation choose(List<SignalObservation> observations){
        if(observations==null||observations.isEmpty()) return null;
        SignalObservation best=null;
        for(SignalObservation x:observations) if(x!=null && (best==null || x.confidence>best.confidence)) best=x;
        return best;
    }
    public boolean allowsPrivateMemoryAccess(){return false;}
    public boolean allowsTrafficInterception(){return false;}
}
