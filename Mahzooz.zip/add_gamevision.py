from pathlib import Path
root=Path('/tmp/v43/app/src/main/java/com/mahzooz/monitor')
# insert DB methods/version
p=root/'HistoryDb.java'
s=p.read_text()
s=s.replace('super(c,"mahzooz_history.db",null,10);','super(c,"mahzooz_history.db",null,11);')
s=s.replace('d.execSQL("CREATE TABLE play_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, hit_no INTEGER NOT NULL, label TEXT NOT NULL, confidence REAL NOT NULL, next_label TEXT NOT NULL DEFAULT \'\', validation_pct INTEGER NOT NULL DEFAULT -1)");\n    }', 'd.execSQL("CREATE TABLE play_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_ms INTEGER NOT NULL, hit_no INTEGER NOT NULL, label TEXT NOT NULL, confidence REAL NOT NULL, next_label TEXT NOT NULL DEFAULT \'\', validation_pct INTEGER NOT NULL DEFAULT -1)");\n        d.execSQL("CREATE TABLE game_transitions(previous TEXT NOT NULL, next TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous,next))");\n    }')
needle='        if(oldV<10){\n'
# add upgrade after oldV<10 block by locating its closing before recordInteractionReference
marker='    public synchronized void recordInteractionReference('
insert='''        if(oldV<11){\n            d.execSQL("CREATE TABLE IF NOT EXISTS game_transitions(previous TEXT NOT NULL, next TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(previous,next))");\n        }\n    }\n\n'''
idx=s.index(marker)
# existing onUpgrade closes immediately before marker, so replace that closing brace
s=s[:idx]+insert+s[idx:]
# methods before recordInteractionReference
methods='''    /** Observed visual-symbol transition inside the selected live game region. */\n    public synchronized void observeGameTransition(String previous, String next){\n        if(previous==null||next==null||previous.isEmpty()||next.isEmpty()||previous.equals(next)) return;\n        getWritableDatabase().execSQL("INSERT INTO game_transitions(previous,next,hits) VALUES(?,?,1) ON CONFLICT(previous,next) DO UPDATE SET hits=hits+1",new Object[]{previous,next});\n    }\n\n    /** Ranked next symbols for the current visual symbol, based only on observed transitions. */\n    public synchronized List<String> rankedGameTransitions(String previous,int n){\n        ArrayList<String> out=new ArrayList<>();\n        if(previous==null||previous.isEmpty()) return out;\n        Cursor c=getReadableDatabase().rawQuery("SELECT next,hits FROM game_transitions WHERE previous=? ORDER BY hits DESC,next ASC LIMIT ?",new String[]{previous,String.valueOf(Math.max(1,n))});\n        Cursor tc=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(hits),0) FROM game_transitions WHERE previous=?",new String[]{previous});\n        int total=0; if(tc.moveToFirst()) total=tc.getInt(0); tc.close();\n        while(c.moveToNext()){ int hits=c.getInt(1); int pct=total>0?Math.round(100f*hits/total):0; out.add(c.getString(0)+"|"+pct+"|"+hits+"/"+total); }\n        c.close(); return out;\n    }\n\n    public synchronized int gameTransitionCount(){\n        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(hits),0) FROM game_transitions",null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n;\n    }\n\n'''
s=s.replace(marker,methods+marker)
p.write_text(s)

# create GamePlayVision
q=root/'GamePlayVision.java'
q.write_text(r'''package com.mahzooz.monitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.*;

/**
 * Read-only visual reader for the user-selected live-game rectangle.
 * It does not tap, send input, or use the area outside the selected rectangle.
 * The default Taka game board is treated as a 5x3 symbol grid; the detector
 * learns stable visual IDs from successive real frames and stores only symbol
 * transition counts, never screenshots.
 */
public final class GamePlayVision {
    public static final class Suggestion {
        public final String label; public final int confidencePct; public final int hits; public final int total;
        Suggestion(String l,int c,int h,int t){label=l;confidencePct=Math.max(0,Math.min(100,c));hits=h;total=t;}
    }
    public static final class Result {
        public final boolean gridDetected, stable;
        public final String currentLabel;
        public final int recognitionPct;
        public final List<Suggestion> suggestions;
        public final int changedCells;
        Result(boolean gd,boolean st,String cl,int rp,List<Suggestion> ss,int cc){gridDetected=gd;stable=st;currentLabel=cl;recognitionPct=rp;suggestions=ss;changedCells=cc;}
    }

    private static final int COLS=5, ROWS=3;
    private final SharedPreferences prefs;
    private final List<Prototype> prototypes=new ArrayList<>();
    private String lastCandidate="";
    private int stableFrames=0;
    private String committed="";
    private String[] committedCells=null;
    private String lastTrigger="";
    private long lastCommitMs=0;

    private static final class Prototype { String label; long hash; Prototype(String l,long h){label=l;hash=h;} }

    public GamePlayVision(Context c){
        prefs=c.getApplicationContext().getSharedPreferences("game_visual_symbols",Context.MODE_PRIVATE);
        load();
    }

    public synchronized Result analyze(Bitmap b, HistoryDb db, long nowMs){
        if(b==null||b.isRecycled()||b.getWidth()<240||b.getHeight()<140)
            return new Result(false,false,"",0,Collections.emptyList(),0);
        // The selected rectangle should contain the actual reel/board, not the entire screen.
        float ratio=b.getWidth()/(float)Math.max(1,b.getHeight());
        if(ratio<1.05f || ratio>2.35f) return new Result(false,false,"",0,Collections.emptyList(),0);

        String[] cells=new String[ROWS*COLS];
        int recognized=0;
        for(int row=0;row<ROWS;row++){
            for(int col=0;col<COLS;col++){
                Rect r=cellRect(b,row,col);
                long h=normalizedHash(b,r);
                String label=labelFor(h);
                cells[row*COLS+col]=label;
                if(!label.isEmpty()) recognized++;
            }
        }
        String sig=String.join(";",cells);
        if(sig.equals(lastCandidate)) stableFrames++; else {lastCandidate=sig;stableFrames=1;}

        int changed=0;
        String trigger="";
        if(stableFrames>=2 && !sig.equals(committed)){
            if(committedCells!=null){
                for(int i=0;i<cells.length;i++){
                    String old=committedCells[i], now=cells[i];
                    if(!now.isEmpty()&&!now.equals(old)){
                        changed++;
                        if(trigger.isEmpty()) trigger=now;
                        if(old!=null&&!old.isEmpty()) db.observeGameTransition(old,now);
                    }
                }
            } else {
                // First stable board is a baseline, not a fake hit.
                for(String x:cells) if(!x.isEmpty()){trigger=x;break;}
            }
            committed=sig;
            committedCells=cells.clone();
            lastCommitMs=nowMs;
            if(!trigger.isEmpty()) lastTrigger=trigger;
        }

        if(trigger.isEmpty()) trigger=lastTrigger;
        if(trigger.isEmpty()) trigger=cells[(ROWS/2)*COLS+(COLS/2)];

        List<Suggestion> suggestions=new ArrayList<>();
        if(trigger!=null&&!trigger.isEmpty()){
            for(String row:db.rankedGameTransitions(trigger,5)){
                String[] p=row.split("\\|",-1); if(p.length<3) continue;
                try{String[] ht=p[2].split("/",2); int h=Integer.parseInt(ht[0]),t=Integer.parseInt(ht[1]); suggestions.add(new Suggestion(p[0],Integer.parseInt(p[1]),h,t));}catch(Exception ignored){}
            }
        }
        int rec=Math.round(100f*recognized/(ROWS*COLS));
        if(rec<45) return new Result(true,stableFrames>=2,trigger,rec,Collections.emptyList(),changed);
        return new Result(true,stableFrames>=2,trigger,rec,suggestions,changed);
    }

    private Rect cellRect(Bitmap b,int row,int col){
        // Ignore the outer border and crossing lines. Inner area is used for hashing.
        int left=Math.round(b.getWidth()*0.04f), top=Math.round(b.getHeight()*0.04f);
        int right=Math.round(b.getWidth()*0.96f), bottom=Math.round(b.getHeight()*0.94f);
        int cw=(right-left)/COLS, ch=(bottom-top)/ROWS;
        int x=left+col*cw, y=top+row*ch;
        int padX=Math.max(2,Math.round(cw*.12f)), padY=Math.max(2,Math.round(ch*.12f));
        return new Rect(x+padX,y+padY,Math.min(right,x+cw-padX),Math.min(bottom,y+ch-padY));
    }

    private long normalizedHash(Bitmap b,Rect r){
        final int N=8; double[] g=new double[N*N]; double mean=0;
        for(int y=0;y<N;y++) for(int x=0;x<N;x++){
            int sx=r.left+(x*r.width())/N, sy=r.top+(y*r.height())/N;
            int c=b.getPixel(Math.max(0,Math.min(b.getWidth()-1,sx)),Math.max(0,Math.min(b.getHeight()-1,sy)));
            // Lightly suppress very dark board background while preserving icon shape.
            double v=.299*Color.red(c)+.587*Color.green(c)+.114*Color.blue(c); g[y*N+x]=v; mean+=v;
        }
        mean/=g.length; long h=0;
        for(int i=0;i<g.length;i++) if(g[i]>=mean) h|=(1L<<i);
        return h;
    }

    private String labelFor(long hash){
        if(hash==0) return "";
        int bestDist=65; String best="";
        for(Prototype p:prototypes){int d=Long.bitCount(hash^p.hash); if(d<bestDist){bestDist=d;best=p.label;}}
        // Require a strong visual match before reusing an ID.
        if(bestDist<=12) return best;
        String label="رمز-"+String.format(Locale.US,"%08X",hash & 0xffffffffL);
        prototypes.add(new Prototype(label,hash));
        save();
        return label;
    }

    private void load(){
        String raw=prefs.getString("prototypes",""); if(raw.isEmpty()) return;
        for(String line:raw.split("\\n")){
            String[] p=line.split("\\|",2); if(p.length!=2) continue;
            try{prototypes.add(new Prototype(p[0],Long.parseUnsignedLong(p[1])));}catch(Exception ignored){}
        }
    }
    private void save(){
        StringBuilder s=new StringBuilder();
        int n=0; for(Prototype p:prototypes){if(n++>=120)break; s.append(p.label).append('|').append(Long.toUnsignedString(p.hash)).append('\\n');}
        prefs.edit().putString("prototypes",s.toString()).apply();
    }
}
''')

# modify Analyzer
p=root/'Analyzer.java'; s=p.read_text()
s=s.replace('private final GameSignalEngine gameSignalEngine;','private final GameSignalEngine gameSignalEngine;\n    private final GamePlayVision gamePlayVision;\n    private GamePlayVision.Result latestGameVision = null;')
s=s.replace('zeroSecondTimingMonitor=new ZeroSecondTimingMonitor(); gameSignalEngine=new GameSignalEngine();','zeroSecondTimingMonitor=new ZeroSecondTimingMonitor(); gameSignalEngine=new GameSignalEngine(); gamePlayVision=new GamePlayVision(c);')
# after visionBmp crop, analyze game region
needle='        Bitmap visionBmp = cropConfiguredReadRegion(bmp);\n'
repl=needle+'        // Live-game reader uses only the user-selected rectangle. It learns visual symbol IDs\n        // from real frames and updates observed transitions automatically.\n        latestGameVision = gamePlayVision.analyze(visionBmp, db, timestampMs);\n'
s=s.replace(needle,repl,1)
# replace compact panel initial portion and internal section additions
old='''        b.append("الضربة الحالية: ").append(latestObservedPlayLabel.isEmpty() ? "غير مقروءة بعد" : latestObservedPlayLabel).append('\\n');\n        if (!latestObservedOutcome.isEmpty()) b.append("النتيجة الظاهرة الآن: ").append(latestObservedOutcome).append('\\n');\n'''
new='''        if (latestGameVision != null && latestGameVision.gridDetected) {\n            b.append("اللعب الحالي — القراءة من المربع المحدد\\n");\n            b.append("حالة الشبكة: ").append(latestGameVision.stable ? "ثابتة" : "جارٍ التثبيت")\n             .append(" | تعرف الرموز: ").append(latestGameVision.recognitionPct).append("%\\n");\n            b.append("الضربة الحالية: ").append(latestGameVision.currentLabel.isEmpty() ? "غير محددة" : latestGameVision.currentLabel).append('\\n');\n            appendLiveHitSuggestions(b, latestGameVision);\n        } else {\n            b.append("الضربة الحالية: ").append(latestObservedPlayLabel.isEmpty() ? "غير مقروءة بعد" : latestObservedPlayLabel).append('\\n');\n        }\n        if (!latestObservedOutcome.isEmpty()) b.append("النتيجة الظاهرة الآن: ").append(latestObservedOutcome).append('\\n');\n'''
if old not in s: print('old panel snippet not found')
s=s.replace(old,new,1)
# add helper before appendMahzoozRelations
marker='    private void appendMahzoozRelations(StringBuilder b) {'
helper='''    private void appendLiveHitSuggestions(StringBuilder b, GamePlayVision.Result v) {\n        if (v == null || v.suggestions == null || v.suggestions.isEmpty()) {\n            b.append("الضربات المقترحة: لا توجد سلسلة مرصودة كافية بعد\\n");\n            return;\n        }\n        b.append("الضربات المقترحة من السجل المرصود:\\n");\n        int n=Math.min(5,v.suggestions.size());\n        for(int i=0;i<n;i++){\n            GamePlayVision.Suggestion x=v.suggestions.get(i);\n            b.append("ضربة ").append(i+1).append(": ").append(x.label)\n             .append(" | ").append(x.confidencePct).append("% | ")\n             .append(x.hits).append('/').append(x.total).append(" مشاهدة\\n");\n        }\n    }\n\n'''
s=s.replace(marker,helper+marker,1)
p.write_text(s)

# overlay text: make live area prominent and keep current game content
p=Path('/tmp/v43/app/src/main/res/layout/overlay_layout.xml'); s=p.read_text()
s=s.replace('android:textSize="13sp"','android:textSize="14sp"',1)
p.write_text(s)

# bump version
p=Path('/tmp/v43/app/build.gradle.kts'); s=p.read_text().replace('versionCode = 43','versionCode = 44').replace('versionName = "8.9.4-live-region-and-play-panel"','versionName = "8.9.5-live-region-sequential-hits"'); p.write_text(s)
