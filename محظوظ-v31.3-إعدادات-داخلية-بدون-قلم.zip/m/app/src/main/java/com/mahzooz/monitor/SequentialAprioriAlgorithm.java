package com.mahzooz.monitor;

import java.util.*;

/**
 * Small sequential-Apriori style miner. It finds repeated ordered subsequences
 * in the analyzer's observed state history; it never fabricates unseen states.
 */
public final class SequentialAprioriAlgorithm {
    public static final class Pattern { public final List<String> items; public final int support; Pattern(List<String> i,int s){items=i;support=s;} }

    public List<Pattern> mine(List<String> sequences,int maxLength,int minSupport,int limit){
        ArrayList<Pattern> out=new ArrayList<>();
        if(sequences==null||sequences.isEmpty()) return out;
        int max=Math.max(1,Math.min(maxLength,4)), min=Math.max(1,minSupport);
        Map<List<String>,Integer> counts=new HashMap<>();
        for(int start=0;start<sequences.size();start++){
            LinkedHashSet<String> seen=new LinkedHashSet<>();
            for(int len=1;len<=max && start+len<=sequences.size();len++){
                String s=sequences.get(start+len-1); if(s==null||s.isEmpty()) continue;
                seen.add(s);
                ArrayList<String> key=new ArrayList<>(seen);
                counts.put(key,counts.containsKey(key)?counts.get(key)+1:1);
            }
        }
        ArrayList<Map.Entry<List<String>,Integer>> entries=new ArrayList<>(counts.entrySet());
        entries.removeIf(e->e.getValue()<min);
        Collections.sort(entries,(a,b)->{int d=Integer.compare(b.getValue(),a.getValue());return d!=0?d:Integer.compare(a.getKey().size(),b.getKey().size());});
        for(Map.Entry<List<String>,Integer> e:entries){out.add(new Pattern(Collections.unmodifiableList(e.getKey()),e.getValue()));if(out.size()>=Math.max(1,limit))break;}
        return out;
    }

    public static String format(List<Pattern> patterns){
        if(patterns==null||patterns.isEmpty()) return "Apriori=لا توجد أنماط متكررة كافية";
        StringBuilder s=new StringBuilder("Apriori=");
        for(int i=0;i<patterns.size();i++){if(i>0)s.append(" | ");Pattern p=patterns.get(i);s.append(p.items).append(" x").append(p.support);}
        return s.toString();
    }
}
