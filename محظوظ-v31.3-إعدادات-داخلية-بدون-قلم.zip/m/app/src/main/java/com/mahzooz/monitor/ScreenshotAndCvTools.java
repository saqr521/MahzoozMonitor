package com.mahzooz.monitor;

import android.graphics.Bitmap;

/** One safe facade for screenshot, OpenCV and optical-flow capabilities. */
public final class ScreenshotAndCvTools {
    private final OpenCvVisionEngine cv = new OpenCvVisionEngine();

    public boolean openCvAvailable() { return cv.isAvailable(); }
    public float opticalFlow(Bitmap bitmap) { return cv.opticalFlowMagnitude(bitmap); }

    public void reset() { cv.reset(); }
}
