package com.mahzooz.monitor;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Local observational sequence memory.
 *
 * It records what was actually observed on screen. It intentionally does not
 * claim to predict future game outcomes or provide a wagering recommendation.
 */
final class DeepChainHistoryTracker {
    private static final int MAX_HISTORY = 120;
    private final ArrayDeque<String> history = new ArrayDeque<>();

    synchronized void observe(String label) {
        if (label == null) return;
        label = label.trim();
        if (label.isEmpty() || "غير معروف".equals(label)) return;
        if (label.equals(history.peekLast())) return;
        history.addLast(label);
        while (history.size() > MAX_HISTORY) history.removeFirst();
    }

    synchronized List<String> lastObserved(int count) {
        ArrayList<String> out = new ArrayList<>();
        if (count <= 0) return out;
        int skip = Math.max(0, history.size() - count);
        int i = 0;
        for (String s : history) {
            if (i++ >= skip) out.add(s);
        }
        return out;
    }

    synchronized String summary5() {
        List<String> last = lastObserved(5);
        if (last.isEmpty()) return "السلسلة المرصودة: لا توجد بيانات كافية";
        StringBuilder b = new StringBuilder("آخر 5 خطوات مرصودة: ");
        for (int i = 0; i < last.size(); i++) {
            if (i > 0) b.append(" ← ");
            b.append(last.get(i));
        }
        return b.toString();
    }

    synchronized void clear() {
        history.clear();
    }
}
