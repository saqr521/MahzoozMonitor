# Mahzooz Vision Companion

This is the desktop validation side of the same live-fusion design:

`MSS screen stream -> OpenCV optical flow -> Tesseract/EasyOCR -> Taka scene routing -> template check -> Markov observed transitions`

`PyAutoGUI` remains an optional dependency for compatibility only. This project never clicks, types, drags or places bets through PyAutoGUI.

The Android runtime does not depend on Python. On Android the equivalent pipeline is:

`MediaProjection -> overlay masking -> OpenCV -> ML Kit + Tesseract -> Taka room/internal-game routing -> gift-marker validation -> seeded image catalog -> history/sequence -> Markov -> overlay`

The supplied `mahzooz_templates.jpg` is copied into Android assets and is also available to the desktop diagnostics.

Examples:

```bash
python screenshot_cv.py
python screenshot_cv.py --ocr tesseract
python screenshot_cv.py --ocr easyocr
python screenshot_cv.py --ocr tesseract --templates ../../app/src/main/assets/mahzooz_templates.jpg
python screenshot_cv.py --ocr tesseract --save
```

Diagnostic frames are saved only when `--save` is explicitly supplied.
