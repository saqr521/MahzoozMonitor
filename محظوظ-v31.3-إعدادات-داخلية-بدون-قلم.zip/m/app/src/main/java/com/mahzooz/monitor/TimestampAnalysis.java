package com.mahzooz.monitor;

/** Wall-clock + monotonic timestamp pairing for reliable event ordering. */
public final class TimestampAnalysis {
    public final long wallClockMs;
    public final long monotonicNs;
    public TimestampAnalysis(){ this(System.currentTimeMillis(),System.nanoTime()); }
    public TimestampAnalysis(long wallClockMs,long monotonicNs){this.wallClockMs=wallClockMs;this.monotonicNs=monotonicNs;}
    public long elapsedNs(TimestampAnalysis earlier){
        if(earlier==null)return 0;
        return Math.max(0L,monotonicNs-earlier.monotonicNs);
    }
    public long elapsedMs(TimestampAnalysis earlier){return elapsedNs(earlier)/1_000_000L;}
}
