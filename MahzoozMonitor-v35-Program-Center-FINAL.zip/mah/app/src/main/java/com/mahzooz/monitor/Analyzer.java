package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.Bitmap;
import java.util.*;

public class Analyzer {
    private final TemplateRepository templates;
    private final HistoryDb db;
    private final SystemLearner learner;
    private final AnalyticsEngine analytics;
    private long lastFrameHash = 0;
    private String lastGreenSignature = "";
    private String lastYellowSignature = "";
    private final ReadOnlyEventMonitor readOnlyEventMonitor;
    private final WebSocketReadOnlyMonitor webSocketMonitor;
    private final EventCorrelationEngine correlationEngine;
    private final SignalRedundancyRouter signalRouter;
    private final OwnedTrafficMetadataMonitor trafficMetadataMonitor;
    private final SelfMemoryStateMonitor selfMemoryMonitor;
    private final FridaSafetyBoundary fridaBoundary;
    private final ScreenshotAndCvTools cvTools;
    private final ParallelProcessingEngine parallelEngine;
    private final HardwareAccelerationManager hardwareAcceleration;
    private final MultiprocessingBoundary multiprocessingBoundary;
    private final SequenceMemory sequenceMemory;
    private final MultiConditionRuleEngine ruleEngine;
    private final SequentialAprioriAlgorithm apriori;
    private final AtomicState atomicState;
    private final InteractionReferenceLearner interactionLearner;
    private final PrePlayDecisionEngine prePlayDecisionEngine;
    private final HitPlanEngine hitPlanEngine;
    private final PatternAnalyticsEngine patternAnalyticsEngine;
    private final OcrEngine ocrEngine;
    private final BettingSignalEngine bettingSignalEngine;
    private final ServerPatternMonitor serverPatternMonitor;
    private final VirtualBettingMode virtualBettingMode;
    private final DeepChainHistoryTracker deepChainTracker;
    private final ObservationalRiskTracker observationalRiskTracker;
    private final GameRouter gameRouter;
    private final DeepChainPatternEngine deepChainPatternEngine;
    private final DynamicRiskStepper dynamicRiskStepper;
    private final ZeroSecondTimingMonitor zeroSecondTimingMonitor;
    private final GameSignalEngine gameSignalEngine;
    // Relation-learning evidence is armed by a selected GREEN strip and is
    // completed only when a later inventory frame actually loses one or more
    // yellow items. This avoids the old reversed/overly-strict one-green/one-yellow rule.
    private String pendingRelationGreen = "";
    private String pendingRelationYellowBaseline = "";
    private long pendingRelationAt = 0L;

    // Filters repeated OCR frames so a real sequence stays consecutive and varied.
    private final ArrayDeque<String> filteredPlaySequence = new ArrayDeque<>();
    private String lastFilteredPlayLabel = "";

    public Analyzer(Context c){ templates=new TemplateRepository(c); db=new HistoryDb(c); learner=new SystemLearner(db); analytics=new AnalyticsEngine(); readOnlyEventMonitor=new ReadOnlyEventMonitor(db); webSocketMonitor=new WebSocketReadOnlyMonitor(db); correlationEngine=new EventCorrelationEngine(db); signalRouter=new SignalRedundancyRouter(); trafficMetadataMonitor=new OwnedTrafficMetadataMonitor(db); selfMemoryMonitor=new SelfMemoryStateMonitor(); fridaBoundary=new FridaSafetyBoundary(); cvTools=new ScreenshotAndCvTools(); parallelEngine=new ParallelProcessingEngine(); hardwareAcceleration=new HardwareAccelerationManager(cvTools.openCvAvailable()); multiprocessingBoundary=new MultiprocessingBoundary(); sequenceMemory=new SequenceMemory(120); ruleEngine=new MultiConditionRuleEngine(); apriori=new SequentialAprioriAlgorithm(); atomicState=new AtomicState(); interactionLearner=new InteractionReferenceLearner(); prePlayDecisionEngine=new PrePlayDecisionEngine(); hitPlanEngine=new HitPlanEngine(); patternAnalyticsEngine=new PatternAnalyticsEngine(); ocrEngine=new OcrEngine(c); bettingSignalEngine=new BettingSignalEngine(c); serverPatternMonitor=new ServerPatternMonitor(); virtualBettingMode=new VirtualBettingMode(c); deepChainTracker=new DeepChainHistoryTracker(); observationalRiskTracker=new ObservationalRiskTracker(); gameRouter=new GameRouter(); deepChainPatternEngine=new DeepChainPatternEngine(); dynamicRiskStepper=new DynamicRiskStepper(c); zeroSecondTimingMonitor=new ZeroSecondTimingMonitor(); gameSignalEngine=new GameSignalEngine(); }

    public synchronized AnalysisResult analyze(Bitmap bmp){
        final long analysisStartNs = HighResolutionTimer.nowNanos();
        final long timestampMs = System.currentTimeMillis();
        atomicState.recordFrame(timestampMs);
        // OCR is deliberately rate-limited independently from frame analysis.
        String ocrText = OcrSanitizer.clean(ocrEngine.readIfDue(bmp, timestampMs));
        List<Detector.Marker> g=Detector.findMarkers(bmp,true);
        List<Detector.Marker> y=Detector.findMarkers(bmp,false);
        sortMarkers(g); sortMarkers(y);
        GameRouter.GameMode gameMode = gameRouter.detect(bmp, ocrText, ocrText, g.size(), y.size());

        // Always run tile detection. Markers are badges; the tile below each badge
        // is the actual item name used for the learned relation map.
        // Every colored badge belongs to one inventory icon. Build the tile directly
        // from the badge position; this works for 4-column layouts and for rows that
        // move after a scroll instead of assuming a fixed six-column grid.
        List<Detector.Tile> greenItems=new ArrayList<>();
        for(Detector.Marker m:g) { Detector.Tile t=Detector.itemForMarker(bmp,m,templates); greenItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> yellowItems=new ArrayList<>();
        for(Detector.Marker m:y) { Detector.Tile t=Detector.itemForMarker(bmp,m,templates); yellowItems.add(t); templates.remember(t.label,t.hash); }
        List<Detector.Tile> tiles=new ArrayList<>();
        tiles.addAll(greenItems);
        for(Detector.Tile t:yellowItems){
            boolean dup=false;
            for(Detector.Tile e:tiles) if(!e.rect.isEmpty() && !t.rect.isEmpty() && centerDistance(e.rect,t.rect)<20){dup=true;break;}
            if(!dup) tiles.add(t);
        }

        String previousGreenSignature = lastGreenSignature;
        String previousYellowSignature = lastYellowSignature;
        String current=signature(greenItems);
        if (!greenItems.isEmpty()) {
            for (Detector.Tile t : greenItems) {
                if (t != null && t.label != null && !t.label.isEmpty() && !"غير معروف".equals(t.label)) {
                    deepChainTracker.observe(t.label);
                }
            }
        }
        sequenceMemory.observeState(current);
        String currentYellow=signature(yellowItems);
        ScreenStateDetector.State screenState = ScreenStateDetector.inspect(bmp,g,y);
        boolean inventoryVisible=!tiles.isEmpty() && (!g.isEmpty() || !y.isEmpty());
        InteractionReferenceLearner.Observation interaction=interactionLearner.observe(bmp,tiles,inventoryVisible,timestampMs);

        // Arm relation learning from an explicitly selected GREEN strip. The
        // yellow inventory is the baseline; we then wait for an actual visible
        // consumption/removal event instead of assuming that a page transition
        // itself proves a relation.
        String selectedNow = interactionLearner.pendingLabel();
        if (inventoryVisible && selectedNow != null && !selectedNow.isEmpty() &&
                labels(current).contains(selectedNow)) {
            if (!selectedNow.equals(pendingRelationGreen)) {
                pendingRelationGreen = selectedNow;
                pendingRelationYellowBaseline = currentYellow;
                pendingRelationAt = timestampMs;
            }
        }

        if(interaction!=null){
            db.recordInteractionReference(timestampMs,interaction.selectedLabel,interaction.beforeSignature,interaction.afterSignature,interaction.row,interaction.column,interaction.confidence);
            // One completed manual interaction is one real observed hit in the persistent chronological play log.
            // This is history only: the monitor never sends input to the game.
            db.recordPlayHit(interaction.selectedLabel, interaction.confidence, timestampMs);
            // Keep the separate evidence layer for exact observed hit plans; a single test is x1.
            db.observeHitPlan(interaction.selectedLabel,1,"icon-test",interaction.confidence);
            AlgorithmTrace.recordInteractionReference(interaction);
        }
        List<String> relations=buildRelations(greenItems,yellowItems,previousGreenSignature,previousYellowSignature,current,currentYellow,interaction);
        // Stronger live evidence path: selected green -> yellow item(s) visibly
        // disappear while the inventory remains on screen. Learn each consumed
        // yellow item once, and keep the evidence persistent in SQLite.
        if (inventoryVisible && !pendingRelationGreen.isEmpty() &&
                timestampMs - pendingRelationAt <= 12000L &&
                !pendingRelationYellowBaseline.isEmpty()) {
            Set<String> baselineY = labels(pendingRelationYellowBaseline);
            Set<String> nowY = labels(currentYellow);
            Set<String> consumed = new LinkedHashSet<>(baselineY);
            consumed.removeAll(nowY);
            if (!consumed.isEmpty()) {
                for (String yItem : consumed) {
                    db.observeRelation(pendingRelationGreen, yItem);
                    int hits=db.relationHits(pendingRelationGreen,yItem);
                    int total=db.relationTotal(pendingRelationGreen);
                    int pct=total>0?Math.round(100f*hits/total):0;
                    relations.add("🟩 "+pendingRelationGreen+" ← 🟨 "+yItem+" | نسبة الربط المرصودة: "+pct+"% ("+hits+"/"+total+")");
                }
                pendingRelationGreen = "";
                pendingRelationYellowBaseline = "";
                pendingRelationAt = 0L;
            }
        } else if (timestampMs - pendingRelationAt > 12000L) {
            pendingRelationGreen = "";
            pendingRelationYellowBaseline = "";
            pendingRelationAt = 0L;
        }
        String recommendation=updateAndRecommend(previousGreenSignature,current,interaction);
        gameSignalEngine.observe(gameMode, gameRouter.confidence(), ocrText, timestampMs);
        String routerStatus = gameRouter.statusLine();
        String signalDashboard = gameSignalEngine.dashboard();
        if (!signalDashboard.isEmpty()) recommendation = signalDashboard + (recommendation.isEmpty() ? "" : "\n" + recommendation);
        String referenceProfile = TakaReferenceCatalog.profileForText(ocrText);
        if (!"غير محدد".equals(referenceProfile) && gameMode == GameRouter.GameMode.UNKNOWN) {
            routerStatus = routerStatus + " | ملف مرجعي: " + referenceProfile;
        }
        recommendation = routerStatus + (recommendation.isEmpty() ? "" : "\n" + recommendation);
        // Add a neutral, local-only description of the observed history/OCR.
        // It deliberately does not produce a betting side or stake amount.
        PatternAnalyticsEngine.Report patternReport =
                patternAnalyticsEngine.analyze(filteredRecentPlayLabels(10), ocrText);
        if (patternReport != null && !patternReport.text.isEmpty()) {
            recommendation = patternReport.text + (recommendation.isEmpty() ? "" : "\n" + recommendation);
        }
        String nextObserved = firstNewLabel(previousGreenSignature, current);
        String predictionSource = !ocrText.isEmpty() ? firstRecognizedLabel(ocrText) : nextObserved;
        ServerPatternMonitor.Snapshot serverPattern = serverPatternMonitor.observe(ocrText, predictionSourceSafe(ocrText, nextObserved), timestampMs);
        if (serverPattern != null) recommendation += "\n\n" + serverPattern.format();
        // BettingSignalEngine is kept for compatibility with the existing project,
        // but its wager-direction output is not surfaced by the observational build.
        recommendation += "\n\n" + virtualBettingMode.summary();
        recommendation += "\n" + observationalRiskTracker.summary();

        // Observational replacement for future-chain prediction:
        // show only the last five items that were actually observed.
        recommendation += "\n\n" + deepChainTracker.summary5();
        dynamicRiskStepper.observe(ocrText);
        recommendation += "\n" + dynamicRiskStepper.snapshot().text;
        DeepChainPatternEngine.Report deepReport = deepChainPatternEngine.analyze(deepChainTracker.lastObserved(30));
        if (deepReport != null && !deepReport.text.isEmpty()) recommendation += "\n\n" + deepReport.text;
        ZeroSecondTimingMonitor.Snapshot timing = zeroSecondTimingMonitor.observe(ocrText);
        if (timing != null) recommendation += "\n" + timing.text;
        virtualBettingMode.observeOutcome(ocrText);
        SystemLearner.Snapshot model=learner.update(greenItems, recommendation);
        AlgorithmTrace.recordGameToMonitor(g, y, greenItems, yellowItems, relations);
        if(!recommendation.isEmpty()) AlgorithmTrace.recordMonitorOutput(recommendation);
        lastGreenSignature=current;
        lastYellowSignature=currentYellow;

        float[] channelMeans = parallelEngine.pixelChannelMeans(bmp);
        AlgorithmTrace.recordVisionMetric("Atomic/Bitmask", atomicState.summary() + " | flags=" +
                BitmaskLookupTables.describe(BitmaskLookupTables.mask(!g.isEmpty(), !y.isEmpty(), false, !tiles.isEmpty(), !relations.isEmpty())));
        AlgorithmTrace.recordVisionMetric("Parallel/Vectorized",
                parallelEngine.backendSummary() + " | RGBmean=" + channelMeans[0] + "," + channelMeans[1] + "," + channelMeans[2]);
        AlgorithmTrace.recordVisionMetric("Hardware", hardwareAcceleration.summary());
        AlgorithmTrace.recordVisionMetric("Multiprocessing", multiprocessingBoundary.status() + " | gameProcessHook=" + multiprocessingBoundary.attachesToGameProcess());

        long screenHash=Detector.phash(bmp,new Rect(0,0,bmp.getWidth(),bmp.getHeight()));
        String change=lastFrameHash==0?"بدء الرصد":(Long.bitCount(screenHash^lastFrameHash)>10?"تغير ملحوظ في الشاشة":"");
        lastFrameHash=screenHash;

        float confidence=.35f;
        if(!g.isEmpty()||!y.isEmpty()) confidence+=.20f;
        if(!tiles.isEmpty()) confidence+=.15f;
        if(!relations.isEmpty()) confidence+=.15f;
        if(!recommendation.isEmpty()) confidence+=.05f;
        confidence=Math.min(1f,confidence);
        String coordinates = buildCoordinates(g, y, greenItems, yellowItems, bmp.getWidth(), bmp.getHeight());
        float opticalFlow = cvTools.opticalFlow(bmp);
        sequenceMemory.observeNumbers(timestampMs, confidence, opticalFlow, greenItems.size(), yellowItems.size());
        if (opticalFlow > 0.35f) confidence = Math.min(1f, confidence + 0.05f);
        AlgorithmTrace.recordVisionMetric("OpenCV", "opticalFlow=" + opticalFlow + " available=" + cvTools.openCvAvailable());
        if(!ocrText.isEmpty()) AlgorithmTrace.recordVisionMetric("OCR", ocrText);
        AlgorithmTrace.recordVisionMetric("matchTemplate", "available=" + cvTools.openCvAvailable() + " | thresholded local template matching ready");
        AlgorithmTrace.recordVisionMetric("SequenceMemory", sequenceMemory.summary());
        AlgorithmTrace.recordVisionMetric("IconInteractionTraining", interactionLearner.status() + " | DB=" + db.interactionReferenceCount());
        List<GridMappingAnalysis.Cell> gridCells=GridMappingAnalysis.map(tiles);
        AlgorithmTrace.recordVisionMetric("GridMapping", GridMappingAnalysis.summary(gridCells));
        List<MultiConditionRuleEngine.Match> ruleMatches=ruleEngine.evaluate(greenItems,yellowItems,confidence,opticalFlow);
        if(!ruleMatches.isEmpty()) {
            StringBuilder rb=new StringBuilder();
            for(MultiConditionRuleEngine.Match m:ruleMatches){if(rb.length()>0) rb.append(" | "); rb.append(m.rule).append(": ").append(m.explanation);}
            AlgorithmTrace.recordVisionMetric("MultiConditionRules", rb.toString());
        }
        List<SequentialAprioriAlgorithm.Pattern> patterns=apriori.mine(sequenceMemory.recentStates(120),3,2,5);
        AlgorithmTrace.recordVisionMetric("SequentialApriori", SequentialAprioriAlgorithm.format(patterns));
        AlgorithmTrace.recordScreenState(screenState);
        List<ReadOnlyEventMonitor.Event> readOnlyEvents = readOnlyEventMonitor.observe(greenItems, yellowItems, screenState, timestampMs);
        correlationEngine.correlate(timestampMs, screenState.scene + "/" + screenState.lockState, readOnlyEvents);
        AnalysisResult result = new AnalysisResult(timestampMs,g,y,tiles,relations,recommendation,change,confidence,coordinates,screenState,ocrText);
        long elapsedNs = HighResolutionTimer.elapsedNanos(analysisStartNs);
        analytics.record(result,timestampMs,elapsedNs,previousGreenSignature,nextObserved);
        db.addAnalyticsSample(timestampMs,elapsedNs,g.size(),y.size(),confidence);
        return result;
    }

    private String predictionSourceSafe(String ocrText, String nextObserved) {
        if (ocrText != null && !ocrText.trim().isEmpty()) return firstRecognizedLabel(ocrText);
        return nextObserved == null ? "" : nextObserved;
    }

    public void close() { try { ocrEngine.close(); } catch (Throwable ignored) {} }
    public GameRouter.GameMode currentGameMode() { return gameRouter.currentMode(); }
    public String currentGameModeName() { return gameRouter.displayName(); }

    private static void sortMarkers(List<Detector.Marker> a){
        Collections.sort(a,(x,z)->{int d=Integer.compare(x.rect.top,z.rect.top);return d!=0?d:Integer.compare(x.rect.left,z.rect.left);});
    }

    private List<Detector.Tile> attachMarkersToTiles(List<Detector.Marker> markers,List<Detector.Tile> tiles,Bitmap bmp,TemplateRepository repo){
        ArrayList<Detector.Tile> out=new ArrayList<>();
        Set<Integer> used=new HashSet<>();
        for(Detector.Marker m:markers){
            double best=Double.MAX_VALUE; int bi=-1;
            double mx=(m.rect.left+m.rect.right)/2.0, my=(m.rect.top+m.rect.bottom)/2.0;
            for(int i=0;i<tiles.size();i++) if(!used.contains(i)){
                Rect r=tiles.get(i).rect;
                double tx=(r.left+r.right)/2.0, ty=(r.top+r.bottom)/2.0;
                // Badge normally sits near the upper-right of its tile.
                double dx=mx-tx, dy=my-ty;
                double d=Math.hypot(dx,dy);
                if(d<best && dy>-r.height()*0.75 && dy<r.height()*0.75) {best=d;bi=i;}
            }
            if(bi>=0 && best<Math.max(bmp.getWidth()/4.0,120)) {used.add(bi); out.add(tiles.get(bi));}
            else out.add(new Detector.Tile(new Rect(),0,"غير معروف",0));
        }
        return out;
    }

    private List<String> buildRelations(List<Detector.Tile> green,List<Detector.Tile> yellow,
                                         String previousGreen,String previousYellow,
                                         String currentGreen,String currentYellow,
                                         InteractionReferenceLearner.Observation interaction){
        ArrayList<String> out=new ArrayList<>();
        Set<String> beforeG=labels(previousGreen), nowG=labels(currentGreen);
        Set<String> beforeY=labels(previousYellow), nowY=labels(currentYellow);
        Set<String> newG=new LinkedHashSet<>(nowG); newG.removeAll(beforeG);
        Set<String> consumedY=new LinkedHashSet<>(beforeY); consumedY.removeAll(nowY);

        // Conservative fallback for a real one-green/one-yellow change. The
        // relation belongs to the GREEN strip that was visible before the change,
        // not the newly appearing strip.
        if(interaction!=null && consumedY.size()==1){
            String g = !beforeG.isEmpty() ? beforeG.iterator().next() : (newG.size()==1 ? newG.iterator().next() : "");
            if(!g.isEmpty()){
                String y=consumedY.iterator().next();
                db.observeRelation(g,y);
                int hits=db.relationHits(g,y), total=db.relationTotal(g);
                int pct=total>0?Math.round(100f*hits/total):0;
                out.add("🟩 "+g+" ← 🟨 "+y+" | نسبة الربط المرصودة: "+pct+"% ("+hits+"/"+total+")");
            }
        }

        // Also report the strongest previously learned relations for currently visible greens.
        for(String g:nowG){
            List<String> learned=db.relationsFor(g,3);
            for(String item:learned) if(!out.contains(item)) out.add(item);
        }
        return out;
    }

    private static Set<String> labels(String signature){
        LinkedHashSet<String> s=new LinkedHashSet<>();
        if(signature==null||signature.isEmpty()) return s;
        for(String x:signature.split(";")) if(!x.isEmpty()) s.add(x);
        return s;
    }

    private String signature(List<Detector.Tile> items){
        ArrayList<String> labels=new ArrayList<>();
        for (Detector.Tile t : items) if (t!=null && t.label!=null && !t.label.equals("غير معروف")) labels.add(t.label);
        Collections.sort(labels);
        StringBuilder s=new StringBuilder();
        String last="";
        for(String label:labels){
            if(!label.equals(last)){ s.append(label).append(';'); last=label; }
        }
        return s.toString();
    }

    private String updateAndRecommend(String previous,String current,InteractionReferenceLearner.Observation interaction){
        // A transition is counted only at the close of a real icon-interaction window.
        // Ordinary animation, scrolling, or page refreshes therefore cannot inflate the model.
        if(interaction==null || previous==null||previous.isEmpty()||current==null||current.isEmpty()||previous.equals(current)) return "";
        Set<String> before=new LinkedHashSet<>(Arrays.asList(previous.split(";")));
        String next="";
        for(String item:current.split(";")) if(!item.isEmpty()&&!before.contains(item)){ next=item; break; }
        if(next.isEmpty()) return "";
        int total=db.observeTransition(previous,next);
        int hits=db.transitionHits(previous,next);
        if(hits < 3) return "انتقال مرصود: "+next+" — نحتاج مشاهدات إضافية قبل تثبيت النسبة.";
        int pct=Math.round(100f*hits/Math.max(1,total));
        return "الشريط التالي المرصود: "+next+" — "+pct+"% ("+hits+"/"+total+")";
    }


    /** Remove consecutive duplicate observations caused by repeated screen/OCR frames. */
    private List<String> filteredRecentPlayLabels(int limit) {
        List<String> raw = db.recentPlayLabels(Math.max(20, limit * 3));
        ArrayList<String> out = new ArrayList<>();
        String last = "";
        for (String label : raw) {
            if (label == null) continue;
            label = label.trim();
            if (label.isEmpty() || label.equals(last)) continue;
            out.add(label);
            last = label;
        }
        int from = Math.max(0, out.size() - Math.max(1, limit));
        return new ArrayList<>(out.subList(from, out.size()));
    }

    private String firstRecognizedLabel(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        for (String label : filteredRecentPlayLabels(30)) {
            if (!label.isEmpty() && text.contains(label)) return label;
        }
        return text.trim();
    }

    /** Predict from persistent observed relations; unknown labels use general history. */
    private AnalysisResult.Prediction predictFromHistory(String currentLabel) {
        if (currentLabel == null || currentLabel.trim().isEmpty()) return null;
        currentLabel = currentLabel.trim();
        List<String> learned = db.relationsFor(currentLabel, 1);
        if (!learned.isEmpty()) {
            String row = learned.get(0);
            String token = "← 🟨 ";
            int arrow = row.indexOf(token);
            if (arrow >= 0) {
                int start = arrow + token.length();
                int pipe = row.indexOf(" | ", start);
                String gift = (pipe > start ? row.substring(start, pipe) : row.substring(start)).trim();
                int hits = db.relationHits(currentLabel, gift);
                int total = db.relationTotal(currentLabel);
                int pct = total > 0 ? Math.round(100f * hits / total) : 0;
                return new AnalysisResult.Prediction(gift, pct);
            }
        }
        List<String> history = filteredRecentPlayLabels(200);
        if (history.isEmpty()) return new AnalysisResult.Prediction("تحليل أولي: تابع النمط العام", 50);
        LinkedHashMap<String,Integer> counts = new LinkedHashMap<>();
        for (String label : history) counts.put(label, counts.containsKey(label) ? counts.get(label)+1 : 1);
        String best = ""; int bestCount = 0;
        for (Map.Entry<String,Integer> e : counts.entrySet()) if (e.getValue() > bestCount) { best=e.getKey(); bestCount=e.getValue(); }
        if (best.isEmpty()) return new AnalysisResult.Prediction("تحليل أولي: تابع النمط العام", 50);
        int pct = Math.max(50, Math.min(99, Math.round(100f * bestCount / Math.max(1, history.size()))));
        return new AnalysisResult.Prediction(best, pct);
    }

    private String buildPrePlayPlan(List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,String currentGreenState){
        ArrayList<Detector.Tile> candidates=new ArrayList<>();
        candidates.addAll(greenItems);
        candidates.addAll(yellowItems);
        List<PrePlayDecisionEngine.Decision> ranked=prePlayDecisionEngine.rank(candidates,currentGreenState,db);
        if(ranked.isEmpty()) return "";
        StringBuilder s=new StringBuilder("تحليل العناصر المرصودة (بدون توصية مراهنة):\n");
        int n=Math.min(5,ranked.size());
        for(int i=0;i<n;i++){
            PrePlayDecisionEngine.Decision d=ranked.get(i);
            s.append(d.line(i+1));
            HitPlanEngine.Plan hp=hitPlanEngine.best(d.label,db);
            if(hp!=null) s.append(" | سجل اختبار مرصود ×").append(hp.hits);
            else s.append(" | لا يوجد سجل اختبار كافٍ");
            s.append('\n');
        }
        s.append("ملاحظة: التحليل وصفي ولا يحدد نتيجة أو مبلغ مراهنة.");
        return s.toString().trim();
    }

    private String buildCoordinates(List<Detector.Marker> green,List<Detector.Marker> yellow,
                                    List<Detector.Tile> greenItems,List<Detector.Tile> yellowItems,
                                    int width,int height){
        StringBuilder s=new StringBuilder();
        if(!green.isEmpty()){
            s.append("🟩 إحداثيات الشرايط (x,y,w,h): ");
            for(int i=0;i<green.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=green.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!yellow.isEmpty()){
            s.append("🟨 إحداثيات الخزين (x,y,w,h): ");
            for(int i=0;i<yellow.size();i++){
                if(i>0)s.append(" ؛ ");
                Rect r=yellow.get(i).rect;
                s.append(i+1).append("=(").append(r.left).append(',').append(r.top).append(',')
                 .append(r.width()).append(',').append(r.height()).append(')');
            }
            s.append('\n');
        }
        if(!greenItems.isEmpty()){
            s.append("📍 مراكز العناصر: ");
            for(int i=0;i<greenItems.size();i++){
                Detector.Tile t=greenItems.get(i); if(t.rect.isEmpty()) continue;
                if(s.charAt(s.length()-1)!=' ') s.append(" ؛ ");
                s.append("🟩 ").append(t.label).append("@").append((t.rect.left+t.rect.right)/2)
                 .append(',').append((t.rect.top+t.rect.bottom)/2);
            }
        }
        return s.toString();
    }

    private static double centerDistance(Rect a,Rect b){
        double ax=(a.left+a.right)/2.0,ay=(a.top+a.bottom)/2.0;
        double bx=(b.left+b.right)/2.0,by=(b.top+b.bottom)/2.0;
        return Math.hypot(ax-bx,ay-by);
    }
    private static String firstNewLabel(String previous,String current){
        Set<String> before=labels(previous);
        for(String x:labels(current)) if(!before.contains(x)) return x;
        return "";
    }
    public void save(AnalysisResult r){db.add(r);} public TemplateRepository templates(){return templates;} public HistoryDb db(){return db;} public AnalyticsEngine analytics(){return analytics;}
    public WebSocketReadOnlyMonitor webSocketMonitor(){return webSocketMonitor;}
    public OwnedTrafficMetadataMonitor trafficMetadataMonitor(){return trafficMetadataMonitor;}
    public SelfMemoryStateMonitor selfMemoryMonitor(){return selfMemoryMonitor;}
    public SignalRedundancyRouter signalRouter(){return signalRouter;}
    public FridaSafetyBoundary fridaBoundary(){return fridaBoundary;}
    public ParallelProcessingEngine parallelEngine(){return parallelEngine;}
    public HardwareAccelerationManager hardwareAcceleration(){return hardwareAcceleration;}
    public MultiprocessingBoundary multiprocessingBoundary(){return multiprocessingBoundary;}
    public InteractionReferenceLearner interactionLearner(){return interactionLearner;}
    public PrePlayDecisionEngine prePlayDecisionEngine(){return prePlayDecisionEngine;}
    public PatternAnalyticsEngine patternAnalyticsEngine(){return patternAnalyticsEngine;}
    public BettingSignalEngine bettingSignalEngine(){return bettingSignalEngine;}
    public DeepChainPatternEngine deepChainPatternEngine(){return deepChainPatternEngine;}
    public DynamicRiskStepper dynamicRiskStepper(){return dynamicRiskStepper;}
    public ZeroSecondTimingMonitor zeroSecondTimingMonitor(){return zeroSecondTimingMonitor;}
    public GameSignalEngine gameSignalEngine(){return gameSignalEngine;}
}
