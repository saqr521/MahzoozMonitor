package com.mahzooz.monitor;

import java.util.*;

/** First-order Markov model over screen-observed labels. It only learns transitions that the app observes. */
public final class MarkovChainsModel {
    private final Map<String,Map<String,Integer>> counts = new HashMap<>();
    public synchronized void observe(String previousState,String nextLabel){
        if(previousState==null||previousState.isEmpty()||nextLabel==null||nextLabel.isEmpty())return;
        Map<String,Integer> row=counts.computeIfAbsent(previousState,k->new HashMap<>());
        row.put(nextLabel,row.getOrDefault(nextLabel,0)+1);
    }
    public synchronized List<String> rank(String previousState,int limit){
        ArrayList<String> out=new ArrayList<>(); Map<String,Integer> row=counts.get(previousState); if(row==null)return out;
        int total=0; for(int n:row.values())total+=n;
        ArrayList<Map.Entry<String,Integer>> e=new ArrayList<>(row.entrySet()); e.sort((a,b)->Integer.compare(b.getValue(),a.getValue()));
        for(int i=0;i<Math.min(limit,e.size());i++){Map.Entry<String,Integer> x=e.get(i);int pct=total==0?0:Math.round(100f*x.getValue()/total);out.add(x.getKey()+"|"+pct+"|"+x.getValue()+"/"+total);}
        return out;
    }
}
