package com.mahzooz.monitor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import java.util.*;

/**
 * Live visual reader for the Mahzooz item board.
 *
 * The v46 build previously contained an unrelated fixed 5x2 Taka board reader
 * with unrelated game prototypes. That reader could never describe the
 * Mahzooz green/yellow item board correctly.  This class now uses the same
 * marker-first pipeline as the main Analyzer and reads only the user-selected
 * rectangle supplied to it.
 */
public final class GamePlayVision {
    public static final class Suggestion {
        public final String label;
        public final int confidencePct;
        public final int hits;
        public final int total;
        Suggestion(String l, int c, int h, int t) {
            label = l;
            confidencePct = Math.max(0, Math.min(100, c));
            hits = h;
            total = t;
        }
    }

    public static final class Result {
        public final boolean gridDetected, stable;
        public final String currentLabel;
        public final int recognitionPct;
        public final List<Suggestion> suggestions;
        public final int changedCells;
        public final String sequence;
        Result(boolean gd, boolean st, String cl, int rp, List<Suggestion> ss, int cc, String seq) {
            gridDetected = gd;
            stable = st;
            currentLabel = cl;
            recognitionPct = rp;
            suggestions = ss;
            changedCells = cc;
            sequence = seq;
        }
    }

    private final Context boardContext;
    private final TemplateRepository templates;
    private String lastSignature = "";
    private int stableFrames = 0;
    private String committedSignature = "";
    private String lastTrigger = "";

    public GamePlayVision(Context context) {
        boardContext = context.getApplicationContext();
        templates = new TemplateRepository(boardContext);
    }

    public synchronized Result analyze(Bitmap board, HistoryDb db, long nowMs) {
        if (board == null || board.isRecycled() || board.getWidth() < 80 || board.getHeight() < 80) {
            return empty();
        }

        List<Detector.Marker> green = Detector.findMarkers(board, true);
        List<Detector.Marker> yellow = Detector.findMarkers(board, false);
        List<Detector.Marker> all = new ArrayList<>();
        all.addAll(green);
        all.addAll(yellow);
        all.sort((a, b) -> {
            int d = Integer.compare(a.rect.top, b.rect.top);
            return d != 0 ? d : Integer.compare(a.rect.left, b.rect.left);
        });

        TemplateRepository repo = templates;
        ArrayList<String> labels = new ArrayList<>();
        int recognized = 0;
        float scoreSum = 0f;
        for (Detector.Marker marker : all) {
            Detector.Tile tile = Detector.itemForMarker(board, marker, repo);
            String label = tile == null ? "" : tile.label;
            if (label == null || label.isEmpty() || "غير معروف".equals(label)) label = "";
            labels.add(label);
            if (!label.isEmpty()) {
                recognized++;
                scoreSum += Math.max(0f, Math.min(1f, tile.similarity));
            }
        }

        String signature = String.join(";", labels);
        if (signature.equals(lastSignature)) stableFrames++;
        else {
            lastSignature = signature;
            stableFrames = 1;
        }

        String trigger = "";
        int changed = 0;
        if (stableFrames >= 2 && !signature.equals(committedSignature)) {
            if (!committedSignature.isEmpty()) {
                String[] old = committedSignature.split(";", -1);
                int n = Math.min(old.length, labels.size());
                for (int i = 0; i < n; i++) {
                    String before = old[i] == null ? "" : old[i];
                    String after = labels.get(i);
                    if (!after.isEmpty() && !after.equals(before)) {
                        changed++;
                        if (trigger.isEmpty()) trigger = after;
                        if (!before.isEmpty()) {
                            try { db.observeGameTransition(before, after); } catch (Throwable ignored) {}
                        }
                    }
                }
            } else {
                for (String label : labels) if (!label.isEmpty()) { trigger = label; break; }
            }
            committedSignature = signature;
            if (!trigger.isEmpty()) lastTrigger = trigger;
        }

        if (trigger.isEmpty()) trigger = lastTrigger;
        if (trigger.isEmpty()) {
            for (String label : labels) if (!label.isEmpty()) { trigger = label; break; }
        }

        List<Suggestion> suggestions = aggregateSuggestions(labels, db);
        int recognition = recognized == 0 ? 0 : Math.round(100f * scoreSum / recognized);
        boolean detected = !all.isEmpty();
        return new Result(detected, stableFrames >= 2, trigger, recognition, suggestions,
                changed, sequenceText(labels));
    }


    private Result empty() {
        return new Result(false, false, "", 0, Collections.emptyList(), 0, "");
    }

    private List<Suggestion> aggregateSuggestions(List<String> labels, HistoryDb db) {
        HashMap<String, int[]> agg = new HashMap<>();
        for (String current : labels) {
            if (current == null || current.isEmpty()) continue;
            try {
                for (String row : db.rankedGameTransitions(current, 5)) {
                    String[] p = row.split("\\|", -1);
                    if (p.length < 3) continue;
                    String[] ht = p[2].split("/", 2);
                    if (ht.length < 2) continue;
                    int hits = Integer.parseInt(ht[0]);
                    int total = Integer.parseInt(ht[1]);
                    if (hits <= 0 || total <= 0) continue;
                    int[] a = agg.get(p[0]);
                    if (a == null) { a = new int[]{0, 0}; agg.put(p[0], a); }
                    a[0] += hits;
                    a[1] += total;
                }
            } catch (Throwable ignored) {}
        }
        ArrayList<Suggestion> out = new ArrayList<>();
        for (Map.Entry<String, int[]> e : agg.entrySet()) {
            int hits = e.getValue()[0], total = e.getValue()[1];
            if (hits <= 0 || total <= 0) continue;
            out.add(new Suggestion(e.getKey(), Math.round(100f * hits / total), hits, total));
        }
        out.sort((a, b) -> {
            int d = Integer.compare(b.confidencePct, a.confidencePct);
            return d != 0 ? d : Integer.compare(b.hits, a.hits);
        });
        return out.size() > 5 ? new ArrayList<>(out.subList(0, 5)) : out;
    }

    private String sequenceText(List<String> labels) {
        if (labels.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (String s : labels) {
            if (b.length() > 0) b.append(" → ");
            b.append(s == null || s.isEmpty() ? "غير مقروء" : s);
        }
        return b.toString();
    }
}
