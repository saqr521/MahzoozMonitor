# Native atomic boundary

`mahzooz_atomic.cpp` demonstrates the C++ `std::atomic` counterpart for
counters owned by the monitor itself. It is intentionally not wired to an
external process and does not implement memory hooking, Frida attachment,
or game-process inspection.

The Android Java path uses `AtomicLong`/`AtomicInteger` so the current APK does
not require the NDK toolchain.
