package com.mahzooz.monitor;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ScaleGestureDetector;
import android.widget.FrameLayout;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;

public class CaptureService extends Service {
    public static final String ACTION_RESULT = "com.mahzooz.monitor.RESULT";
    private MediaProjection projection;
    private ImageReader reader;
    private android.hardware.display.VirtualDisplay display;
    private Analyzer analyzer;
    private HandlerThread workerThread;
    private Handler worker;
    private Handler mainHandler;
    private long lastFrame = 0;
    private AnalysisAccelerators accelerators;
    private ScreenshotAndCvTools cvTools;
    private boolean running = false;
    private WindowManager overlayManager;
    private LinearLayout overlayView;
    private android.widget.FrameLayout overlayContainer;
    private WindowManager.LayoutParams overlayParams;
    private TextView liveText;
    private TextView exploreText;
    private TextView liveHeader;
    private TextView exploreHeader;
    private TextView roundText;
    private TextView mahzoozStatus;
    private TextView incomeStatus;
    private TextView topGameStatus;
    private android.widget.Button selectGameButton;
    private TextView selectedGameText;
    private View moveHandle;
    private android.widget.Button regionButton;
    private android.view.View regionOverlay;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        createChannel();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, notification("جاري التقاط الشاشة وتحليلها"));
        }

        // A new monitoring session always replaces the previous one.
        // This prevents an old floating panel from surviving beside the new panel.
        if (running || overlayView != null || projection != null || reader != null) {
            cleanupCapture();
        }

        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = intent.getParcelableExtra("data");
        }

        if (resultCode != Activity.RESULT_OK || data == null) {
            broadcast("لم يتم منح صلاحية التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager pm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = pm.getMediaProjection(resultCode, data);
        if (projection == null) {
            broadcast("تعذر بدء التقاط الشاشة.");
            stopSelf();
            return START_NOT_STICKY;
        }

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = intent.getIntExtra("width", dm.widthPixels);
        int h = intent.getIntExtra("height", dm.heightPixels);
        int dpi = intent.getIntExtra("densityDpi", dm.densityDpi);

        mainHandler = new Handler(getMainLooper());
        workerThread = new HandlerThread("MahzoozCapture");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        analyzer = new Analyzer(this);
        AlgorithmTrace.init(this);
        accelerators = new AnalysisAccelerators(AnalysisAccelerators.Level.BALANCED);
        cvTools = new ScreenshotAndCvTools();

        reader = ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 3);

        // Android 14+ requires the MediaProjection callback to be registered
        // before creating the VirtualDisplay.
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                running = false;
                broadcast("تم إيقاف التقاط الشاشة.");
                stopSelf();
            }
        }, worker);

        display = projection.createVirtualDisplay(
                "MahzoozMonitor", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, worker);

        reader.setOnImageAvailableListener(r -> {
            running = true;
            long now = System.currentTimeMillis();
            Image image = null;
            Bitmap bitmap = null;
            Bitmap analysisBitmap = null;
            try {
                image = r.acquireLatestImage();
                if (image == null) return;
                bitmap = ImageUtils.toBitmap(image);
                // The floating panel is itself part of a MediaProjection frame.
                // Mask it before OCR/vision so the monitor cannot read its own
                // words (for example "محظوظ") and falsely classify the scene.
                analysisBitmap = maskOverlayFromFrame(bitmap);
                // The captured frame exists only in RAM for this analysis pass.
                // Never write it to Pictures/DCIM or any user-visible image file.
                long frameHash = Detector.phash(analysisBitmap, new android.graphics.Rect(0,0,analysisBitmap.getWidth(),analysisBitmap.getHeight()));
                if (!accelerators.shouldAnalyze(now, frameHash)) {
                    if (analysisBitmap != bitmap && !analysisBitmap.isRecycled()) analysisBitmap.recycle();
                    return;
                }
                lastFrame = now;
                AnalysisResult result = analyzer.analyze(bitmap, analysisBitmap);
                AlgorithmTrace.recordSignalBoundary(new SignalObservation(now, SignalObservation.Direction.GAME_TO_MONITOR, "SCREEN_CAPTURE", SignalReaders.visualState(analysisBitmap, result.green, result.yellow), result.confidence));
                analyzer.save(result);
                broadcast(format(result));
                updateOverlay(result);
            } catch (Throwable e) {
                broadcast("خطأ أثناء تحليل اللقطة: " + e.getClass().getSimpleName());
            } finally {
                if (image != null) image.close();
                if (analysisBitmap != null && analysisBitmap != bitmap && !analysisBitmap.isRecycled()) analysisBitmap.recycle();
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }, worker);

        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            updateOverlay(null);
        }
        broadcast("تم بدء التقاط الشاشة — في انتظار مؤشرات اللعبة...");
        return START_NOT_STICKY;
    }

    private Bitmap maskOverlayFromFrame(Bitmap source) {
        if (source == null || source.isRecycled() || overlayParams == null || overlayContainer == null) return source;
        try {
            int left = Math.max(0, overlayParams.x);
            int top = Math.max(0, overlayParams.y);
            int right = Math.min(source.getWidth(), left + Math.max(0, overlayParams.width));
            int bottom = Math.min(source.getHeight(), top + Math.max(0, overlayParams.height));
            if (right <= left || bottom <= top) return source;
            Bitmap copy = source.copy(Bitmap.Config.ARGB_8888, true);
            if (copy == null) return source;
            android.graphics.Canvas canvas = new android.graphics.Canvas(copy);
            android.graphics.Paint paint = new android.graphics.Paint();
            paint.setColor(0xFF000000);
            canvas.drawRect(left, top, right, bottom, paint);
            return copy;
        } catch (Throwable ignored) {
            return source;
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, "capture")
                .setContentTitle("محظوظ")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void broadcast(String text) {
        Intent out = new Intent(ACTION_RESULT);
        out.setPackage(getPackageName());
        out.putExtra("text", text);
        sendBroadcast(out);
    }

    private String format(AnalysisResult r) {
        if (r == null) return "";
        return "تم الرصد: " + r.green.size() + " | " + r.yellow.size() + (r.ocrText.isEmpty() ? "" : " | OCR: " + r.ocrText);
    }

    private void updateOverlay(AnalysisResult r) {
        if (Build.VERSION.SDK_INT < 23 || !Settings.canDrawOverlays(this)) { removeOverlay(); return; }
        if (mainHandler != null && android.os.Looper.myLooper() != mainHandler.getLooper()) {
            mainHandler.post(() -> updateOverlay(r));
            return;
        }
        try {
            ensureOverlay();
            if (r == null) {
                liveText.setText("");
                exploreText.setText("");
                return;
            }
            updateTopStatus();
            TextView gameTitle = overlayView.findViewById(R.id.tvCurrentGameTitle);
            if (gameTitle != null) {
                String prefix = analyzer.isTakaForeground() ? "Taka — " : "";
                gameTitle.setText(prefix + "اللعبة المكتشفة الآن: " + analyzer.currentGameModeName());
            }
            liveText.setText(buildLiveOverlay(r));
            if (exploreText != null) exploreText.setText("");
        } catch (Throwable ignored) {}
    }

    private void ensureOverlay() {
        if (overlayManager == null) overlayManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (overlayView != null) return;

        overlayView = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);
        liveText = overlayView.findViewById(R.id.tvLiveText);
        android.view.View overlayScroll = overlayView.findViewById(R.id.tvLiveText);
        if (overlayScroll != null) overlayScroll.setVerticalScrollBarEnabled(false);
        exploreText = overlayView.findViewById(R.id.tvExploreText);
        mahzoozStatus = overlayView.findViewById(R.id.tvMahzoozStatus);
        incomeStatus = overlayView.findViewById(R.id.tvIncomeStatus);
        topGameStatus = overlayView.findViewById(R.id.tvTopGameStatus);
        updateTopStatus();
        TextView gameTitle = overlayView.findViewById(R.id.tvCurrentGameTitle);
        selectGameButton = overlayView.findViewById(R.id.btnSelectGame);
        selectedGameText = overlayView.findViewById(R.id.tvSelectedGame);
        updateSelectedGameText();
        if (selectGameButton != null) {
            selectGameButton.setOnClickListener(v -> {
                if (analyzer == null) return;
                analyzer.cycleSelectedGameMode();
                updateSelectedGameText();
                updateTopStatus();
                if (liveText != null) refreshOverlayText();
            });
        }
        regionButton = overlayView.findViewById(R.id.btnSetReadRegion);
        if (regionButton != null) {
            regionButton.setOnClickListener(v -> showReadRegionSelector());
        }
        moveHandle = overlayView.findViewById(R.id.tvMoveHandle);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        overlayParams = new WindowManager.LayoutParams(
                dp(440), dp(290), type, flags, PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;

        android.content.SharedPreferences sp = getSharedPreferences("overlay", MODE_PRIVATE);
        overlayParams.x = sp.getInt("x", 8);
        overlayParams.y = sp.getInt("y", 70);
        overlayParams.width = Math.max(dp(300), sp.getInt("w", dp(440)));
        overlayParams.height = Math.max(dp(190), sp.getInt("h", dp(290)));

        PinchResizeFrame frame = new PinchResizeFrame(this);
        overlayContainer = frame;
        frame.addView(overlayView, new FrameLayout.LayoutParams(-1, -1));
        overlayManager.addView(frame, overlayParams);

        View.OnTouchListener drag = new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY(); startX=overlayParams.x; startY=overlayParams.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (e.getPointerCount() == 1) {
                            overlayParams.x=startX+Math.round(e.getRawX()-downX);
                            overlayParams.y=startY+Math.round(e.getRawY()-downY);
                            try { overlayManager.updateViewLayout(frame, overlayParams); } catch(Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                        getSharedPreferences("overlay", MODE_PRIVATE).edit()
                                .putInt("x",overlayParams.x).putInt("y",overlayParams.y)
                                .putInt("w",overlayParams.width).putInt("h",overlayParams.height).apply();
                        return true;
                }
                return false;
            }
        };
        if (moveHandle != null) moveHandle.setOnTouchListener(drag);
        if (gameTitle != null) gameTitle.setOnTouchListener(drag);
        if (mahzoozStatus != null) mahzoozStatus.setOnTouchListener(drag);
        if (incomeStatus != null) incomeStatus.setOnTouchListener(drag);
        if (topGameStatus != null) topGameStatus.setOnTouchListener(drag);
    }

    /**
     * Floating overlay container that keeps one-finger dragging on the section
     * headers and adds two-finger pinch zoom anywhere inside the overlay.
     */
    private class PinchResizeFrame extends FrameLayout {
        private final ScaleGestureDetector scaleDetector;

        PinchResizeFrame(android.content.Context context) {
            super(context);
            scaleDetector = new ScaleGestureDetector(context,
                    new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                        @Override public boolean onScale(ScaleGestureDetector detector) {
                            if (overlayParams == null || overlayManager == null) return true;

                            float factor = detector.getScaleFactor();
                            if (Float.isNaN(factor) || Float.isInfinite(factor)) return true;
                            if (factor < 0.5f) factor = 0.5f;
                            if (factor > 2.0f) factor = 2.0f;

                            DisplayMetrics dm = getResources().getDisplayMetrics();
                            int maxW = Math.max(dp(300), Math.round(dm.widthPixels * 0.96f));
                            int maxH = Math.max(dp(190), Math.round(dm.heightPixels * 0.70f));

                            int newW = Math.round(overlayParams.width * factor);
                            int newH = Math.round(overlayParams.height * factor);
                            overlayParams.width = Math.max(dp(300), Math.min(maxW, newW));
                            overlayParams.height = Math.max(dp(190), Math.min(maxH, newH));

                            try {
                                overlayManager.updateViewLayout(PinchResizeFrame.this, overlayParams);
                            } catch (Exception ignored) {}
                            return true;
                        }
                    });
        }

        @Override public boolean onInterceptTouchEvent(MotionEvent ev) {
            // Keep the detector's initial ACTION_DOWN while one finger is used.
            // As soon as a second finger appears, take over the gesture and resize
            // the complete floating window with a two-finger pinch.
            if (ev.getPointerCount() < 2) {
                scaleDetector.onTouchEvent(ev);
                return false;
            }
            return true;
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);
            if (event.getActionMasked() == MotionEvent.ACTION_UP
                    || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                getSharedPreferences("overlay", MODE_PRIVATE).edit()
                        .putInt("x", overlayParams.x)
                        .putInt("y", overlayParams.y)
                        .putInt("w", overlayParams.width)
                        .putInt("h", overlayParams.height)
                        .apply();
            }
            return true;
        }
    }

    /** Opens a full-screen calibration shade. The selected rectangle is the only
     * region used for visual game/icon analysis; OCR/routing can still use the
     * complete screen. Coordinates are stored normalized for different densities.
     */
    private void showReadRegionSelector() {
        if (overlayManager == null) overlayManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (regionOverlay != null) return;
        final int screenW = getResources().getDisplayMetrics().widthPixels;
        final int screenH = getResources().getDisplayMetrics().heightPixels;
        final int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        final WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                -1, -1, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;

        ReadRegionView v = new ReadRegionView(this, screenW, screenH);
        regionOverlay = v;
        v.setOnDone(() -> {
            float l=v.leftNorm(), t=v.topNorm(), r=v.rightNorm(), b=v.bottomNorm();
            getSharedPreferences("analysis_region", MODE_PRIVATE).edit()
                    .putBoolean("enabled", true).putFloat("left", l).putFloat("top", t)
                    .putFloat("right", r).putFloat("bottom", b).apply();
            getSharedPreferences("game_selection", MODE_PRIVATE).edit()
                    .putBoolean("read_region_enabled", true)
                    .putFloat("read_region_left", l).putFloat("read_region_top", t)
                    .putFloat("read_region_right", r).putFloat("read_region_bottom", b).apply();
            removeReadRegionSelector();
            broadcast("تم حفظ منطقة القراءة — سيحلل البرنامج المستطيل الذي حددته.");
            updateSelectedGameText();
        });
        v.setOnCancel(this::removeReadRegionSelector);
        try { overlayManager.addView(regionOverlay, p); }
        catch (Throwable e) { regionOverlay = null; }
    }

    private void removeReadRegionSelector() {
        if (regionOverlay != null && overlayManager != null) {
            try { overlayManager.removeView(regionOverlay); } catch (Throwable ignored) {}
        }
        regionOverlay = null;
    }

    private class ReadRegionView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final int sw, sh;
        private float l, t, r, b;
        private float downX, downY, startL, startT, startR, startB;
        private int mode = 0;
        private Runnable done, cancel;

        ReadRegionView(android.content.Context c, int w, int h) {
            super(c);
            sw=w; sh=h;
            android.content.SharedPreferences sp=getSharedPreferences("analysis_region",MODE_PRIVATE);
            if (sp.getBoolean("enabled",false)) {
                l=sp.getFloat("left",.08f)*w; t=sp.getFloat("top",.20f)*h;
                r=sp.getFloat("right",.92f)*w; b=sp.getFloat("bottom",.78f)*h;
            } else {
                l=.06f*w; t=.20f*h; r=.94f*w; b=.82f*h;
            }
            normalize();
        }

        void setOnDone(Runnable x){ done=x; }
        void setOnCancel(Runnable x){ cancel=x; }
        float leftNorm(){ return l/(float)sw; }
        float topNorm(){ return t/(float)sh; }
        float rightNorm(){ return r/(float)sw; }
        float bottomNorm(){ return b/(float)sh; }

        private void normalize(){
            l=Math.max(0,Math.min(sw-100,l));
            t=Math.max(0,Math.min(sh-140,t));
            r=Math.max(l+100,Math.min(sw,r));
            b=Math.max(t+100,Math.min(sh,b));
        }

        @Override protected void onDraw(android.graphics.Canvas c){
            super.onDraw(c);
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(0x66000000); c.drawRect(0,0,getWidth(),getHeight(),paint);
            paint.setColor(0x2600FF66); c.drawRect(l,t,r,b,paint);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(5); paint.setColor(0xFF00FF66); c.drawRect(l,t,r,b,paint);
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(0xEE10151D); c.drawRoundRect(l,t,r,t+56,10,10,paint);
            paint.setColor(android.graphics.Color.WHITE);
            paint.setTextSize(24); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            c.drawText("حدد مستطيل اللعبة الذي سيقرأه البرنامج",Math.max(12,l+10),t+35,paint);
            paint.setTextSize(19);
            c.drawText("اسحب من الداخل للتحريك — اسحب الحواف للتوسيع/التصغير",Math.max(12,l+10),Math.min(sh-65,b+34),paint);
            paint.setColor(0xFF00FF66); paint.setTextSize(23);
            c.drawText("تم",Math.max(12,r-55),Math.max(35,t-12),paint);
            paint.setColor(android.graphics.Color.WHITE);
            c.drawText("إلغاء",Math.max(12,l),Math.max(35,t-12),paint);
        }

        private int hit(float x,float y){
            float e=48;
            if (Math.abs(x-l)<e && y>t+60 && y<b) return 2;
            if (Math.abs(x-r)<e && y>t+60 && y<b) return 3;
            if (Math.abs(y-t)<e && x>l+60 && x<r) return 4;
            if (Math.abs(y-b)<e && x>l && x<r) return 5;
            if (x>l && x<r && y>t+60 && y<b) return 1;
            if (y<t && x>r-90) return 6;
            if (y<t && x<l+90) return 7;
            return 0;
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(), y=e.getY();
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    mode=hit(x,y); downX=x; downY=y;
                    startL=l; startT=t; startR=r; startB=b; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=x-downX, dy=y-downY;
                    if(mode==1){ l=startL+dx; r=startR+dx; t=startT+dy; b=startB+dy; }
                    else if(mode==2) l=startL+dx;
                    else if(mode==3) r=startR+dx;
                    else if(mode==4) t=startT+dy;
                    else if(mode==5) b=startB+dy;
                    normalize(); invalidate(); return true;
                case MotionEvent.ACTION_UP:
                    if(mode==6){ if(done!=null) done.run(); return true; }
                    if(mode==7){ if(cancel!=null) cancel.run(); return true; }
                    mode=0; return true;
            }
            return true;
        }
    }

    private LinearLayout makeSection(String title, boolean live) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(7), dp(5), dp(7), dp(7));

        GradientDrawable bg = new GradientDrawable();
        // Semi-transparent section backgrounds keep the game visible underneath.
        bg.setColor(live ? 0x8F171A20 : 0x8F202020);
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(1), live ? 0xC04CAF50 : 0xC0E0B83B);
        box.setBackground(bg);

        TextView header = new TextView(this);
        header.setText(title + "  ⋮⋮");
        header.setTextSize(14);
        header.setTextColor(0xFFFFFFFF);
        header.setTypeface(null, android.graphics.Typeface.BOLD);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, dp(2), 0, dp(5));
        box.addView(header, new LinearLayout.LayoutParams(-1, -2));

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);

        TextView body = new TextView(this);
        body.setTextSize(12.5f);
        body.setTextColor(0xFFFFFFFF);
        body.setGravity(Gravity.RIGHT | Gravity.TOP);
        body.setLineSpacing(dp(2), 1.08f);
        body.setPadding(dp(3), dp(2), dp(3), dp(5));
        scroll.addView(body, new android.widget.ScrollView.LayoutParams(-1, -2));
        box.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        if (live) { liveHeader = header; liveText = body; }
        else { exploreHeader = header; exploreText = body; }
        return box;
    }

    private void updateTopStatus() {
        if (analyzer == null) return;
        if (mainHandler != null && android.os.Looper.myLooper() != mainHandler.getLooper()) {
            mainHandler.post(this::updateTopStatus);
            return;
        }
        try {
            boolean taka = analyzer.isTakaForeground();
            int mahzoozConfidence = analyzer.mahzoozRecognitionConfidence();
            int internalConfidence = analyzer.internalRecognitionConfidence();
            if (mahzoozStatus != null) {
                String state = mahzoozConfidence > 0 ? " مفتوح" : " غير ظاهر";
                mahzoozStatus.setText("محظوظ" + state + "\nالتعرف الحالي: " + mahzoozConfidence + "%");
            }
            if (incomeStatus != null) {
                String state = internalConfidence > 0 ? " مفتوح" : " غير ظاهر";
                incomeStatus.setText("الدخل / الألعاب الداخلية" + state + "\nالتعرف الحالي: " + internalConfidence + "%");
            }
            if (topGameStatus != null) {
                String visible = analyzer.visibleGameName();
                if (!visible.isEmpty() && analyzer.hasConfirmedInternalGame()) {
                    String stake = analyzer.observedStake() > 0 ? "\nالرهان الظاهر: " + analyzer.observedStake() : "\nالرهان الظاهر: غير مقروء";
                    topGameStatus.setText("اللعبة الداخلية المفتوحة الآن\n" + visible + " — " + internalConfidence + "%" + stake);
                } else {
                    topGameStatus.setText("اللعبة الداخلية المفتوحة الآن\nلا توجد لعبة مؤكدة على الشاشة الحالية");
                }
            }
        } catch (Throwable ignored) {}
    }
    private void updateSelectedGameText() {
        if (selectedGameText == null || analyzer == null) return;
        boolean enabled=getSharedPreferences("analysis_region",MODE_PRIVATE).getBoolean("enabled",false);
        selectedGameText.setText("الاختيار اليدوي: " + analyzer.selectedGameModeName() +
                (enabled ? " | منطقة القراءة: مفعلة" : " | منطقة القراءة: الشاشة كاملة"));
    }

    private void refreshOverlayText() {
        if (analyzer == null || liveText == null) return;
        liveText.setText(buildLiveOverlay(null));
    }

    private String buildLiveOverlay(AnalysisResult r) {
        if (analyzer == null) return "جاري تهيئة الرصد...";
        return analyzer.compactLivePanel();
    }

    private String buildExploreOverlay(AnalysisResult r) {
        if (analyzer == null) return "جاري تهيئة اللوحة الداخلية...";
        return analyzer.internalGameDashboard();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void removeOverlay() {
        if (overlayView != null && overlayManager != null) {
            try { overlayManager.removeView(overlayContainer != null ? overlayContainer : overlayView); } catch (Exception ignored) {}
        }
        removeReadRegionSelector();
        overlayView = null; overlayContainer = null; overlayManager = null; overlayParams = null;
        liveText = null; exploreText = null; liveHeader = null; exploreHeader = null; selectGameButton = null; selectedGameText = null; moveHandle = null; regionButton = null;
    }

    private void cleanupCapture() {
        running = false;
        removeOverlay();
        try { if (reader != null) { reader.close(); reader = null; } } catch (Throwable ignored) {}
        try { if (display != null) { display.release(); display = null; } } catch (Throwable ignored) {}
        try { if (projection != null) { projection.stop(); projection = null; } } catch (Throwable ignored) {}
        try { if (workerThread != null) { workerThread.quitSafely(); workerThread = null; worker = null; } } catch (Throwable ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    "capture", "مراقبة الشاشة", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // The floating window must never outlive the app task.
        removeOverlay();
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        removeOverlay();
        try { if (analyzer != null) { analyzer.close(); analyzer.db().endPlaySession(System.currentTimeMillis()); } } catch (Throwable ignored) {}
        cleanupCapture();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
