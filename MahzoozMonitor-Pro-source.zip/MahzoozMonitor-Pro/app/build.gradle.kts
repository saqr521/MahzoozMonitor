plugins { id("com.android.application") }

android { namespace = "com.mahzooz.monitor"; compileSdk = 35
 defaultConfig { applicationId = "com.mahzooz.monitor"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "3.0.0" }
}

dependencies { implementation("androidx.core:core:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0") }
