package com.mahzooz.monitor;

import java.util.*;

/**
 * Compares only what the monitor has actually observed for each game profile.
 * The score is a signal/quality index, not a win probability or guarantee.
 */
public final class GameSignalEngine {
    public static final class Signal {
        public final GameRouter.GameMode mode;
        public final String name;
        public final int score;
        public final int observations;
        public final int outcomeSamples;
        public final int observedWinRate;
        public final String status;

        Signal(GameRouter.GameMode mode, String name, int score, int observations,
               int outcomeSamples, int observedWinRate, String status) {
            this.mode = mode;
            this.name = name;
            this.score = score;
            this.observations = observations;
            this.outcomeSamples = outcomeSamples;
            this.observedWinRate = observedWinRate;
            this.status = status;
        }

        public String line() {
            return name + " | إشارة " + score + "% | مشاهدات " + observations +
                    (outcomeSamples > 0 ? " | نتائج " + outcomeSamples + " | معدل مرصود " + observedWinRate + "%" : "") +
                    " | " + status;
        }
    }

    private static final class Stats {
        int observations;
        float confidenceSum;
        int wins;
        int losses;
        int consecutiveWeak;
        long lastSeen;
    }

    private final EnumMap<GameRouter.GameMode, Stats> stats =
            new EnumMap<>(GameRouter.GameMode.class);
    private GameRouter.GameMode current = GameRouter.GameMode.UNKNOWN;

    public synchronized void observe(GameRouter.GameMode mode, int recognitionConfidence,
                                      String ocr, long nowMs) {
        if (mode == null || mode == GameRouter.GameMode.UNKNOWN) return;
        current = mode;
        Stats s = stats.computeIfAbsent(mode, k -> new Stats());
        s.observations++;
        s.confidenceSum += clamp(recognitionConfidence, 0, 100);
        s.lastSeen = nowMs;
        String outcome = outcome(ocr);
        if ("W".equals(outcome)) s.wins++;
        else if ("L".equals(outcome)) s.losses++;
        if (recognitionConfidence < 42) s.consecutiveWeak++;
        else s.consecutiveWeak = 0;
    }

    public synchronized Signal strongest() {
        GameRouter.GameMode best = null;
        int bestScore = -1;
        for (Map.Entry<GameRouter.GameMode, Stats> e : stats.entrySet()) {
            int score = score(e.getValue());
            if (score > bestScore) { bestScore = score; best = e.getKey(); }
        }
        if (best == null) return new Signal(GameRouter.GameMode.UNKNOWN, "لا توجد بيانات كافية", 0, 0, 0, 0, "انتظر رصدًا فعليًا");
        return make(best, stats.get(best));
    }

    public synchronized Signal currentSignal() {
        if (current == GameRouter.GameMode.UNKNOWN || !stats.containsKey(current))
            return strongest();
        return make(current, stats.get(current));
    }

    /** Returns the latest observed signal for a specific game profile. */
    public synchronized Signal signalFor(GameRouter.GameMode mode) {
        if (mode == null || mode == GameRouter.GameMode.UNKNOWN || !stats.containsKey(mode)) {
            return new Signal(GameRouter.GameMode.UNKNOWN, "لا توجد بيانات كافية", 0, 0, 0, 0, "انتظر رصدًا فعليًا");
        }
        return make(mode, stats.get(mode));
    }

    public synchronized List<Signal> ranking(int limit) {
        ArrayList<GameRouter.GameMode> modes = new ArrayList<>(stats.keySet());
        modes.sort((a,b) -> Integer.compare(score(stats.get(b)), score(stats.get(a))));
        ArrayList<Signal> out = new ArrayList<>();
        for (GameRouter.GameMode mode : modes) {
            if (out.size() >= Math.max(1, limit)) break;
            out.add(make(mode, stats.get(mode)));
        }
        return out;
    }

    /** True only when the currently visible signal has materially deteriorated. */
    public synchronized boolean shouldSwitch() {
        Signal cur = currentSignal();
        Signal best = strongest();
        return cur.mode != GameRouter.GameMode.UNKNOWN && best.mode != cur.mode &&
                best.score >= cur.score + 15 && cur.score < 55;
    }

    public synchronized String dashboard() {
        Signal cur = currentSignal();
        if (cur.mode == GameRouter.GameMode.UNKNOWN) {
            return "تحليل النظام: غير محدد\\nانتظر دليلًا مرئيًا/مقروءًا مؤكدًا.";
        }
        StringBuilder s = new StringBuilder();
        s.append("اللعبة/الملف المرصود: ").append(cur.name).append('\n');
        s.append("ثقة التعرف: ").append(cur.score).append("%\\n");
        s.append("عدد المشاهدات: ").append(cur.observations);
        if (cur.outcomeSamples > 0) {
            s.append(" | النتائج المقروءة: ").append(cur.outcomeSamples);
            s.append(" | المعدل المرصود: ").append(cur.observedWinRate).append("%");
        }
        s.append("\\nحالة البيانات: ").append(cur.status);
        s.append("\\nهذه أرقام وصفية لما قرأه البرنامج، وليست توقعًا أو توصية باللعب.");
        return s.toString().trim();
    }

    private Signal make(GameRouter.GameMode mode, Stats s) {
        int n = s.observations;
        int outcomes = s.wins + s.losses;
        int winRate = outcomes == 0 ? 0 : Math.round(100f * s.wins / outcomes);
        String status;
        if (n < 10) status = "عينة صغيرة";
        else if (s.consecutiveWeak >= 3) status = "الإشارة تضعف";
        else if (outcomes >= 20 && winRate >= 60) status = "نتائج مرصودة جيدة";
        else status = "تحتاج مزيدًا من الرصد";
        return new Signal(mode, name(mode), score(s), n, outcomes, winRate, status);
    }

    private int score(Stats s) {
        if (s == null || s.observations == 0) return 0;
        float recognition = s.confidenceSum / s.observations;
        int stability = Math.min(25, s.observations / 4);
        int outcomeComponent = 0;
        int outcomes = s.wins + s.losses;
        if (outcomes > 0) {
            float rate = 100f * s.wins / outcomes;
            float shrink = Math.min(1f, outcomes / 30f);
            outcomeComponent = Math.round((rate * shrink + 50f * (1f-shrink)) * .25f);
        }
        int score = Math.round(recognition * .60f) + stability + outcomeComponent;
        if (s.consecutiveWeak >= 3) score -= 15;
        return clamp(score, 0, 100);
    }

    private String name(GameRouter.GameMode mode) {
        switch (mode) {
            case LUCKY_GIFTS: return "هدايا المحظوظ";
            case DRAGON_TIGER: return "التنين والنمر";
            case BACCARAT: return "باكارات";
            case POKER: return "بوكر / تكساس";
            case CARD_GAMES: return "ألعاب الورق";
            case DICE_GAMES: case DICE_GAME: return "النرد / سيكبو / لودو";
            case ROULETTE: case WHEEL_ROULETTE: return "العجلة / الروليت";
            case CRASH_GAMES: case CRASH_GAME: return "كراش / مضاعف";
            case TABLE_GAMES: return "ألعاب الطاولة";
            case ARCADE_INSTANT: return "ألعاب فورية";
            case SPORTS_GAMES: return "ألعاب رياضية";
            default: return "غير محدد";
        }
    }

    private String outcome(String ocr) {
        if (ocr == null) return "";
        String t = ocr.toLowerCase(Locale.ROOT);
        if (containsAny(t, "win", "won", "winner", "فوز", "فاز", "رابح", "ربح")) return "W";
        if (containsAny(t, "lose", "lost", "loss", "خسارة", "خسر", "خاسر")) return "L";
        return "";
    }

    private boolean containsAny(String t, String... values) {
        for (String v : values) if (t.contains(v)) return true;
        return false;
    }

    private int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
