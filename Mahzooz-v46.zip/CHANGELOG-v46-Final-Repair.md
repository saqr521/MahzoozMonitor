# Mahzooz v46 — Final repair

- Simplified project archive name to `Mahzooz-v46.zip` for GitHub Actions upload.
- Workflow now uses that exact ZIP name and never selects an older ZIP by wildcard.
- Live grid reader respects the selected read rectangle and no longer manufactures symbols for flat/background cells.
- Grid detection requires visual evidence before reporting a valid grid.
- Live results are no longer blocked solely because OCR/accessibility did not confirm the Taka interface.
- Existing observed-only history, transitions, relations, and confidence percentages remain intact; the app does not invent win probabilities.
- Final APK artifact remains `Mahzooz-debug.apk`.
