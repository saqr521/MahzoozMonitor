package com.mahzooz.monitor;

/** Monotonic nanosecond timer. It is paired with wall-clock timestamps when persistence is needed. */
public final class HighResolutionTimer {
    private HighResolutionTimer() {}
    public static long nowNanos(){ return System.nanoTime(); }
    public static long elapsedNanos(long startNanos){ return Math.max(0L, System.nanoTime() - startNanos); }
    public static long elapsedMillis(long startNanos){ return elapsedNanos(startNanos) / 1_000_000L; }
}
