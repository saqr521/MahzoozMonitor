# v45 — Live Grid Reader

- The selected read rectangle is now read from the raw MediaProjection frame; the floating overlay is masked only for OCR/room routing.
- Live board recognition now prefers the 4x3 grid visible in the supplied Taka Jackpot screen, with 5x3 fallback.
- Each cell is classified using a semantic catalog when a real visual match exists; otherwise a stable learned visual ID is assigned instead of inventing a name.
- Current board order is displayed explicitly.
- Suggested hits are aggregated from observed transitions across the currently visible symbols and ranked by observed frequency.
- No screenshot files are written and the reader remains read-only.
